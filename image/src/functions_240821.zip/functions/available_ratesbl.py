from functions.additional_functions import *
import decimal
from datetime import date
from functions.htpint import htpint
from functions.ratecode_rate import ratecode_rate
from functions.calculate_occupied_roomsbl import calculate_occupied_roomsbl
from sqlalchemy import func
from models import Ratecode, Queasy, Htparam, Zimkateg, Guest_pr, Waehrung, Segment, Arrangement, Res_line

def available_ratesbl(frdate:date, todate:date, i_zikatnr:int, i_counter:int, adult_child_str:str, ind_gastno:int, created_list:[Created_list]):
    rate_list_list = []
    adult:int = 0
    child:int = 0
    rooms:int = 1
    inp_resnr:int = 0
    inp_reslinnr:int = 0
    rmtype:int = 0
    argtno:int = 0
    markno:int = 0
    wahrno:int = 0
    tokcounter:int = 0
    iftask:str = ""
    mestoken:str = ""
    mesvalue:str = ""
    currency:str = ""
    mapcode:str = ""
    datum:date = None
    ankunft:date = None
    dynacode:str = ""
    rmtype_str:str = ""
    curr_i:int = 0
    curr_date:date = None
    rm_rate:decimal = 0
    rate_found:bool = False
    restricted:bool = False
    kback_flag:bool = False
    global_occ:bool = False
    dd:int = 0
    mm:int = 0
    yyyy:int = 0
    ci_date:date = None
    co_date:date = None
    map_code:str = ""
    use_it:bool = False
    w_day:int = 0
    occ_rooms:int = 0
    wd_array:[int] = [0, 0, 0, 0, 0, 0, 0, 0, 0]
    occ_room_array:[int] = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    not_found_flag:bool = False
    do_it:bool = False
    rate_created:bool = False
    allotment_ok:bool = False
    calc_rm:bool = False
    ratecode = queasy = htparam = zimkateg = guest_pr = waehrung = segment = arrangement = res_line = None

    created_list = rate_list = dynarate_list = selected_ratelist = buff_rlist = buff_dynarate = bratecode = bqueasy = qsy18 = ratebuff = dynabuff = zbuff = None

    created_list_list, Created_list = create_model("Created_list", {"ratecode":str, "marknr":int, "rmcateg":int, "argtno":int, "statcode":[str, 30], "rmrate":[decimal, 30]})
    rate_list_list, Rate_list = create_model("Rate_list", {"ratecode":str, "segmentcode":str, "dynaflag":bool, "expired":bool, "room_type":int, "argtno":int, "statcode":[str, 30], "rmrate":[decimal, 30], "minstay":int, "maxstay":int, "minadvance":int, "maxadvance":int, "frdate":date, "todate":date, "adult":int, "child":int, "currency":int, "wabkurz":str, "occ_rooms":int, "marknr":int, "i_counter":int}, {"frdate": None, "todate": None})
    dynarate_list_list, Dynarate_list = create_model("Dynarate_list", {"counter":int, "w_day":int, "rmtype":str, "fr_room":int, "to_room":int, "days1":int, "days2":int, "rcode":str, "dynacode":str})
    selected_ratelist_list, Selected_ratelist = create_model("Selected_ratelist", {"ratecode":str, "marknr":int, "argtno":int, "adult":int, "child":int, "minstay":int, "maxstay":int})

    Buff_rlist = Rate_list
    buff_rlist_list = rate_list_list

    Buff_dynarate = Dynarate_list
    buff_dynarate_list = dynarate_list_list

    Bratecode = Ratecode
    Bqueasy = Queasy
    Qsy18 = Queasy
    Ratebuff = Ratecode
    Dynabuff = Dynarate_list
    dynabuff_list = dynarate_list_list

    Zbuff = Zimkateg

    db_session = local_storage.db_session

    def generate_output():
        nonlocal rate_list_list, adult, child, rooms, inp_resnr, inp_reslinnr, rmtype, argtno, markno, wahrno, tokcounter, iftask, mestoken, mesvalue, currency, mapcode, datum, ankunft, dynacode, rmtype_str, curr_i, curr_date, rm_rate, rate_found, restricted, kback_flag, global_occ, dd, mm, yyyy, ci_date, co_date, map_code, use_it, w_day, occ_rooms, wd_array, occ_room_array, not_found_flag, do_it, rate_created, allotment_ok, calc_rm, ratecode, queasy, htparam, zimkateg, guest_pr, waehrung, segment, arrangement, res_line
        nonlocal buff_rlist, buff_dynarate, bratecode, bqueasy, qsy18, ratebuff, dynabuff, zbuff


        nonlocal created_list, rate_list, dynarate_list, selected_ratelist, buff_rlist, buff_dynarate, bratecode, bqueasy, qsy18, ratebuff, dynabuff, zbuff
        nonlocal created_list_list, rate_list_list, dynarate_list_list, selected_ratelist_list
        return {"rate-list": rate_list_list}

    def check_allotment(origcode:str, statcode:str, curr_date:date):

        nonlocal rate_list_list, adult, child, rooms, inp_resnr, inp_reslinnr, rmtype, argtno, markno, wahrno, tokcounter, iftask, mestoken, mesvalue, currency, mapcode, datum, ankunft, dynacode, rmtype_str, curr_i, rm_rate, rate_found, restricted, kback_flag, global_occ, dd, mm, yyyy, ci_date, co_date, map_code, use_it, w_day, occ_rooms, wd_array, occ_room_array, not_found_flag, do_it, rate_created, allotment_ok, calc_rm, ratecode, queasy, htparam, zimkateg, guest_pr, waehrung, segment, arrangement, res_line
        nonlocal buff_rlist, buff_dynarate, bratecode, bqueasy, qsy18, ratebuff, dynabuff, zbuff


        nonlocal created_list, rate_list, dynarate_list, selected_ratelist, buff_rlist, buff_dynarate, bratecode, bqueasy, qsy18, ratebuff, dynabuff, zbuff
        nonlocal created_list_list, rate_list_list, dynarate_list_list, selected_ratelist_list

        allotment_ok = False
        occ_room:int = 0
        allotment:int = 0
        curr_i:int = 0
        rline_origcode:str = ""
        str:str = ""
        ratecode_found:bool = False
        doit_flag:bool = False

        def generate_inner_output():
            return allotment_ok
        Zbuff = Zimkateg

        zimkateg = db_session.query(Zimkateg).filter(
                (Zimkateg.zikatnr == rate_list.room_type)).first()

        if zimkateg.typ == 0:

            ratecode = db_session.query(Ratecode).filter(
                    (func.lower(Ratecode.code) == (statcode).lower()) &  (Ratecode.zikatnr == rate_list.room_type) &  (Ratecode.argtnr == rate_list.argtno) &  (Ratecode.startperiode <= curr_date) &  (Ratecode.endperiode >= curr_date) &  (Ratecode.num1[0] > 0)).first()
            ratecode_found = None != ratecode

            if ratecode_found:
                allotment = ratecode.num1[0]
        else:

            ratecode_obj_list = []
            for ratecode, zbuff in db_session.query(Ratecode, Zbuff).join(Zbuff,(Zbuff.zikatnr == Ratecode.zikatnr) &  (Zbuff.typ == zimkateg.typ)).filter(
                    (func.lower(Ratecode.code) == (statcode).lower()) &  (Ratecode.zikatnr == rate_list.room_type) &  (Ratecode.argtnr == rate_list.argtno) &  (Ratecode.startperiode <= curr_date) &  (Ratecode.endperiode >= curr_date) &  (Ratecode.num1[0] > 0)).all():
                if ratecode._recid in ratecode_obj_list:
                    continue
                else:
                    ratecode_obj_list.append(ratecode._recid)


                ratecode_found = True
                allotment = ratecode.num1[0]


                pass
                break

        if not (allotment > 0):

            return generate_inner_output()

        for res_line in db_session.query(Res_line).filter(
                (Res_line.gastnr == ind_gastno) &  (Res_line.active_flag <= 1) &  (Res_line.ankunft <= curr_date) &  (Res_line.abreise > curr_date) &  ((Res_line.resstatus <= 6) &  (Res_line.resstatus != 3) &  (Res_line.resstatus != 4)) &  (Res_line.zimmer_wunsch.op("~")(".*\$origcode\$.*"))).all():
            doit_flag = (res_line.resnr != inp_resnr) or (res_line.reslinnr != inp_reslinnr)

            if doit_flag  and zimkateg.typ == 0:

                if res_line.zikatnr != zimkateg.zikatnr:
                    doit_flag = False
            else:

                zbuff = db_session.query(Zbuff).filter(
                        (Zbuff.zikatnr == res_line.zikatnr)).first()

                if zbuff.typ != zimkateg.typ:
                    doit_flag = False

            if doit_flag:

                arrangement = db_session.query(Arrangement).filter(
                        (Arrangement == res_line.arrangement)).first()

                if arrangement.argtnr != rate_list.argtno:
                    doit_flag = False

            if doit_flag:
                for curr_i in range(1,num_entries(res_line.zimmer_wunsch, ";") - 1 + 1) :
                    str = entry(curr_i - 1, res_line.zimmer_wunsch, ";")

                    if substring(str, 0, 10) == "$origcode$":
                        rline_origcode = substring(str, 10)

                        if rline_origcode.lower()  == (origcode).lower() :
                            occ_room = occ_room + res_line.zimmeranz
                        break

        if (occ_room + rooms) > allotment:
            allotment_ok = False


        return generate_inner_output()


    htparam = db_session.query(Htparam).filter(
            (Htparam.paramnr == 459)).first()

    if htparam:
        calc_rm = htparam.flogical

    if ind_gastno == 0:
        ind_gastno = get_output(htpint(123))

        if ind_gastno == 0:

            return generate_output()
    adult_child_str = substring(adult_child_str, 2)
    adult = to_int(entry(0, adult_child_str, ","))
    child = to_int(entry(1, adult_child_str, ","))

    if num_entries(adult_child_str, ",") > 2:
        i_counter = i_counter * 100
        mm = to_int(substring(entry(2, adult_child_str, ",") , 0, 2))
        dd = to_int(substring(entry(2, adult_child_str, ",") , 2, 2))
        yyyy = to_int(substring(entry(2, adult_child_str, ",") , 4, 4))
        co_date = date_mdy(mm, dd, yyyy) + 1

        if todate > co_date:
            todate = co_date

    if num_entries(adult_child_str, ",") > 3:
        rooms = to_int(entry(3, adult_child_str, ","))
        inp_resnr = to_int(entry(4, adult_child_str, ","))
        inp_reslinnr = to_int(entry(5, adult_child_str, ","))

    zimkateg = db_session.query(Zimkateg).filter(
            (Zimkateg.zikatnr == i_zikatnr)).first()

    htparam = db_session.query(Htparam).filter(
            (Htparam.paramnr == 87)).first()
    ci_date = htparam.fdate

    if frdate == ci_date:
        ankunft = ci_date
    else:
        ankunft = frdate + 2

    guest_pr_obj_list = []
    for guest_pr, bqueasy in db_session.query(Guest_pr, Bqueasy).join(Bqueasy,(Bqueasy.key == 2) &  (Bqueasy.char1 == Guest_pr.CODE)).filter(
            (Guest_pr.gastnr == ind_gastno)).all():
        if guest_pr._recid in guest_pr_obj_list:
            continue
        else:
            guest_pr_obj_list.append(guest_pr._recid)

        if bqueasy.number3 > (ankunft - ci_date):
            1

        elif bqueasy.deci3 > 0 and bqueasy.deci3 < (ankunft - ci_date):
            1

        elif not bqueasy.logi2:

            for bratecode in db_session.query(Bratecode).filter(
                    (Bratecode.CODE == guest_pr.CODE) &  (Bratecode.zikatnr == i_zikatnr) &  (Bratecode.erwachs == adult) &  (Bratecode.kind1 == child) &  (not (Bratecode.startperiode > todate)) &  (not (Bratecode.endperiode < frdate))).all():
                do_it = True

                if bqueasy.number3 != 0:

                    buff_rlist = query(buff_rlist_list, filters=(lambda buff_rlist :buff_rlist.rateCode != bratecode.CODE and buff_rlist.room_type == bratecode.zikatnr and buff_rlist.argtno == bratecode.argtnr and buff_rlist.adult == bratecode.erwachs and buff_rlist.child == bratecode.kind1 and buff_rlist.marknr == bratecode.marknr), first=True)
                    do_it = not None != buff_rlist

                if do_it:

                    rate_list = query(rate_list_list, filters=(lambda rate_list :rate_list.rateCode == bratecode.CODE and rate_list.room_type == bratecode.zikatnr and rate_list.argtno == bratecode.argtnr and rate_list.adult == bratecode.erwachs and rate_list.child == bratecode.kind1 and rate_list.marknr == bratecode.marknr), first=True)

                    if not rate_list:

                        qsy18 = db_session.query(Qsy18).filter(
                                (Qsy18.key == 18) &  (Qsy18.number1 == bratecode.marknr)).first()

                        waehrung = db_session.query(Waehrung).filter(
                                (Waehrung.wabkurz == qsy18.char3)).first()
                        rate_list = Rate_list()
                        rate_list_list.append(rate_list)

                        i_counter = i_counter + 1
                        rate_list.i_counter = i_counter
                        rate_list.rateCode = bratecode.CODE
                        rate_list.room_type = bratecode.zikatnr
                        rate_list.argtno = bratecode.argtnr
                        rate_list.adult = bratecode.erwachs
                        rate_list.child = bratecode.kind1
                        rate_list.marknr = bratecode.marknr
                        rate_list.currency = bqueasy.number1
                        rate_list.minstay = bqueasy.number2
                        rate_list.maxstay = bqueasy.deci2
                        rate_list.minadvance = bqueasy.number3
                        rate_list.maxadvance = bqueasy.deci3
                        rate_list.frdate = bqueasy.date1
                        rate_list.todate = bqueasy.date2
                        rate_list.wabkurz = waehrung.wabkurz

                        if bqueasy.char3 != "":

                            segment = db_session.query(Segment).filter(
                                    (Segment.bezeich == bqueasy.char3)).first()

                            if segment:
                                rate_list.segmentcode = to_string(segmentcode) + " " + segment.bezeich

                        if bqueasy.date1 != None and (ci_date < bqueasy.date1):
                            rate_list.expired = True

                        if bqueasy.date2 != None and (ci_date > bqueasy.date2):
                            rate_list.expired = True
                    curr_i = 0

                    if not rate_list.expired:
                        for curr_date in range(frdate,todate + 1) :
                            curr_i = curr_i + 1
                            allotment_ok = check_allotment(bqueasy.char1, bqueasy.char1, curr_date)
                            rate_found = allotment_ok

                            if allotment_ok:
                                rate_found, rm_rate, restricted, kback_flag = get_output(ratecode_rate(False, False, 0, 1, ("!" + bqueasy.char1), ci_date, curr_date, curr_date, curr_date, rate_list.marknr, rate_list.argtno, i_zikatnr, rate_list.adult, rate_list.child, 0, 0, rate_list.currency))

                            if rate_found:
                                rate_list.rmRate[curr_i - 1] = rm_rate
                                rate_list.statcode[curr_i - 1] = bqueasy.char1


                            else:
                                rate_list.rmRate[curr_i - 1] = -0.001

        elif bqueasy.logi2:
            dynarate_list_list.clear()

            for bratecode in db_session.query(Bratecode).filter(
                    (Bratecode.CODE == guest_pr.CODE)).all():
                dynarate_list = Dynarate_list()
                dynarate_list_list.append(dynarate_list)

                dynarate_list.dynacode = bratecode.CODE
                iftask = bratecode.char1[4]


                for tokcounter in range(1,num_entries(iftask, ";") - 1 + 1) :
                    mestoken = substring(entry(tokcounter - 1, iftask, ";") , 0, 2)
                    mesvalue = substring(entry(tokcounter - 1, iftask, ";") , 2)

                    if mestoken == "CN":
                        dynarate_list.counter = to_int(mesvalue)
                    elif mestoken == "RT":
                        dynarate_list.rmtype = mesvalue
                    elif mestoken == "WD":
                        dynarate_list.w_day = to_int(mesvalue)
                    elif mestoken == "FR":
                        dynarate_list.fr_room = to_int(mesvalue)
                    elif mestoken == "TR":
                        dynarate_list.to_room = to_int(mesvalue)
                    elif mestoken == "D1":
                        dynarate_list.days1 = to_int(mesvalue)
                    elif mestoken == "D2":
                        dynarate_list.days2 = to_int(mesvalue)
                    elif mestoken == "RC":
                        dynarate_list.rCode = mesvalue

        htparam = db_session.query(Htparam).filter(
                (Htparam.paramnr == 439)).first()

        dynarate_list = query(dynarate_list_list, filters=(lambda dynarate_list :dynarate_list.rmtype.lower()  == "*"), first=True)
        global_occ = None != dynarate_list and htparam.finteger == 1

        if global_occ:

            for dynarate_list in query(dynarate_list_list, filters=(lambda dynarate_list :dynarate_list.rmtype.lower()  != "*")):
                dynarate_list_list.remove(dynarate_list)

        else:

            for dynarate_list in query(dynarate_list_list, filters=(lambda dynarate_list :dynarate_list.rmtype != zimkateg.kurzbez)):
                dynarate_list_list.remove(dynarate_list)


        for dynarate_list in query(dynarate_list_list):

            bratecode_obj_list = []
            for bratecode, arrangement in db_session.query(Bratecode, Arrangement).join(Arrangement,(Arrangement.argtnr == Bratecode.argtnr)).filter(
                    (Bratecode.CODE == dynarate_list.rcode) &  (Bratecode.zikatnr == i_zikatnr) &  (Bratecode.erwachs == adult) &  (Bratecode.kind1 == child) &  (not (Bratecode.startperiode > todate)) &  (not (Bratecode.endperiode < frdate))).all():
                if bratecode._recid in bratecode_obj_list:
                    continue
                else:
                    bratecode_obj_list.append(bratecode._recid)

                buff_rlist = query(buff_rlist_list, filters=(lambda buff_rlist :buff_rlist.rateCode == guest_pr.CODE and buff_rlist.room_type == bratecode.zikatnr and buff_rlist.argtno == bratecode.argtnr and buff_rlist.adult == bratecode.erwachs and buff_rlist.child == bratecode.kind1 and buff_rlist.marknr == bratecode.marknr), first=True)
                do_it = not None != buff_rlist

                if do_it:

                    rate_list = query(rate_list_list, filters=(lambda rate_list :rate_list.rateCode == guest_pr.CODE and rate_list.room_type == i_zikatnr and rate_list.argtno == bratecode.argtnr and rate_list.adult == bratecode.erwachs and rate_list.child == bratecode.kind1), first=True)

                    if not rate_list:

                        waehrung = db_session.query(Waehrung).filter(
                                (Waehrungsnr == bqueasy.number1)).first()
                        rate_list = Rate_list()
                        rate_list_list.append(rate_list)

                        i_counter = i_counter + 1
                        rate_list.i_counter = i_counter
                        rate_list.rateCode = guest_pr.CODE
                        rate_list.dynaflag = True
                        rate_list.room_type = i_zikatnr
                        rate_list.argtno = bratecode.argtnr
                        rate_list.adult = bratecode.erwachs
                        rate_list.child = bratecode.kind1
                        rate_list.marknr = bratecode.marknr
                        rate_list.currency = bqueasy.number1
                        rate_list.minstay = bqueasy.number2
                        rate_list.maxstay = bqueasy.deci2
                        rate_list.minadvance = bqueasy.number3
                        rate_list.maxadvance = bqueasy.deci3
                        rate_list.frdate = bqueasy.date1
                        rate_list.todate = bqueasy.date2
                        rate_list.wabkurz = waehrung.wabkurz

                        if bqueasy.char3 != "":

                            segment = db_session.query(Segment).filter(
                                    (Segment.bezeich == bqueasy.char3)).first()

                            if segment:
                                rate_list.segmentcode = to_string(segmentcode) + " " + segment.bezeich

                        if bqueasy.date1 != None and bqueasy.date2 != None and ((ci_date < bqueasy.date1) or (ci_date > bqueasy.date2)):
                            rate_list.expired = True

        if zimkateg.typ > 0:

            for rate_list in query(rate_list_list):

                created_list = query(created_list_list, filters=(lambda created_list :created_list.rateCode == rate_list.rateCode and created_list.marknr == rate_list.marknr and created_list.rmcateg == zimkateg.typ and created_list.argtno == rate_list.argtno), first=True)

                if created_list:
                    rate_created = True
                    rate_list.i_counter = - rate_list.i_counter


                    for curr_i in range(1,30 + 1) :
                        rate_list.rmRate[curr_i - 1] = created_list.rmRate[curr_i - 1]
                        rate_list.statcode[curr_i - 1] = created_list.statcode[curr_i - 1]


        if calc_rm :
            rate_created = False

        rate_list = query(rate_list_list, first=True)

        if rate_list and not rate_created:
            curr_i = 0
            for curr_date in range(frdate,todate + 1) :
                curr_i = curr_i + 1
                w_day = wd_array[get_weekday(curr_date) - 1]


                occ_rooms = get_output(calculate_occupied_roomsbl(curr_date, zimkateg.kurzbez, global_occ))
                occ_room_array[curr_i - 1] = occ_rooms

                dynarate_list = query(dynarate_list_list, filters=(lambda dynarate_list :dynarate_list.w_day == w_day and dynarate_list.days1 == 0 and dynarate_list.days2 == 0 and (dynaRate_list.fr_room <= occ_rooms) and (dynaRate_list.to_room >= occ_rooms)), first=True)

                if not dynarate_list:

                    dynarate_list = query(dynarate_list_list, filters=(lambda dynarate_list :dynarate_list.w_day == 0 and dynarate_list.days1 == 0 and dynarate_list.days2 == 0 and (dynaRate_list.fr_room <= occ_rooms) and (dynaRate_list.to_room >= occ_rooms)), first=True)

                if dynarate_list:
                    mapcode = dynaRate_list.rcode

                    if not global_occ:

                        queasy = db_session.query(Queasy).filter(
                                (Queasy.key == 145) &  (Queasy.char1 == guest_pr.CODE) &  (func.lower(Queasy.char2) == (mapcode).lower()) &  (Queasy.number1 == i_zikatnr) &  (Queasy.deci1 == dynarate_list.w_day) &  (Queasy.deci2 == dynarate_list.counter) &  (Queasy.date1 == curr_date)).first()
                    else:

                        queasy = db_session.query(Queasy).filter(
                                (Queasy.key == 145) &  (Queasy.char1 == guest_pr.CODE) &  (func.lower(Queasy.char2) == (mapcode).lower()) &  (Queasy.number1 == 0) &  (Queasy.deci1 == dynarate_list.w_day) &  (Queasy.deci2 == dynarate_list.counter) &  (Queasy.date1 == curr_date)).first()

                    if queasy:
                        mapcode = queasy.char3

                    for rate_list in query(rate_list_list, filters=(lambda rate_list :rate_list.dynaflag  and rate_list.rateCode == guest_pr.CODE)):
                        rate_found = check_allotment(bqueasy.char1, mapcode, curr_date)

                        if rate_found:
                            rate_found, rm_rate, restricted, kback_flag = get_output(ratecode_rate(False, False, 0, 1, ("!" + mapcode), ci_date, curr_date, curr_date, curr_date, rate_list.marknr, rate_list.argtno, i_zikatnr, rate_list.adult, rate_list.child, 0, 0, rate_list.currency))

                        if rate_found:
                            rate_list.rmRate[curr_i - 1] = rm_rate
                            rate_list.statcode[curr_i - 1] = mapcode


                        else:
                            rate_list.rmRate[curr_i - 1] = -0.001

                            if dynarate_list.w_day != 0:
                                not_found_flag = True


            curr_i = 0

            if not_found_flag:
                for curr_date in range(frdate,todate + 1) :
                    curr_i = curr_i + 1
                    occ_rooms = occ_room_array[curr_i - 1]

                    dynarate_list = query(dynarate_list_list, filters=(lambda dynarate_list :dynarate_list.w_day == 0 and dynarate_list.days1 == 0 and dynarate_list.days2 == 0 and (dynaRate_list.fr_room <= occ_rooms) and (dynaRate_list.to_room >= occ_rooms)), first=True)

                    if dynarate_list:
                        mapcode = dynaRate_list.rcode

                        if not global_occ:

                            queasy = db_session.query(Queasy).filter(
                                    (Queasy.key == 145) &  (Queasy.char1 == guest_pr.CODE) &  (func.lower(Queasy.char2) == (mapcode).lower()) &  (Queasy.number1 == i_zikatnr) &  (Queasy.deci1 == 0) &  (Queasy.deci2 == dynarate_list.counter) &  (Queasy.date1 == curr_date)).first()
                        else:

                            queasy = db_session.query(Queasy).filter(
                                    (Queasy.key == 145) &  (Queasy.char1 == guest_pr.CODE) &  (func.lower(Queasy.char2) == (mapcode).lower()) &  (Queasy.number1 == 0) &  (Queasy.deci1 == dynarate_list.w_day) &  (Queasy.deci2 == dynarate_list.counter) &  (Queasy.date1 == curr_date)).first()

                        if queasy:
                            mapcode = queasy.char3

                        for rate_list in query(rate_list_list, filters=(lambda rate_list :rate_list.dynaflag  and rate_list.rateCode == guest_pr.CODE)):

                            if rate_list.rmRate[curr_i - 1] == 0:
                                rate_found, rm_rate, restricted, kback_flag = get_output(ratecode_rate(False, False, 0, 1, ("!" + mapcode), ci_date, curr_date, curr_date, curr_date, rate_list.marknr, rate_list.argtno, i_zikatnr, rate_list.adult, rate_list.child, 0, 0, rate_list.currency))

                                if rate_found:
                                    rate_list.rmRate[curr_i - 1] = rm_rate
                                    rate_list.statcode[curr_i - 1] = mapcode

    for rate_list in query(rate_list_list, filters=(lambda rate_list :rate_list.minadvance > 0)):

        selected_ratelist = query(selected_ratelist_list, filters=(lambda selected_ratelist :selected_ratelist.marknr == rate_list.marknr and selected_ratelist.argtno == rate_list.argtno and selected_ratelist.adult == rate_list.adult and selected_ratelist.child == rate_list.child and selected_ratelist.minstay == rate_list.minstay and selected_ratelist.maxstay == rate_list.maxstay), first=True)

        if not selected_ratelist:
            selected_ratelist = Selected_ratelist()
            selected_ratelist_list.append(selected_ratelist)

            selected_ratelist.marknr = rate_list.marknr
            selected_ratelist.argtno = rate_list.argtno
            selected_ratelist.adult = rate_list.adult
            selected_ratelist.child = rate_list.child
            selected_ratelist.minstay = rate_list.minstay
            selected_ratelist.maxstay = rate_list.maxstay


        else:
            rate_list_list.remove(rate_list)

    if zimkateg.typ > 0:

        for rate_list in query(rate_list_list, filters=(lambda rate_list :rate_list.dynaflag)):

            if rate_list.i_counter < 0:
                rate_list.i_counter = - rate_list.i_counter
            else:
                created_list = Created_list()
                created_list_list.append(created_list)

                buffer_copy(rate_list, created_list)
                created_list.rmcateg = zimkateg.typ


    return generate_output()