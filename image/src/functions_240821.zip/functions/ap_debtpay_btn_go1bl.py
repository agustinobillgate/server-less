from functions.additional_functions import *
import decimal
from datetime import date
from sqlalchemy import func
from models import L_lieferant, Artikel, L_kredit, Bediener, Queasy, Gl_jouhdr, Gl_acct, Gl_journal, L_order

def ap_debtpay_btn_go1bl(art_selected:int, bill_name:str, bill_date:date):
    outstand = 0
    age_list_list = []
    t_l_lieferant_list = []
    l_lieferant = artikel = l_kredit = bediener = queasy = gl_jouhdr = gl_acct = gl_journal = l_order = None

    age_list = t_l_lieferant = artikel1 = None

    age_list_list, Age_list = create_model("Age_list", {"selected":bool, "ap_recid":int, "counter":int, "docu_nr":str, "rechnr":int, "lief_nr":int, "lscheinnr":str, "supplier":str, "rgdatum":date, "rabatt":decimal, "rabattbetrag":decimal, "ziel":date, "netto":decimal, "user_init":str, "debt":decimal, "credit":decimal, "bemerk":str, "tot_debt":decimal, "rec_id":int, "resname":str, "comments":str, "fibukonto":str, "t_bezeich":str, "debt2":decimal, "recv_date":date})
    t_l_lieferant_list, T_l_lieferant = create_model("T_l_lieferant", {"telefon":str, "fax":str, "adresse1":str, "notizen_1":str, "lief_nr":int})

    Artikel1 = Artikel

    db_session = local_storage.db_session

    def generate_output():
        nonlocal outstand, age_list_list, t_l_lieferant_list, l_lieferant, artikel, l_kredit, bediener, queasy, gl_jouhdr, gl_acct, gl_journal, l_order
        nonlocal artikel1


        nonlocal age_list, t_l_lieferant, artikel1
        nonlocal age_list_list, t_l_lieferant_list
        return {"outstand": outstand, "age-list": age_list_list, "t-l-lieferant": t_l_lieferant_list}

    def create_age_list():

        nonlocal outstand, age_list_list, t_l_lieferant_list, l_lieferant, artikel, l_kredit, bediener, queasy, gl_jouhdr, gl_acct, gl_journal, l_order
        nonlocal artikel1


        nonlocal age_list, t_l_lieferant, artikel1
        nonlocal age_list_list, t_l_lieferant_list

        curr_rechnr:int = 0
        curr_saldo:decimal = 0
        opart:int = 1
        create_it:bool = False
        Artikel1 = Artikel
        age_list_list.clear()
        curr_rechnr = 0
        outstand = 0

        l_kredit_obj_list = []
        for l_kredit, l_lieferant in db_session.query(L_kredit, L_lieferant).join(L_lieferant,(L_lieferant.lief_nr == L_kredit.lief_nr)).filter(
                    (L_kredit.rgdatum <= bill_date) &  (L_kredit.opart < 2) &  (L_kredit.counter >= 0)).all():
            if l_kredit._recid in l_kredit_obj_list:
                continue
            else:
                l_kredit_obj_list.append(l_kredit._recid)


            create_it = False

            if l_kredit.counter == 0:
                create_it = True
            else:

                age_list = query(age_list_list, filters=(lambda age_list :age_list.counter == l_kredit.counter), first=True)

                if not age_list:
                    create_it = True

            if create_it:
                age_list = Age_list()
                age_list_list.append(age_list)

                age_list.counter = l_kredit.counter
                age_list.docu_nr = l_kredit.name
                age_list.rechnr = l_kredit.rechnr
                age_list.lief_nr = l_kredit.lief_nr
                age_list.supplier = l_lieferant.firma + ", " + l_lieferant.anredefirma
                age_list.rec_id = l_kredit._recid

            if l_kredit.zahlkonto == 0:

                bediener = db_session.query(Bediener).filter(
                            (Bediener.nr == l_kredit.bediener_nr)).first()

                if bediener:
                    age_list.user_init = bediener.userinit
                age_list.ap_recid = l_kredit._recid
                age_list.rgdatum = l_kredit.rgdatum
                age_list.debt = l_kredit.saldo
                age_list.rabatt = l_kredit.rabatt
                age_list.rabattbetrag = l_kredit.rabattbetrag
                age_list.netto = l_kredit.netto
                age_list.ziel = l_kredit.rgdatum + l_kredit.ziel
                age_list.lscheinnr = l_kredit.lscheinnr
                age_list.bemerk = l_kredit.bemerk
                age_list.tot_debt = age_list.tot_debt + l_kredit.netto

                queasy = db_session.query(Queasy).filter(
                            (Queasy.key == 221) &  (Queasy.char1 == l_kredit.name)).first()

                if queasy:
                    age_list.recv_date = queasy.date1


            else:
                age_list.credit = age_list.credit - l_kredit.saldo
                age_list.tot_debt = age_list.tot_debt + l_kredit.saldo
            disp_l_lieferant_debt()

            gl_jouhdr = db_session.query(Gl_jouhdr).filter(
                        (Gl_jouhdr.refno == l_kredit.name)).first()

            if gl_jouhdr:

                for gl_journal, gl_acct in db_session.query(Gl_journal, Gl_acct).join(Gl_acct,(Gl_acct.fibukonto == Gl_journal.fibukonto) &  ((Gl_acct.acc_type == 2) |  (Gl_acct.acc_type == 3) |  (Gl_acct.acc_type == 5))).filter(
                            (Gl_journal.jnr == gl_jouhdr.jnr)).all():
                    age_list.comment = age_list.comment + ";" + to_string(gl_journal.fibukonto) + ";" + to_string(l_kredit.steuercode)
                    age_list.fibukonto = gl_journal.fibukonto
                    age_list.t_bezeich = gl_acct.bezeich

                    if gl_journal.debit > 0:
                        age_list.debt2 = gl_journal.debit

                    elif gl_journal.credit > 0:
                        age_list.debt2 = - (gl_journal.credit)
        art_selected = 1

    def create_age_list1():

        nonlocal outstand, age_list_list, t_l_lieferant_list, l_lieferant, artikel, l_kredit, bediener, queasy, gl_jouhdr, gl_acct, gl_journal, l_order
        nonlocal artikel1


        nonlocal age_list, t_l_lieferant, artikel1
        nonlocal age_list_list, t_l_lieferant_list

        curr_rechnr:int = 0
        curr_saldo:decimal = 0
        opart:int = 1
        create_it:bool = False
        Artikel1 = Artikel
        age_list_list.clear()
        curr_rechnr = 0
        outstand = 0

        l_lieferant = db_session.query(L_lieferant).filter(
                    (func.lower(L_lieferant.firma) == (bill_name).lower())).first()

        if l_lieferant:

            for l_kredit in db_session.query(L_kredit).filter(
                        (L_kredit.rgdatum <= bill_date) &  (L_kredit.opart < 2) &  (L_kredit.lief_nr == l_lieferant.lief_nr)).all():
                create_it = False

                if l_kredit.counter == 0:
                    create_it = True
                else:

                    age_list = query(age_list_list, filters=(lambda age_list :age_list.counter == l_kredit.counter), first=True)

                    if not age_list:
                        create_it = True

                if create_it:
                    age_list = Age_list()
                    age_list_list.append(age_list)

                    age_list.counter = l_kredit.counter
                    age_list.docu_nr = l_kredit.name
                    age_list.rechnr = l_kredit.rechnr
                    age_list.lief_nr = l_kredit.lief_nr
                    age_list.supplier = l_lieferant.firma + ", " + l_lieferant.anredefirma
                    age_list.rec_id = l_kredit._recid

                if l_kredit.zahlkonto == 0:

                    bediener = db_session.query(Bediener).filter(
                                (Bediener.nr == l_kredit.bediener_nr)).first()

                    if bediener:
                        age_list.user_init = bediener.userinit
                    age_list.ap_recid = l_kredit._recid
                    age_list.rgdatum = l_kredit.rgdatum
                    age_list.debt = l_kredit.saldo
                    age_list.netto = l_kredit.netto
                    age_list.ziel = l_kredit.rgdatum + l_kredit.ziel
                    age_list.lscheinnr = l_kredit.lscheinnr
                    age_list.bemerk = l_kredit.bemerk
                    age_list.tot_debt = age_list.tot_debt + l_kredit.netto

                    if l_kredit.name != l_kredit.lscheinnr:

                        l_order = db_session.query(L_order).filter(
                                    (L_order.lief_nr == l_kredit.lief_nr) &  (L_order.docu_nr == l_kredit.name) &  (L_order.pos == 0)).first()

                        if l_order:
                            age_list.rabattbetrag = l_order.warenwert

                    queasy = db_session.query(Queasy).filter(
                                (Queasy.key == 221) &  (Queasy.char1 == l_kredit.name)).first()

                    if queasy:
                        age_list.recv_date = queasy.date1


                else:
                    age_list.credit = age_list.credit - l_kredit.saldo
                    age_list.tot_debt = age_list.tot_debt + l_kredit.saldo
                disp_l_lieferant_debt()

                gl_jouhdr = db_session.query(Gl_jouhdr).filter(
                            (Gl_jouhdr.refno == l_kredit.name)).first()

                if gl_jouhdr:

                    for gl_journal, gl_acct in db_session.query(Gl_journal, Gl_acct).join(Gl_acct,(Gl_acct.fibukonto == Gl_journal.fibukonto) &  ((Gl_acct.acc_type == 2) |  (Gl_acct.acc_type == 3) |  (Gl_acct.acc_type == 5))).filter(
                                (Gl_journal.jnr == gl_jouhdr.jnr)).all():
                        age_list.comment = age_list.comment + ";" + to_string(gl_journal.fibukonto) + ";" + to_string(l_kredit.steuercode)
                        age_list.fibukonto = gl_journal.fibukonto
                        age_list.t_bezeich = gl_acct.bezeich

                        if gl_journal.debit > 0:
                            age_list.debt2 = gl_journal.debit

                        elif gl_journal.credit > 0:
                            age_list.debt2 = - (gl_journal.credit)

        art_selected = 1

    def disp_l_lieferant_debt():

        nonlocal outstand, age_list_list, t_l_lieferant_list, l_lieferant, artikel, l_kredit, bediener, queasy, gl_jouhdr, gl_acct, gl_journal, l_order
        nonlocal artikel1


        nonlocal age_list, t_l_lieferant, artikel1
        nonlocal age_list_list, t_l_lieferant_list

        lief_nr:int = 0

        if age_list:
            lief_nr = age_list.lief_nr

            l_lieferant = db_session.query(L_lieferant).filter(
                    (L_lieferant.lief_nr == lief_nr)).first()
            age_list.resname = l_lieferant.firma + ", " + l_lieferant.anredefirma + chr (10) +\
                    l_lieferant.adresse1 + chr (10) + l_lieferant.wohnort + " " + l_lieferant.plz
            age_list.comments = age_list.bemerk


    if bill_name == "":
        create_age_list()
    else:
        create_age_list1()

    for age_list in query(age_list_list):

        l_lieferant = db_session.query(L_lieferant).filter(
                (L_lieferant.lief_nr == age_list.lief_nr)).first()

        if l_lieferant:

            t_l_lieferant = query(t_l_lieferant_list, filters=(lambda t_l_lieferant :t_l_lieferant.lief_nr == l_lieferant.lief_nr), first=True)

            if not t_l_lieferant:
                t_l_lieferant = T_l_lieferant()
                t_l_lieferant_list.append(t_l_lieferant)

                t_l_lieferant.telefon = l_lieferant.telefon
                t_l_lieferant.fax = l_lieferant.fax
                t_l_lieferant.adresse1 = l_lieferant.adresse1
                t_l_lieferant.notizen_1 = l_lieferant.notizen[0]
                t_l_lieferant.lief_nr = l_lieferant.lief_nr

    return generate_output()