from functions.additional_functions import *
import decimal
from models import Bill_line, Blinehis, Artikel

def ar_subledger_prepare_disp_fobillbl(a_rechnr:int):
    t_bill_line_list = []
    t_blinehis_list = []
    bill_line = blinehis = artikel = None

    t_bill_line = t_blinehis = foart = None

    t_bill_line_list, T_bill_line = create_model_like(Bill_line, {"rec_id":int, "run_disp_restbill":bool})
    t_blinehis_list, T_blinehis = create_model_like(Blinehis, {"rec_id":int, "run_disp_restbill":bool})

    Foart = Artikel

    db_session = local_storage.db_session

    def generate_output():
        nonlocal t_bill_line_list, t_blinehis_list, bill_line, blinehis, artikel
        nonlocal foart


        nonlocal t_bill_line, t_blinehis, foart
        nonlocal t_bill_line_list, t_blinehis_list
        return {"t-bill-line": t_bill_line_list, "t-blinehis": t_blinehis_list}


    bill_line = db_session.query(Bill_line).filter(
            (Bill_line.rechnr == a_rechnr)).first()

    if bill_line:

        for bill_line in db_session.query(Bill_line).filter(
                (Bill_line.rechnr == a_rechnr)).all():

            foart = db_session.query(Foart).filter(
                    (Foart.artnr == bill_line.artnr) &  (Foart.departement == 0)).first()
            t_bill_line = T_bill_line()
            t_bill_line_list.append(t_bill_line)

            buffer_copy(bill_line, t_bill_line)
            t_bill_line.rec_id = (bill_line._recid)

            if foart and foart.artart == 1:
                t_bill_line.run_disp_restbill = True

    else:

        for blinehis in db_session.query(Blinehis).filter(
                (Blinehis.rechnr == a_rechnr)).all():

            foart = db_session.query(Foart).filter(
                    (Foart.artnr == bill_line.artnr) &  (Foart.departement == 0)).first()
            t_blinehis = T_blinehis()
            t_blinehis_list.append(t_blinehis)

            buffer_copy(blinehis, t_blinehis)
            t_blinehis.rec_id = (blinehis._recid)

            if foart and foart.artart == 1:
                t_blinehis.run_disp_restbill = True


    return generate_output()