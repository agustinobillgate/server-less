from functions.additional_functions import *
import decimal
from datetime import date
from sqlalchemy import func
from functions.bill_vatsum import bill_vatsum
import re
from functions.ratecode_rate import ratecode_rate
from functions.pricecod_rate import pricecod_rate
from models import Res_line, Reservation, Bediener, Htparam, Guest, Bill, Bill_line, Waehrung, Printer, Briefzei, Artikel, Queasy, Printcod, Akt_kont, Zimkateg, Zimmer, Master, Guest_pr, Reslin_queasy, Arrangement, Katpreis, exrate, Fixleist, Genstat

def bill_parserbl(pvilanguage:int, case_type:int, briefnr:int, reslinnr:int, resnr:int, rechnr:int, gastnr:int, f_page:bool, spbill_flag:bool, inv_type:int, user_init:str, printnr:int, t_spbill_list:[T_spbill_list]):
    succes_flag = False
    outfile = ""
    run_ask = False
    bill_list_list = []
    output_list_list = []
    lvcarea:str = "bill_parser"
    new_contrate:bool = False
    billdate:date = None
    price_decimal:int = 0
    vat_artnr:[int] = [0, 0, 0, 0, 0, 0]
    n:int = 0
    serv_vat:bool = False
    briefnr2:int = 0
    briefnr21:int = 0
    print_rc:bool = False
    f_gastnr:bool = False
    f_resnr:bool = False
    f_resline:bool = False
    f_bill:bool = False
    longer_billamt:bool = False
    long_billamt:bool = False
    master_ankunft:date = None
    master_abreise:date = None
    fixrate_flag:bool = False
    long_digit:bool = False
    exchg_rate:decimal = 1
    curr_line:int = 0
    curr_page:int = 0
    curr_pos:int = 0
    blloop:int = 0
    headloop:int = 0
    f_lmargin:bool = False
    lmargin:int = 1
    proforma_inv:bool = False
    bline_flag:int = -1
    keychar:str = ""
    bl_balance:decimal = 0
    bl_balance1:decimal = 0
    bl0_balance:decimal = 0
    bl0_balance1:decimal = 0
    bl1_balance:decimal = 0
    bl1_balance1:decimal = 0
    bline_nr:int = 0
    print_all_member:bool = False
    g_length:int = 16
    d_length:int = 24
    c_length:int = 48
    w_length:int = 40
    v_length:int = 16
    print_member:bool = True
    short_arrival:bool = False
    short_depart:bool = False
    ntab:int = 1
    nskip:int = 1
    wd_array:[int] = [0, 0, 0, 0, 0, 0, 0, 0, 0]
    bonus_array:[bool] = [None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None]
    curr_bl_vat:decimal = 0
    bl_netto:decimal = 0
    res_line = reservation = bediener = htparam = guest = bill = bill_line = waehrung = printer = briefzei = artikel = queasy = printcod = akt_kont = zimkateg = zimmer = master = guest_pr = reslin_queasy = arrangement = katpreis = exrate = fixleist = genstat = None

    brief_list = htp_list = loop_list = loop1_list = header_list = bill_list = output_list = s_list = t_list = bline_list = t_spbill_list = rmember = mainres = foart = resline = rline = gmember = guest1 = gast = mbill = rsvguest = gbuff = mresline = exchg_buff = htp = w1 = None

    brief_list_list, Brief_list = create_model("Brief_list", {"b_text":str})
    htp_list_list, Htp_list = create_model("Htp_list", {"paramnr":int, "fchar":str})
    loop_list_list, Loop_list = create_model("Loop_list", {"texte":str})
    loop1_list_list, Loop1_list = create_model("Loop1_list", {"texte":str})
    header_list_list, Header_list = create_model("Header_list", {"texte":str})
    bill_list_list, Bill_list = create_model("Bill_list", {"rechnr":int, "name":str, "rechnr2":int})
    output_list_list, Output_list = create_model("Output_list", {"str":str, "pos":int})
    s_list_list, S_list = create_model("S_list", {"nr":int, "ankunft":date, "abreise":date, "bezeich":str, "rmcat":str, "preis":decimal, "lrate":decimal, "datum":date, "qty":int, "erwachs":int, "kind1":int, "kind2":int})
    t_list_list, T_list = create_model("T_list", {"nr":int, "ankunft":date, "abreise":date, "bezeich":str, "rmcat":str, "preis":decimal, "lrate":decimal, "tage":int, "date1":date, "date2":date, "qty":int, "betrag":decimal, "erwachs":int, "kind1":int, "kind2":int})
    bline_list_list, Bline_list = create_model("Bline_list", {"bl_recid":int, "artnr":int, "dept":int, "anzahl":int, "massnr":int, "billin_nr":int, "zeit":int, "mwst_code":int, "vatproz":decimal, "epreis":decimal, "netto":decimal, "fsaldo":decimal, "saldo":decimal, "orts_tax":decimal, "voucher":str, "bezeich":str, "zinr":str, "gname":str, "origin_id":str, "userinit":str, "ankunft":date, "abreise":date, "datum":date}, {"origin_id": ""})
    t_spbill_list_list, T_spbill_list = create_model("T_spbill_list", {"selected":bool, "bl_recid":int}, {"selected": True})

    Rmember = Res_line
    Mainres = Reservation
    Foart = Artikel
    Resline = Res_line
    Rline = Res_line
    Gmember = Guest
    Guest1 = Guest
    Gast = Guest
    Mbill = Bill
    Rsvguest = Guest
    Gbuff = Guest
    Mresline = Res_line
    Exchg_buff = exrate
    Htp = Htparam
    W1 = Waehrung

    db_session = local_storage.db_session

    def generate_output():
        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list
        return {"succes_flag": succes_flag, "outfile": outfile, "run_ask": run_ask, "bill-list": bill_list_list, "output-list": output_list_list}

    def get_rackrate(erwachs:int, kind1:int, kind2:int):

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        rate:decimal = 0

        if erwachs >= 1 and erwachs <= 4:
            rate = rate + katpreis.perspreis[erwachs - 1]
        rate = rate + kind1 * katpreis.kindpreis[0] + kind2 * katpreis.kindpreis[1]
        return rate

    def fill_list():

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        i:int = 0
        j:int = 0
        l:int = 0
        n:int = 0
        c:str = ""
        keycont:str = ""
        continued:bool = False

        htparam = db_session.query(Htparam).filter(
                (Htparam.paramnr == 600)).first()
        keychar = htparam.fchar

        htparam = db_session.query(Htparam).filter(
                (Htparam.paramnr == 1122)).first()
        keycont = keychar + htparam.fchar

        for htparam in db_session.query(Htparam).filter(
                (Htparam.paramgruppe == 17) &  (func.lower(Htparam.bezeich) != "Not Used")).all():
            htp_list = Htp_list()
            htp_list_list.append(htp_list)

            htp_list.paramnr = htparam.paramnr
            htp_list.fchar = keychar + htparam.fchar

        for briefzei in db_session.query(Briefzei).filter(
                    (Briefzei.briefnr == briefnr)).all():
            j = 1
            for i in range(1,len(briefzei.texte)  + 1) :

                if ord(substring(briefzei.texte, i - 1, 1)) == 10:
                    n = i - j
                    c = substring(briefzei.texte, j - 1, n)
                    l = len(c)

                    if not continued:
                        brief_list = Brief_list()
                    brief_list_list.append(brief_list)

                    brief_list.b_text = brief_list.b_text + c
                    j = i + 1

                    if l > len((keycont).lower() ) and substring(c, l - len((keycont).lower() ) + 1 - 1, len((keycont).lower() )) == (keycont).lower() :
                        continued = True
                        b_text = substring(b_text, 0, len(b_text) - len(keycont))
                    else:
                        continued = False
            n = len(briefzei.texte) - j + 1
            c = substring(briefzei.texte, j - 1, n)

            if not continued:
                brief_list = Brief_list()
            brief_list_list.append(brief_list)

            brief_list.b_text = brief_list.b_text + c

    def analyse_text():

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        len_:int = 0

        htp_list = query(htp_list_list, filters=(lambda htp_list :htp_list.paramnr == 2300), first=True)

        if trim(brief_list.b_text) == htp_list.fchar:
            headloop = 1

        htp_list = query(htp_list_list, filters=(lambda htp_list :htp_list.paramnr == 2301), first=True)

        if trim(brief_list.b_text) == htp_list.fchar:
            headloop = headloop + 1

        htp_list = query(htp_list_list, filters=(lambda htp_list :htp_list.paramnr == 2302), first=True)

        if trim(brief_list.b_text) == htp_list.fchar:
            blloop = 1
            bline_flag = -1
        else:
            len_ = len(trim(brief_list.b_text))

            if substring(trim(brief_list.b_text) , 0, len_ - 1) == htp_list.fchar:

                if substring(trim(brief_list.b_text) , len_ - 1, 1) == "0":
                    blloop = 1
                    bline_flag = 0

                elif substring(trim(brief_list.b_text) , len_ - 1, 1) == "1":
                    blloop = 1
                    bline_flag = 1

                elif substring(trim(brief_list.b_text) , len_ - 1, 1) == "2":
                    blloop = 1
                    bline_flag = 2

        htp_list = query(htp_list_list, filters=(lambda htp_list :htp_list.paramnr == 2303), first=True)

        if trim(brief_list.b_text) == htp_list.fchar:
            blloop = blloop + 1

    def build_text_line(curr_texte:str):

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        i:int = 0
        j:int = 1
        n:int = 0
        found:bool = False
        for i in range(1,len(curr_texte)  + 1) :

            if substring(curr_texte, i - 1, 1) == (keychar).lower() :

                if i == len(curr_texte):
                    found = False

                elif substring(curr_texte, i + 1 - 1, 1) == " ":
                    found = False
                else:
                    put_string(substring(curr_texte, j - 1, i - j))
                    i, found = interprete_text(curr_texte, i)
                    j = i + 1
            else:
                found = False

        if not found:
            put_string(substring(curr_texte, j - 1, len(curr_texte) - j + 1))

    def build_loop_line(curr_texte:str):

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        i:int = 0
        j:int = 1
        n:int = 0
        found:bool = False
        for i in range(1,len(curr_texte)  + 1) :

            if substring(curr_texte, i - 1, 1) == (keychar).lower() :

                if i == len(curr_texte):
                    found = False

                elif substring(curr_texte, i + 1 - 1, 1) == " ":
                    found = False
                else:
                    put_string(substring(curr_texte, j - 1, i - j))
                    i, found = interprete_text(curr_texte, i)
                    j = i + 1
            else:
                found = False

        if not found:
            put_string(substring(curr_texte, j - 1, len(curr_texte) - j + 1))

    def cal_vat():

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        t_vat = 0
        vat:decimal = 0
        serv:decimal = 0
        fact:decimal = 0

        def generate_inner_output():
            return t_vat

        bill_line_obj_list = []
        for bill_line, artikel in db_session.query(Bill_line, Artikel).join(Artikel,(Artikel.artnr == Bill_line.artnr) &  (Artikel.departement == Bill_line.departement) &  (Artikel.artart != 2) &  (Artikel.artart != 4) &  (Artikel.artart != 6) &  (Artikel.artart != 7)).filter(
                (Bill_line.rechnr == rechnr)).all():
            if bill_line._recid in bill_line_obj_list:
                continue
            else:
                bill_line_obj_list.append(bill_line._recid)


            serv = 0
            vat = 0

            if bill_line.orts_tax != 0:
                t_vat = t_vat + bill_line.orts_tax
            else:

                if artikel.service_code != 0 and serv_vat:

                    htparam = db_session.query(Htparam).filter(
                            (Htparam.paramnr == artikel.service_code)).first()

                    if htparam:
                        serv = htparam.fdecimal / 100

                if artikel.mwst_code != 0:

                    htparam = db_session.query(Htparam).filter(
                            (Htparam.paramnr == artikel.mwst_code)).first()

                    if htparam:
                        vat = htparam.fdecimal / 100

                    if serv_vat:
                        vat = vat + vat * serv

                if (artikel.artnr == vat_artnr[0] or artikel.artnr == vat_artnr[1] or artikel.artnr == vat_artnr[2] or artikel.artnr == vat_artnr[3] or artikel.artnr == vat_artnr[4]) and artikel.departement == 0:
                    fact = 1
                    vat = 1
                    serv = 0
                else:
                    fact = 1.00 + serv + vat
                t_vat = t_vat + bill_line.betrag / fact * vat


        return generate_inner_output()

    def cal_spvat():

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        t_vat = 0
        vat:decimal = 0
        serv:decimal = 0
        fact:decimal = 0

        def generate_inner_output():
            return t_vat

        for t_spbill_list in query(t_spbill_list_list, filters=(lambda t_spbill_list :t_spbill_list.selected)):
            bill_line = db_session.query(Bill_line).filter((Bill_line._recid == t_spbill_list.bl_recid) &  (Bill_line.rechnr == rechnr)).first()
            if not bill_line:
                continue

            artikel = db_session.query(Artikel).filter((Artikel.artnr == bill_line.artnr) &  (Artikel.departement == bill_line.departement) &  (Artikel.artart != 2) &  (Artikel.artart != 4) &  (Artikel.artart != 6) &  (Artikel.artart != 7)).first()
            if not artikel:
                continue

            serv = 0
            vat = 0

            if bill_line.orts_tax != 0:
                t_vat = t_vat + bill_line.orts_tax
            else:

                if artikel.service_code != 0 and serv_vat:

                    htparam = db_session.query(Htparam).filter(
                            (Htparam.paramnr == artikel.service_code)).first()

                    if htparam:
                        serv = htparam.fdecimal / 100

                if artikel.mwst_code != 0:

                    htparam = db_session.query(Htparam).filter(
                            (Htparam.paramnr == artikel.mwst_code)).first()

                    if htparam:
                        vat = htparam.fdecimal / 100

                    if serv_vat:
                        vat = vat + vat * serv

                if (artikel.artnr == vat_artnr[0] or artikel.artnr == vat_artnr[1] or artikel.artnr == vat_artnr[2] or artikel.artnr == vat_artnr[3] or artikel.artnr == vat_artnr[4]) and artikel.departement == 0:
                    fact = 1
                    vat = 1
                    serv = 0
                else:
                    fact = 1.00 + serv + vat
                t_vat = t_vat + bill_line.betrag / fact * vat


        return generate_inner_output()

    def do_billlinea():

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        n:int = 0
        saldo:decimal = 0
        paidout:int = 0

        htparam = db_session.query(Htparam).filter(
                (Htparam.paramnr == 242)).first()
        paidout = htparam.finteger
        bl_balance = 0
        bl_balance1 = 0
        bline_list_list.clear()

        for bill_line in db_session.query(Bill_line).filter(
                (Bill_line.rechnr == rechnr)).all():

            artikel = db_session.query(Artikel).filter(
                    (Artikel.artnr == bill_line.artnr) &  (Artikel.departement == bill_line.departement)).first()

            if not artikel:

                artikel = db_session.query(Artikel).filter(
                        (Artikel.artnr == bill_line.artnr) &  (Artikel.departement == 0)).first()

            bline_list = query(bline_list_list, filters=(lambda bline_list :bline_list.artnr == bill_line.artnr and bline_list.dept == bill_line.departement and bline_list.bezeich == bill_line.bezeich and bline_list.datum == bill_line.bill_datum and bline_list.saldo == - bill_line.betrag), first=True)

            if bline_list:
                bline_list_list.remove(bline_list)
            else:
                bline_list = Bline_list()
                bline_list_list.append(bline_list)

                buffer_copy(bill_line, bline_list)
                bline_list.bl_recid = bill_line._recid
                bline_list.dept = bill_line.departement
                bline_list.datum = bill_line.bill_datum
                bline_list.fsaldo = bill_line.fremdwbetrag
                bline_list.saldo = bill_line.betrag

            if (artikel.artart == 0 or artikel.artart == 1 or artikel.artart == 8 or artikel.artart == 9):
                bl0_balance = bl0_balance + bill_line.betrag

            elif artikel.artart == 6 and artikel.zwkum == paidout:
                bl0_balance = bl0_balance + bill_line.betrag
        bline_nr = 0

        bill_line_obj_list = []
        for bill_line, bline_list in db_session.query(Bill_line, Bline_list).join(Bline_list,(Bline_list.bl_recid == to_int(Bill_line._recid))).filter(
                (Bill_line.rechnr == rechnr)).all():
            if bill_line._recid in bill_line_obj_list:
                continue
            else:
                bill_line_obj_list.append(bill_line._recid)


            bline_nr = bline_nr + 1
            bl_balance = bl_balance + bill_line.betrag
            bl_balance1 = bl_balance1 + bill_line.fremdwbetrag
            saldo = saldo + bill_line.betrag

            if curr_line >= printer.pglen:
                output_list.str = output_list.str + ""


                output_list = Output_list()
                output_list_list.append(output_list)

                curr_page = curr_page + 1
                curr_line = 1
                do_billhead()

            for loop_list in query(loop_list_list):
                curr_pos = 1

                if f_lmargin:
                    for n in range(1,lmargin + 1) :
                        put_string(" ")
                build_loop_line(loop_list.texte)
                output_list.str = output_list.str + ""


                output_list = Output_list()
                output_list_list.append(output_list)

                curr_line = curr_line + 1

        if f_bill:

            bill = db_session.query(Bill).filter(
                    (Bill.rechnr == rechnr)).first()
            bl_balance = bill.saldo

        if (bl_balance - saldo) >= 0.5 or (saldo - bl_balance) >= 0.5:
            pass
        loop_list_list.clear()
        blloop = 0

    def do_billlineb():

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        n:int = 0
        s_bezeich:str = ""
        netto:decimal = 0
        curr_bl_vat:decimal = 0
        paidout:int = 0
        vat_perc:decimal = 0
        vatcode:int = 0
        Foart = Artikel

        htparam = db_session.query(Htparam).filter(
                (Htparam.paramnr == 242)).first()
        paidout = htparam.finteger
        bl0_balance = 0
        bl0_balance1 = 0
        bline_list_list.clear()

        bill_line_obj_list = []
        for bill_line, artikel in db_session.query(Bill_line, Artikel).join(Artikel,(Artikel.artnr == Bill_line.artnr) &  (Artikel.departement == Bill_line.departement) &  ((Artikel.artart == 0) |  (Artikel.artart == 1) |  (Artikel.artart == 8) |  (Artikel.artart == 9) |  ((Artikel.artart == 6) &  (Artikel.zwkum == paidout)))).filter(
                (Bill_line.rechnr == rechnr)).all():
            if bill_line._recid in bill_line_obj_list:
                continue
            else:
                bill_line_obj_list.append(bill_line._recid)

            if bill_line.origin_id != "":
                vat% = get_vat(bill_line.origin_id)
                vatcode = 0

                if vat% == 1000:
                    vat% = 0
                    curr_bl_vat = 0


                else:
                    curr_bl_vat = vat%

                    htparam = db_session.query(Htparam).filter(
                            (Htparam.fdecimal == vat%)).first()

                    if htparam:
                        vatcode = htparam.paramnr

                bline_list = query(bline_list_list, filters=(lambda bline_list :bline_list.vatProz == vat%), first=True)

                if not bline_list:
                    bline_list = Bline_list()
                    bline_list_list.append(bline_list)

                    buffer_copy(bill_line, bline_list,except_fields=["bill_line.orts_tax","bill_line.anzahl"])
                    bline_list.bl_recid = bill_line._recid
                    bline_list.dept = bill_line.departement
                    bline_list.zinr = bill.zinr
                    bline_list.mwst_code = vatcode
                    bline_list.vatproz = vat%


                bline_list.fsaldo = bline_list.fsaldo + bill_line.fremdwbetrag
                bline_list.saldo = bline_list.saldo + bill_line.betrag
                bl0_balance = bl0_balance + bill_line.betrag
                bl0_balance1 = bl0_balance1 + bill_line.fremdwbetrag

                if bill_line.orts_tax != 0:
                    netto = bill_line.betrag - bill_line.orts_tax
                else:
                    netto = bill_line.betrag / (1 + curr_bl_vat / 100)
                    netto = round(netto, price_decimal)


                bline_list.netto = bline_list.netto + netto
            else:

                bline_list = query(bline_list_list, filters=(lambda bline_list :bline_list.mwst_code == artikel.mwst_code), first=True)

                if not bline_list:
                    bline_list = Bline_list()
                    bline_list_list.append(bline_list)

                    buffer_copy(bill_line, bline_list,except_fields=["bill_line.orts_tax","bill_line.anzahl"])
                    bline_list.bl_recid = bill_line._recid
                    bline_list.dept = bill_line.departement
                    bline_list.zinr = bill.zinr
                    bline_list.mwst_code = artikel.mwst_code


                bline_list.fsaldo = bline_list.fsaldo + bill_line.fremdwbetrag
                bline_list.saldo = bline_list.saldo + bill_line.betrag
                bl0_balance = bl0_balance + bill_line.betrag
                bl0_balance1 = bl0_balance1 + bill_line.fremdwbetrag

                if (artikel.artnr == vat_artnr[0] or artikel.artnr == vat_artnr[1] or artikel.artnr == vat_artnr[2] or artikel.artnr == vat_artnr[3] or artikel.artnr == vat_artnr[4]) and artikel.departement == 0:
                    1
                else:

                    foart = db_session.query(Foart).filter(
                            (Foart.artnr == bill_line.artnr) &  (Foart.departement == bill_line.departement)).first()

                    if foart:

                        htparam = db_session.query(Htparam).filter(
                                (Htparam.paramnr == foart.mwst_code)).first()

                        if htparam:
                            curr_bl_vat = htparam.fdecimal
                            bline_list.vatproz = curr_bl_vat


                        else:
                            curr_bl_vat = 0

                    if bill_line.orts_tax != 0:
                        netto = bill_line.betrag - bill_line.orts_tax
                    else:
                        netto = bill_line.betrag / (1 + curr_bl_vat / 100)
                        netto = round (netto, price_decimal)


                    bline_list.netto = bline_list.netto + netto
        bline_nr = 0

        for bline_list in query(bline_list_list):
            bline_nr = bline_nr + 1
            bl_balance = bl_balance + bline_list.saldo
            bl_balance1 = bl_balance1 + bline_list.fsaldo

            if curr_line >= printer.pglen:
                output_list.str = output_list.str + ""


                output_list = Output_list()
                output_list_list.append(output_list)

                curr_page = curr_page + 1
                curr_line = 1
                do_billhead()

            for loop_list in query(loop_list_list):
                curr_pos = 1

                if f_lmargin:
                    for n in range(1,lmargin + 1) :
                        put_string(" ")
                build_loop_line(loop_list.texte)
                output_list.str = output_list.str + ""


                output_list = Output_list()
                output_list_list.append(output_list)

                curr_line = curr_line + 1
        loop_list_list.clear()
        blloop = 0

    def do_billlinec():

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        n:int = 0
        saldo:decimal = 0
        descript:str = ""
        paidout:int = 0
        Resline = Res_line
        Rline = Res_line

        htparam = db_session.query(Htparam).filter(
                (Htparam.paramnr == 242)).first()
        paidout = htparam.finteger
        bl0_balance = 0
        bl_balance = 0
        bl_balance1 = 0
        bline_list_list.clear()

        bill_line_obj_list = []
        for bill_line, artikel in db_session.query(Bill_line, Artikel).join(Artikel,(Artikel.artnr == Bill_line.artnr) &  (Artikel.departement == Bill_line.departement) &  ((Artikel.artart == 0) |  (Artikel.artart == 1) |  (Artikel.artart == 8) |  (Artikel.artart == 9))).filter(
                (Bill_line.rechnr == rechnr)).all():
            if bill_line._recid in bill_line_obj_list:
                continue
            else:
                bill_line_obj_list.append(bill_line._recid)

            if inv_type == 3:

                if artikel.bezaendern or artikel.artart == 1:

                    bline_list = query(bline_list_list, filters=(lambda bline_list :bline_list.artnr == bill_line.artnr and bline_list.dept == bill_line.departement and bline_list.bezeich == bill_line.bezeich), first=True)
                else:

                    bline_list = query(bline_list_list, filters=(lambda bline_list :bline_list.artnr == bill_line.artnr and bline_list.dept == bill_line.departement), first=True)

            elif inv_type == 4:

                if artikel.bezaendern or artikel.artart == 1:

                    bline_list = query(bline_list_list, filters=(lambda bline_list :bline_list.artnr == bill_line.artnr and bline_list.dept == bill_line.departement and bline_list.bezeich == bill_line.bezeich and bline_list.zinr == bill_line.zinr), first=True)
                else:

                    bline_list = query(bline_list_list, filters=(lambda bline_list :bline_list.artnr == bill_line.artnr and bline_list.dept == bill_line.departement and bline_list.zinr == bill_line.zinr), first=True)

            if not bline_list:

                mainres = db_session.query(Mainres).filter(
                        (Mainres.resnr == bill_line.massnr)).first()

                resline = db_session.query(Resline).filter(
                        (Resline.resnr == bill_line.massnr) &  (Resline.reslinnr == bill_line.billin_nr)).first()

                if resline and resline.zimmerfix:

                    rline = db_session.query(Rline).filter(
                            (Rline.resnr == resline.resnr) &  (Rline.zinr == resline.zinr) &  (not Rline.zimmerfix)).first()

                    if rline:

                        resline = db_session.query(Resline).filter(
                                (Resline._recid == rline._recid)).first()

                if not resline:

                    resline = db_session.query(Resline).filter(
                            (Resline.resnr == bill.resnr) &  (Resline.zinr == bill_line.zinr) &  (Resline.resstatus != 12) &  (Resline.resstatus != 9) &  (Resline.resstatus != 10)).first()
                bline_list = Bline_list()
                bline_list_list.append(bline_list)

                buffer_copy(bill_line, bline_list,except_fields=["bill_line.orts_tax","bill_line.anzahl"])
                bline_list.bl_recid = bill_line._recid
                bline_list.dept = bill_line.departement
                bline_list.datum = bill_line.bill_datum

                if resline:
                    bline_list.gname = resline.name

                if mainres:
                    bline_list.voucher = mainres.vesrdepot
            bline_list.orts_tax = bline_list.orts_tax + bill_line.orts_tax
            bline_list.anzahl = bline_list.anzahl + bill_line.anzahl
            bline_list.saldo = bline_list.saldo + bill_line.betrag
            bline_list.fsaldo = bline_list.fsaldo + bill_line.fremdwbetrag
            bl0_balance = bl0_balance + bill_line.betrag

        bill_line_obj_list = []
        for bill_line, artikel in db_session.query(Bill_line, Artikel).join(Artikel,(Artikel.artnr == Bill_line.artnr) &  (Artikel.departement == Bill_line.departement) &  ((Artikel.artart == 2) |  (Artikel.artart == 5) |  (Artikel.artart == 6) |  (Artikel.artart == 7))).filter(
                (Bill_line.rechnr == rechnr)).all():
            if bill_line._recid in bill_line_obj_list:
                continue
            else:
                bill_line_obj_list.append(bill_line._recid)

            bline_list = query(bline_list_list, filters=(lambda bline_list :bline_list.artnr == bill_line.artnr and bline_list.dept == bill_line.departement and bline_list.bezeich == bill_line.bezeich), first=True)

            if not bline_list:
                bline_list = Bline_list()
                bline_list_list.append(bline_list)

                buffer_copy(bill_line, bline_list,except_fields=["bill_line.orts_tax","bill_line.anzahl"])
                bline_list.bl_recid = bill_line._recid


            bline_list.saldo = bline_list.saldo + bill_line.betrag
            bline_list.dept = bill_line.departement
            bline_list.fsaldo = bline_list.fsaldo + bill_line.fremdwbetrag

            if artikel.zwkum == paidout:
                bl0_balance = bl0_balance + bill_line.betrag

        for bline_list in query(bline_list_list, filters=(lambda bline_list :bline_list.saldo == 0)):
            bline_list_list.remove(bline_list)
        bline_nr = 0

        for bline_list in query(bline_list_list):
            bline_nr = bline_nr + 1
            bl_balance = bl_balance + bline_list.saldo
            bl_balance1 = bl_balance1 + bline_list.fsaldo
            saldo = saldo + bline_list.saldo

            if curr_line >= printer.pglen:
                output_list.str = output_list.str + ""


                output_list = Output_list()
                output_list_list.append(output_list)

                curr_page = curr_page + 1
                curr_line = 1
                do_billhead()

            for loop_list in query(loop_list_list):
                curr_pos = 1

                if f_lmargin:
                    for n in range(1,lmargin + 1) :
                        put_string(" ")
                build_loop_line(loop_list.texte)
                output_list.str = output_list.str + ""


                output_list = Output_list()
                output_list_list.append(output_list)

                curr_line = curr_line + 1

        if f_bill:

            bill = db_session.query(Bill).filter(
                    (Bill.rechnr == rechnr)).first()
            bl_balance = bill.saldo

        if (bl_balance - saldo) >= 0.5 or (saldo - bl_balance) >= 0.5:
            pass
        loop_list_list.clear()
        blloop = 0

    def do_spbillline():

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        n:int = 0
        saldo:decimal = 0
        bl_balance = 0
        bl_balance1 = 0
        bline_list_list.clear()

        for t_spbill_list in query(t_spbill_list_list, filters=(lambda t_spbill_list :t_spbill_list.selected)):
            bill_line = db_session.query(Bill_line).filter((Bill_line._recid == t_spbill_list.bl_recid) &  (Bill_line.rechnr == rechnr)).first()
            if not bill_line:
                continue


            bline_list = query(bline_list_list, filters=(lambda bline_list :bline_list.artnr == bill_line.artnr and bline_list.dept == bill_line.departement and bline_list.bezeich == bill_line.bezeich and bline_list.datum == bill_line.bill_datum and bline_list.saldo == - bill_line.betrag), first=True)

            if bline_list:
                bline_list_list.remove(bline_list)
            else:
                bline_list = Bline_list()
                bline_list_list.append(bline_list)

                buffer_copy(bill_line, bline_list)
                bline_list.bl_recid = bill_line._recid
                bline_list.datum = bill_line.bill_datum
                bline_list.dept = bill_line.departement
                bline_list.fsaldo = bill_line.fremdwbetrag
                bline_list.saldo = bill_line.betrag


        bline_nr = 0

        bill_line_obj_list = []
        for bill_line, bline_list in db_session.query(Bill_line, Bline_list).join(Bline_list,(Bline_list.bl_recid == to_int(Bill_line._recid))).filter(
                (Bill_line.rechnr == rechnr)).all():
            if bill_line._recid in bill_line_obj_list:
                continue
            else:
                bill_line_obj_list.append(bill_line._recid)


            bline_nr = bline_nr + 1
            bl_balance = bl_balance + bill_line.betrag
            bl_balance1 = bl_balance1 + bill_line.fremdwbetrag
            saldo = saldo + bill_line.betrag

            if curr_line >= printer.pglen:
                output_list.str = output_list.str + ""


                output_list = Output_list()
                output_list_list.append(output_list)

                curr_page = curr_page + 1
                curr_line = 1
                do_billhead()

            for loop_list in query(loop_list_list):
                curr_pos = 1

                if f_lmargin:
                    for n in range(1,lmargin + 1) :
                        put_string(" ")
                build_loop_line(loop_list.texte)
                output_list.str = output_list.str + ""


                output_list = Output_list()
                output_list_list.append(output_list)

                curr_line = curr_line + 1

        if f_bill:

            bill = db_session.query(Bill).filter(
                    (Bill.rechnr == rechnr)).first()

            if not spbill_flag:
                bl_balance = bill.saldo

        if ((bl_balance - saldo) >= 0.5 or (saldo - bl_balance) >= 0.5) and not spbill_flag:
            pass
        loop_list_list.clear()
        blloop = 0

    def do_billline0():

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        n:int = 0
        paidout:int = 0
        Resline = Res_line

        htparam = db_session.query(Htparam).filter(
                (Htparam.paramnr == 242)).first()
        paidout = htparam.finteger
        bl0_balance = 0
        bl0_balance1 = 0
        bl_balance = 0
        bl_balance1 = 0
        bline_list_list.clear()

        bill_line_obj_list = []
        for bill_line, artikel in db_session.query(Bill_line, Artikel).join(Artikel,(Artikel.artnr == Bill_line.artnr) &  (Artikel.departement == Bill_line.departement) &  ((Artikel.artart == 0) |  (Artikel.artart == 1) |  (Artikel.artart == 8) |  (Artikel.artart == 9) |  ((Artikel.artart == 6) &  (Artikel.zwkum == paidout)))).filter(
                (Bill_line.rechnr == rechnr)).all():
            if bill_line._recid in bill_line_obj_list:
                continue
            else:
                bill_line_obj_list.append(bill_line._recid)

            bline_list = query(bline_list_list, filters=(lambda bline_list :bline_list.artnr == bill_line.artnr and bline_list.dept == bill_line.departement and bline_list.bezeich == bill_line.bezeich and bline_list.datum == bill_line.bill_datum and bline_list.saldo == - bill_line.betrag), first=True)

            if bline_list:
                bline_list_list.remove(bline_list)
            else:

                mainres = db_session.query(Mainres).filter(
                        (Mainres.resnr == bill_line.massnr)).first()

                resline = db_session.query(Resline).filter(
                        (Resline.resnr == bill_line.massnr) &  (Resline.reslinnr == bill_line.billin_nr)).first()

                if not resline:

                    resline = db_session.query(Resline).filter(
                            (Resline.resnr == bill.resnr) &  (Resline.zinr == bill_line.zinr) &  (Resline.resstatus != 12) &  (Resline.resstatus != 9) &  (Resline.resstatus != 10) &  (Resline.resstatus != 99)).first()
                bline_list = Bline_list()
                bline_list_list.append(bline_list)

                buffer_copy(bill_line, bline_list)
                bline_list.bl_recid = bill_line._recid
                bline_list.datum = bill_line.bill_datum
                bline_list.dept = bill_line.departement
                bline_list.fsaldo = bill_line.fremdwbetrag
                bline_list.saldo = bill_line.betrag

                if resline:
                    bline_list.gname = resline.name

                if mainres:
                    bline_list.voucher = mainres.vesrdepot
        bline_nr = 0

        bill_line_obj_list = []
        for bill_line, artikel, bline_list in db_session.query(Bill_line, Artikel, Bline_list).join(Artikel,(Artikel.artnr == Bill_line.artnr) &  (Artikel.departement == Bill_line.departement) &  ((Artikel.artart == 0) |  (Artikel.artart == 1) |  (Artikel.artart == 8) |  (Artikel.artart == 9) |  ((Artikel.artart == 6) &  (Artikel.zwkum == paidout)))).join(Bline_list,(Bline_list.bl_recid == to_int(Bill_line._recid))).filter(
                (Bill_line.rechnr == rechnr)).all():
            if bill_line._recid in bill_line_obj_list:
                continue
            else:
                bill_line_obj_list.append(bill_line._recid)


            bline_nr = bline_nr + 1
            bl0_balance = bl0_balance + bill_line.betrag
            bl0_balance1 = bl0_balance1 + bill_line.fremdwbetrag
            bl_balance = bl_balance + bill_line.betrag
            bl_balance1 = bl_balance1 + bill_line.fremdwbetrag

            if curr_line >= printer.pglen:
                output_list.str = output_list.str + ""


                output_list = Output_list()
                output_list_list.append(output_list)

                curr_page = curr_page + 1
                curr_line = 1
                do_billhead()

            for loop_list in query(loop_list_list):
                curr_pos = 1

                if f_lmargin:
                    for n in range(1,lmargin + 1) :
                        put_string(" ")
                build_loop_line(loop_list.texte)
                output_list.str = output_list.str + ""


                output_list = Output_list()
                output_list_list.append(output_list)

                curr_line = curr_line + 1
        loop_list_list.clear()
        blloop = 0

    def do_billline0c():

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        n:int = 0
        paidout:int = 0
        Resline = Res_line
        Rline = Res_line

        htparam = db_session.query(Htparam).filter(
                (Htparam.paramnr == 242)).first()
        paidout = htparam.finteger
        bl0_balance = 0
        bl0_balance1 = 0
        bline_list_list.clear()

        bill_line_obj_list = []
        for bill_line, artikel in db_session.query(Bill_line, Artikel).join(Artikel,(Artikel.artnr == Bill_line.artnr) &  (Artikel.departement == Bill_line.departement) &  ((Artikel.artart == 0) |  (Artikel.artart == 1) |  (Artikel.artart == 8) |  (Artikel.artart == 9) |  ((Artikel.artart == 6) &  (Artikel.zwkum == paidout)))).filter(
                (Bill_line.rechnr == rechnr)).all():
            if bill_line._recid in bill_line_obj_list:
                continue
            else:
                bill_line_obj_list.append(bill_line._recid)

            if inv_type == 3:

                if artikel.bezaendern or artikel.artart == 1:

                    bline_list = query(bline_list_list, filters=(lambda bline_list :bline_list.artnr == bill_line.artnr and bline_list.dept == bill_line.departement and bline_list.bezeich == bill_line.bezeich), first=True)
                else:

                    bline_list = query(bline_list_list, filters=(lambda bline_list :bline_list.artnr == bill_line.artnr and bline_list.dept == bill_line.departement), first=True)

            elif inv_type == 4:

                if artikel.bezaendern or artikel.artart == 1:

                    bline_list = query(bline_list_list, filters=(lambda bline_list :bline_list.artnr == bill_line.artnr and bline_list.dept == bill_line.departement and bline_list.bezeich == bill_line.bezeich and bline_list.zinr == bill_line.zinr), first=True)
                else:

                    bline_list = query(bline_list_list, filters=(lambda bline_list :bline_list.artnr == bill_line.artnr and bline_list.dept == bill_line.departement and bline_list.zinr == bill_line.zinr), first=True)

            if not bline_list:

                mainres = db_session.query(Mainres).filter(
                        (Mainres.resnr == bill_line.massnr)).first()

                resline = db_session.query(Resline).filter(
                        (Resline.resnr == bill_line.massnr) &  (Resline.reslinnr == bill_line.billin_nr)).first()

                if resline and resline.zimmerfix:

                    rline = db_session.query(Rline).filter(
                            (Rline.resnr == resline.resnr) &  (Rline.zinr == resline.zinr) &  (not Rline.zimmerfix)).first()

                    if rline:

                        resline = db_session.query(Resline).filter(
                                (Resline._recid == rline._recid)).first()

                if not resline:

                    resline = db_session.query(Resline).filter(
                            (Resline.resnr == bill.resnr) &  (Resline.zinr == bill_line.zinr) &  (Resline.resstatus != 12) &  (Resline.resstatus != 9) &  (Resline.resstatus != 10) &  (Resline.resstatus != 99) &  (Resline.l_zuordnung[2] == 0)).first()
                bline_list = Bline_list()
                bline_list_list.append(bline_list)

                buffer_copy(bill_line, bline_list,except_fields=["bill_line.orts_tax","bill_line.anzahl"])
                bline_list.bl_recid = bill_line._recid
                bline_list.dept = bill_line.departement
                bline_list.datum = bill_line.bill_datum

                if resline:
                    bline_list.gname = resline.name

                if mainres:
                    bline_list.voucher = mainres.vesrdepot
            bline_list.orts_tax = bline_list.orts_tax + bill_line.orts_tax
            bline_list.anzahl = bline_list.anzahl + bill_line.anzahl
            bline_list.saldo = bline_list.saldo + bill_line.betrag
            bline_list.fsaldo = bline_list.fsaldo + bill_line.fremdwbetrag

        for bline_list in query(bline_list_list, filters=(lambda bline_list :bline_list.saldo == 0)):
            bline_list_list.remove(bline_list)
        bline_nr = 0

        for bline_list in query(bline_list_list):
            bline_nr = bline_nr + 1
            bl0_balance = bl0_balance + bline_list.saldo
            bl0_balance1 = bl0_balance1 + bline_list.fsaldo

            if curr_line >= printer.pglen:
                output_list.str = output_list.str + ""


                output_list = Output_list()
                output_list_list.append(output_list)

                curr_page = curr_page + 1
                curr_line = 1
                do_billhead()

            for loop_list in query(loop_list_list):
                curr_pos = 1

                if f_lmargin:
                    for n in range(1,lmargin + 1) :
                        put_string(" ")
                build_loop_line(loop_list.texte)
                output_list.str = output_list.str + ""


                output_list = Output_list()
                output_list_list.append(output_list)

                curr_line = curr_line + 1
        loop_list_list.clear()
        blloop = 0

    def do_spbillline0():

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        n:int = 0
        paidout:int = 0
        Resline = Res_line

        htparam = db_session.query(Htparam).filter(
                (Htparam.paramnr == 242)).first()
        paidout = htparam.finteger
        bl0_balance = 0
        bl0_balance1 = 0
        bline_list_list.clear()

        for t_spbill_list in query(t_spbill_list_list, filters=(lambda t_spbill_list :t_spbill_list.selected)):
            bill_line = db_session.query(Bill_line).filter((Bill_line._recid == t_spbill_list.bl_recid) &  (Bill_line.rechnr == rechnr)).first()
            if not bill_line:
                continue

            artikel = db_session.query(Artikel).filter((Artikel.artnr == bill_line.artnr) &  (Artikel.departement == bill_line.departement) &  ((Artikel.artart == 0) |  (Artikel.artart == 1) |  (Artikel.artart == 8) |  (Artikel.artart == 9) |  ((Artikel.artart == 6) &  (Artikel.zwkum == paidout)))).first()
            if not artikel:
                continue


            bline_list = query(bline_list_list, filters=(lambda bline_list :bline_list.artnr == bill_line.artnr and bline_list.dept == bill_line.departement and bline_list.bezeich == bill_line.bezeich and bline_list.datum == bill_line.bill_datum and bline_list.saldo == - bill_line.betrag), first=True)

            if bline_list:
                bline_list_list.remove(bline_list)
            else:

                mainres = db_session.query(Mainres).filter(
                        (Mainres.resnr == bill_line.massnr)).first()

                resline = db_session.query(Resline).filter(
                        (Resline.resnr == bill_line.massnr) &  (Resline.reslinnr == bill_line.billin_nr)).first()

                if not resline:

                    resline = db_session.query(Resline).filter(
                            (Resline.resnr == bill.resnr) &  (Resline.zinr == bill_line.zinr) &  (Resline.resstatus != 12) &  (Resline.resstatus != 9) &  (Resline.resstatus != 10) &  (Resline.resstatus != 99)).first()
                bline_list = Bline_list()
                bline_list_list.append(bline_list)

                buffer_copy(bill_line, bline_list)
                bline_list.bl_recid = bill_line._recid
                bline_list.datum = bill_line.bill_datum
                bline_list.dept = bill_line.departement
                bline_list.fsaldo = bill_line.fremdwbetrag
                bline_list.saldo = bill_line.betrag

                if resline:
                    bline_list.gname = resline.name

                if mainres:
                    bline_list.voucher = mainres.vesrdepot
        bline_nr = 0

        if inv_type == 4:

            bill_line_obj_list = []
            for bill_line, artikel, bline_list in db_session.query(Bill_line, Artikel, Bline_list).join(Artikel,(Artikel.artnr == Bill_line.artnr) &  (Artikel.departement == Bill_line.departement) &  ((Artikel.artart == 0) |  (Artikel.artart == 1) |  (Artikel.artart == 8) |  (Artikel.artart == 9) |  ((Artikel.artart == 6) &  (Artikel.zwkum == paidout)))).join(Bline_list,(Bline_list.bl_recid == to_int(Bill_line._recid))).filter(
                    (Bill_line.rechnr == rechnr)).all():
                if bill_line._recid in bill_line_obj_list:
                    continue
                else:
                    bill_line_obj_list.append(bill_line._recid)


                bline_nr = bline_nr + 1
                bl0_balance = bl0_balance + bill_line.betrag
                bl0_balance1 = bl0_balance1 + bill_line.fremdwbetrag
                bl_balance = bl_balance + bill_line.betrag
                bl_balance1 = bl_balance1 + bill_line.fremdwbetrag

                if curr_line >= printer.pglen:
                    output_list.str = output_list.str + ""


                    output_list = Output_list()
                    output_list_list.append(output_list)

                    curr_page = curr_page + 1
                    curr_line = 1
                    do_billhead()

                for loop_list in query(loop_list_list):
                    curr_pos = 1

                    if f_lmargin:
                        for n in range(1,lmargin + 1) :
                            put_string(" ")
                    build_loop_line(loop_list.texte)
                    output_list.str = output_list.str + ""


                    output_list = Output_list()
                    output_list_list.append(output_list)

                    curr_line = curr_line + 1

        else:

            bill_line_obj_list = []
            for bill_line, artikel, bline_list in db_session.query(Bill_line, Artikel, Bline_list).join(Artikel,(Artikel.artnr == Bill_line.artnr) &  (Artikel.departement == Bill_line.departement) &  ((Artikel.artart == 0) |  (Artikel.artart == 1) |  (Artikel.artart == 8) |  (Artikel.artart == 9) |  ((Artikel.artart == 6) &  (Artikel.zwkum == paidout)))).join(Bline_list,(Bline_list.bl_recid == to_int(Bill_line._recid))).filter(
                    (Bill_line.rechnr == rechnr)).all():
                if bill_line._recid in bill_line_obj_list:
                    continue
                else:
                    bill_line_obj_list.append(bill_line._recid)


                bline_nr = bline_nr + 1
                bl0_balance = bl0_balance + bill_line.betrag
                bl0_balance1 = bl0_balance1 + bill_line.fremdwbetrag
                bl_balance = bl_balance + bill_line.betrag
                bl_balance1 = bl_balance1 + bill_line.fremdwbetrag

                if curr_line >= printer.pglen:
                    output_list.str = output_list.str + ""


                    output_list = Output_list()
                    output_list_list.append(output_list)

                    curr_page = curr_page + 1
                    curr_line = 1
                    do_billhead()

                for loop_list in query(loop_list_list):
                    curr_pos = 1

                    if f_lmargin:
                        for n in range(1,lmargin + 1) :
                            put_string(" ")
                    build_loop_line(loop_list.texte)
                    output_list.str = output_list.str + ""


                    output_list = Output_list()
                    output_list_list.append(output_list)

                    curr_line = curr_line + 1

        loop_list_list.clear()
        blloop = 0

    def do_spbillline0b():

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        n:int = 0
        s_bezeich:str = ""
        netto:decimal = 0
        curr_bl_vat:decimal = 0
        paidout:int = 0
        Foart = Artikel

        htparam = db_session.query(Htparam).filter(
                (Htparam.paramnr == 242)).first()
        paidout = htparam.finteger
        bl0_balance = 0
        bl0_balance1 = 0
        bline_list_list.clear()

        for t_spbill_list in query(t_spbill_list_list, filters=(lambda t_spbill_list :t_spbill_list.selected)):
            bill_line = db_session.query(Bill_line).filter((Bill_line._recid == t_spbill_list.bl_recid)).first()
            if not bill_line:
                continue

            artikel = db_session.query(Artikel).filter((Artikel.artnr == bill_line.artnr) &  (Artikel.departement == bill_line.departement) &  ((Artikel.artart == 0) |  (Artikel.artart == 1) |  (Artikel.artart == 8) |  (Artikel.artart == 9) |  ((Artikel.artart == 6) &  (Artikel.zwkum == paidout)))).first()
            if not artikel:
                continue


            bline_list = query(bline_list_list, filters=(lambda bline_list :bline_list.mwst_code == artikel.mwst_code), first=True)

            if not bline_list:
                bline_list = Bline_list()
                bline_list_list.append(bline_list)

                buffer_copy(bill_line, bline_list,except_fields=["bill_line.orts_tax","bill_line.anzahl"])
                bline_list.bl_recid = bill_line._recid
                bline_list.dept = bill_line.departement
                bline_list.zinr = bill.zinr
                bline_list.mwst_code = artikel.mwst_code


            bline_list.fsaldo = bline_list.fsaldo + bill_line.fremdwbetrag
            bline_list.saldo = bline_list.saldo + bill_line.betrag
            bl0_balance = bl0_balance + bill_line.betrag
            bl0_balance1 = bl0_balance1 + bill_line.fremdwbetrag

            if (artikel.artnr == vat_artnr[0] or artikel.artnr == vat_artnr[1] or artikel.artnr == vat_artnr[2] or artikel.artnr == vat_artnr[3] or artikel.artnr == vat_artnr[4]) and artikel.departement == 0:
                1
            else:

                foart = db_session.query(Foart).filter(
                        (Foart.artnr == bill_line.artnr) &  (Foart.departement == bill_line.departement)).first()

                if foart:

                    htparam = db_session.query(Htparam).filter(
                            (Htparam.paramnr == foart.mwst_code)).first()

                    if htparam:
                        curr_bl_vat = htparam.fdecimal
                    else:
                        curr_bl_vat = 0

                if bill_line.orts_tax != 0:
                    netto = bill_line.betrag - bill_line.orts_tax
                else:
                    netto = bill_line.betrag / (1 + curr_bl_vat / 100)
                    netto = round (netto, price_decimal)
                bline_list.netto = bline_list.netto + netto
        bline_nr = 0

        if bline_list:
            bline_nr = 1
            bl_balance = bline_list.saldo
            bl_balance1 = bline_list.fsaldo

            if curr_line >= printer.pglen:
                output_list.str = output_list.str + ""


                output_list = Output_list()
                output_list_list.append(output_list)

                curr_page = curr_page + 1
                curr_line = 1
                do_billhead()

            for loop_list in query(loop_list_list):
                curr_pos = 1

                if f_lmargin:
                    for n in range(1,lmargin + 1) :
                        put_string(" ")
                build_loop_line(loop_list.texte)
                output_list.str = output_list.str + ""


                output_list = Output_list()
                output_list_list.append(output_list)

                curr_line = curr_line + 1
        loop_list_list.clear()
        blloop = 0

    def do_spbillline0c():

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        n:int = 0
        paidout:int = 0
        Resline = Res_line
        Rline = Res_line

        htparam = db_session.query(Htparam).filter(
                (Htparam.paramnr == 242)).first()
        paidout = htparam.finteger
        bl0_balance = 0
        bl0_balance1 = 0
        bline_list_list.clear()

        for t_spbill_list in query(t_spbill_list_list, filters=(lambda t_spbill_list :t_spbill_list.selected)):
            bill_line = db_session.query(Bill_line).filter((Bill_line._recid == t_spbill_list.bl_recid)).first()
            if not bill_line:
                continue

            artikel = db_session.query(Artikel).filter((Artikel.artnr == bill_line.artnr) &  (Artikel.departement == bill_line.departement) &  ((Artikel.artart == 0) |  (Artikel.artart == 1) |  (Artikel.artart == 8) |  (Artikel.artart == 9) |  ((Artikel.artart == 6) &  (Artikel.zwkum == paidout)))).first()
            if not artikel:
                continue


            if inv_type == 3:

                if artikel.bezaendern or artikel.artart == 1:

                    bline_list = query(bline_list_list, filters=(lambda bline_list :bline_list.artnr == bill_line.artnr and bline_list.dept == bill_line.departement and bline_list.bezeich == bill_line.bezeich), first=True)
                else:

                    bline_list = query(bline_list_list, filters=(lambda bline_list :bline_list.artnr == bill_line.artnr and bline_list.dept == bill_line.departement), first=True)

            elif inv_type == 4:

                if artikel.bezaendern or artikel.artart == 1:

                    bline_list = query(bline_list_list, filters=(lambda bline_list :bline_list.artnr == bill_line.artnr and bline_list.dept == bill_line.departement and bline_list.bezeich == bill_line.bezeich and bline_list.zinr == bill_line.zinr), first=True)
                else:

                    bline_list = query(bline_list_list, filters=(lambda bline_list :bline_list.artnr == bill_line.artnr and bline_list.dept == bill_line.departement and bline_list.zinr == bill_line.zinr), first=True)

            if not bline_list:

                mainres = db_session.query(Mainres).filter(
                        (Mainres.resnr == bill_line.massnr)).first()

                resline = db_session.query(Resline).filter(
                        (Resline.resnr == bill_line.massnr) &  (Resline.reslinnr == bill_line.billin_nr)).first()

                if resline and resline.zimmerfix:

                    rline = db_session.query(Rline).filter(
                            (Rline.resnr == resline.resnr) &  (Rline.zinr == resline.zinr) &  (not Rline.zimmerfix)).first()

                    if rline:

                        resline = db_session.query(Resline).filter(
                                (Resline._recid == rline._recid)).first()

                if not resline:

                    resline = db_session.query(Resline).filter(
                            (Resline.resnr == bill.resnr) &  (Resline.zinr == bill_line.zinr) &  (Resline.resstatus != 12) &  (Resline.resstatus != 9) &  (Resline.resstatus != 10) &  (Resline.resstatus != 99)).first()
                bline_list = Bline_list()
                bline_list_list.append(bline_list)

                buffer_copy(bill_line, bline_list,except_fields=["bill_line.orts_tax","bill_line.anzahl"])
                bline_list.bl_recid = bill_line._recid
                bline_list.dept = bill_line.departement
                bline_list.datum = bill_line.bill_datum

                if resline:
                    bline_list.gname = resline.name

                if mainres:
                    bline_list.voucher = mainres.vesrdepot
            bline_list.orts_tax = bline_list.orts_tax + bill_line.orts_tax
            bline_list.anzahl = bline_list.anzahl + bill_line.anzahl
            bline_list.saldo = bline_list.saldo + bill_line.betrag
            bline_list.fsaldo = bline_list.fsaldo + bill_line.fremdwbetrag

        for bline_list in query(bline_list_list, filters=(lambda bline_list :bline_list.saldo == 0)):
            bline_list_list.remove(bline_list)
        bline_nr = 0

        for bline_list in query(bline_list_list):
            bline_nr = bline_nr + 1
            bl0_balance = bl0_balance + bline_list.saldo
            bl0_balance1 = bl0_balance1 + bline_list.fsaldo

            if curr_line >= printer.pglen:
                output_list.str = output_list.str + ""


                output_list = Output_list()
                output_list_list.append(output_list)

                curr_page = curr_page + 1
                curr_line = 1
                do_billhead()

            for loop_list in query(loop_list_list):
                curr_pos = 1

                if f_lmargin:
                    for n in range(1,lmargin + 1) :
                        put_string(" ")
                build_loop_line(loop_list.texte)
                output_list.str = output_list.str + ""


                output_list = Output_list()
                output_list_list.append(output_list)

                curr_line = curr_line + 1
        loop_list_list.clear()
        blloop = 0

    def do_billline1():

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        n:int = 0
        paidout:int = 0
        Resline = Res_line

        htparam = db_session.query(Htparam).filter(
                (Htparam.paramnr == 242)).first()
        paidout = htparam.finteger
        bl1_balance = 0
        bl1_balance1 = 0
        bline_list_list.clear()

        bill_line_obj_list = []
        for bill_line, artikel in db_session.query(Bill_line, Artikel).join(Artikel,(Artikel.artnr == Bill_line.artnr) &  (Artikel.departement == 0) &  ((Artikel.artart == 2) |  (Artikel.artart == 5) |  (Artikel.artart == 6) |  (Artikel.artart == 7)) &  (Artikel.zwkum != paidout)).filter(
                (Bill_line.rechnr == rechnr)).all():
            if bill_line._recid in bill_line_obj_list:
                continue
            else:
                bill_line_obj_list.append(bill_line._recid)

            bline_list = query(bline_list_list, filters=(lambda bline_list :bline_list.artnr == bill_line.artnr and bline_list.dept == bill_line.departement and bline_list.bezeich == bill_line.bezeich and bline_list.datum == bill_line.bill_datum and bline_list.saldo == - bill_line.betrag), first=True)

            if bline_list:
                bline_list_list.remove(bline_list)
            else:

                mainres = db_session.query(Mainres).filter(
                        (Mainres.resnr == bill_line.massnr)).first()

                resline = db_session.query(Resline).filter(
                        (Resline.resnr == bill_line.massnr) &  (Resline.reslinnr == bill_line.billin_nr)).first()

                if not resline:

                    resline = db_session.query(Resline).filter(
                            (Resline.resnr == bill.resnr) &  (Resline.zinr == bill_line.zinr) &  (Resline.resstatus != 12) &  (Resline.resstatus != 9) &  (Resline.resstatus != 10) &  (Resline.resstatus != 99)).first()
                bline_list = Bline_list()
                bline_list_list.append(bline_list)

                buffer_copy(bill_line, bline_list,except_fields=["bill_line.orts_tax","bill_line.anzahl"])
                bline_list.bl_recid = bill_line._recid
                bline_list.datum = bill_line.bill_datum
                bline_list.dept = bill_line.departement
                bline_list.saldo = bline_list.saldo + bill_line.betrag
                bline_list.fsaldo = bline_list.fsaldo + bill_line.fremdwbetrag

                if resline:
                    bline_list.gname = resline.name

                if mainres:
                    bline_list.voucher = mainres.vesrdepot

        bill_line_obj_list = []
        for bill_line, artikel, bline_list in db_session.query(Bill_line, Artikel, Bline_list).join(Artikel,(Artikel.artnr == Bill_line.artnr) &  (Artikel.departement == 0) &  ((Artikel.artart == 2) |  (Artikel.artart == 5) |  (Artikel.artart == 6) |  (Artikel.artart == 7)) &  (Artikel.zwkum != paidout)).join(Bline_list,(Bline_list.bl_recid == to_int(Bill_line._recid))).filter(
                (Bill_line.rechnr == rechnr) &  (Bill_line.departement == 0)).all():
            if bill_line._recid in bill_line_obj_list:
                continue
            else:
                bill_line_obj_list.append(bill_line._recid)


            bline_nr = bline_nr + 1
            bl1_balance = bl1_balance + bill_line.betrag
            bl1_balance1 = bl1_balance1 + bill_line.fremdwbetrag
            bl_balance = bl_balance + bill_line.betrag
            bl_balance1 = bl_balance1 + bill_line.fremdwbetrag

            if artikel.zwkum == paidout:
                bl0_balance = bl0_balance + bill_line.betrag

            if curr_line >= printer.pglen:
                output_list.str = output_list.str + ""


                output_list = Output_list()
                output_list_list.append(output_list)

                curr_page = curr_page + 1
                curr_line = 1
                do_billhead()

            for loop_list in query(loop_list_list):
                curr_pos = 1

                if f_lmargin:
                    for n in range(1,lmargin + 1) :
                        put_string(" ")
                build_loop_line(loop_list.texte)
                output_list.str = output_list.str + ""


                output_list = Output_list()
                output_list_list.append(output_list)

                curr_line = curr_line + 1
        loop_list_list.clear()
        blloop = 0

    def do_spbillline1():

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        n:int = 0
        paidout:int = 0
        Resline = Res_line

        htparam = db_session.query(Htparam).filter(
                (Htparam.paramnr == 242)).first()
        paidout = htparam.finteger
        bl1_balance = 0
        bl1_balance1 = 0
        bline_list_list.clear()

        for t_spbill_list in query(t_spbill_list_list, filters=(lambda t_spbill_list :t_spbill_list.selected)):
            bill_line = db_session.query(Bill_line).filter((Bill_line._recid == t_spbill_list.bl_recid) &  (Bill_line.rechnr == rechnr)).first()
            if not bill_line:
                continue

            artikel = db_session.query(Artikel).filter((Artikel.artnr == bill_line.artnr) &  (Artikel.departement == 0) &  ((Artikel.artart == 2) |  (Artikel.artart == 5) |  (Artikel.artart == 6) |  (Artikel.artart == 7)) &  (Artikel.zwkum != paidout)).first()
            if not artikel:
                continue


            bline_list = query(bline_list_list, filters=(lambda bline_list :bline_list.artnr == bill_line.artnr and bline_list.dept == bill_line.departement and bline_list.bezeich == bill_line.bezeich and bline_list.datum == bill_line.bill_datum and bline_list.saldo == - bill_line.betrag), first=True)

            if bline_list:
                bline_list_list.remove(bline_list)
            else:

                mainres = db_session.query(Mainres).filter(
                        (Mainres.resnr == bill_line.massnr)).first()

                resline = db_session.query(Resline).filter(
                        (Resline.resnr == bill_line.massnr) &  (Resline.reslinnr == bill_line.billin_nr)).first()

                if not resline:

                    resline = db_session.query(Resline).filter(
                            (Resline.resnr == bill.resnr) &  (Resline.zinr == bill_line.zinr) &  (Resline.resstatus != 12) &  (Resline.resstatus != 9) &  (Resline.resstatus != 10) &  (Resline.resstatus != 99)).first()
                bline_list = Bline_list()
                bline_list_list.append(bline_list)

                buffer_copy(bill_line, bline_list,except_fields=["bill_line.orts_tax","bill_line.anzahl"])
                bline_list.bl_recid = bill_line._recid
                bline_list.datum = bill_line.bill_datum
                bline_list.dept = bill_line.departement
                bline_list.saldo = bline_list.saldo + bill_line.betrag
                bline_list.fsaldo = bline_list.fsaldo + bill_line.fremdwbetrag

                if resline:
                    bline_list.gname = resline.name

                if mainres:
                    bline_list.voucher = mainres.vesrdepot

        bill_line_obj_list = []
        for bill_line, artikel, bline_list in db_session.query(Bill_line, Artikel, Bline_list).join(Artikel,(Artikel.artnr == Bill_line.artnr) &  (Artikel.departement == 0) &  ((Artikel.artart == 2) |  (Artikel.artart == 5) |  (Artikel.artart == 6) |  (Artikel.artart == 7)) &  (Artikel.zwkum != paidout)).join(Bline_list,(Bline_list.bl_recid == to_int(Bill_line._recid))).filter(
                (Bill_line.rechnr == rechnr) &  (Bill_line.departement == 0)).all():
            if bill_line._recid in bill_line_obj_list:
                continue
            else:
                bill_line_obj_list.append(bill_line._recid)


            bline_nr = bline_nr + 1
            bl1_balance = bl1_balance + bill_line.betrag
            bl1_balance1 = bl1_balance1 + bill_line.fremdwbetrag
            bl_balance = bl_balance + bill_line.betrag
            bl_balance1 = bl_balance1 + bill_line.fremdwbetrag

            if artikel.zwkum == paidout:
                bl0_balance = bl0_balance + bill_line.betrag

            if curr_line >= printer.pglen:
                output_list.str = output_list.str + ""


                output_list = Output_list()
                output_list_list.append(output_list)

                curr_page = curr_page + 1
                curr_line = 1
                do_billhead()

            for loop_list in query(loop_list_list):
                curr_pos = 1

                if f_lmargin:
                    for n in range(1,lmargin + 1) :
                        put_string(" ")
                build_loop_line(loop_list.texte)
                output_list.str = output_list.str + ""


                output_list = Output_list()
                output_list_list.append(output_list)

                curr_line = curr_line + 1
        loop_list_list.clear()
        blloop = 0

    def do_billline2():

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        n:int = 0
        paidout:int = 0
        Resline = Res_line

        htparam = db_session.query(Htparam).filter(
                (Htparam.paramnr == 242)).first()
        paidout = htparam.finteger
        bl1_balance = 0
        bl1_balance1 = 0
        bline_list_list.clear()

        bill_line_obj_list = []
        for bill_line, artikel in db_session.query(Bill_line, Artikel).join(Artikel,(Artikel.artnr == Bill_line.artnr) &  (Artikel.departement == 0) &  ((Artikel.artart == 6) |  (Artikel.artart == 7)) &  (Artikel.zwkum != paidout)).filter(
                (Bill_line.rechnr == rechnr)).all():
            if bill_line._recid in bill_line_obj_list:
                continue
            else:
                bill_line_obj_list.append(bill_line._recid)

            bline_list = query(bline_list_list, filters=(lambda bline_list :bline_list.artnr == bill_line.artnr and bline_list.dept == bill_line.departement and bline_list.bezeich == bill_line.bezeich and bline_list.datum == bill_line.bill_datum and bline_list.saldo == - bill_line.betrag), first=True)

            if bline_list:
                bline_list_list.remove(bline_list)
            else:

                mainres = db_session.query(Mainres).filter(
                        (Mainres.resnr == bill_line.massnr)).first()

                resline = db_session.query(Resline).filter(
                        (Resline.resnr == bill_line.massnr) &  (Resline.reslinnr == bill_line.billin_nr)).first()

                if not resline:

                    resline = db_session.query(Resline).filter(
                            (Resline.resnr == bill.resnr) &  (Resline.zinr == bill_line.zinr) &  (Resline.resstatus != 12) &  (Resline.resstatus != 9) &  (Resline.resstatus != 10) &  (Resline.resstatus != 99)).first()
                bline_list = Bline_list()
                bline_list_list.append(bline_list)

                buffer_copy(bill_line, bline_list)
                bline_list.bl_recid = bill_line._recid
                bline_list.datum = bill_line.bill_datum
                bline_list.dept = bill_line.departement
                bline_list.fsaldo = bill_line.fremdwbetrag
                bline_list.saldo = bill_line.betrag

                if resline:
                    bline_list.gname = resline.name

                if mainres:
                    bline_list.voucher = mainres.vesrdepot

        bill_line_obj_list = []
        for bill_line, artikel, bline_list in db_session.query(Bill_line, Artikel, Bline_list).join(Artikel,(Artikel.artnr == Bill_line.artnr) &  (Artikel.departement == 0) &  ((Artikel.artart == 6) |  (Artikel.artart == 7)) &  (Artikel.zwkum != paidout)).join(Bline_list,(Bline_list.bl_recid == to_int(Bill_line._recid))).filter(
                (Bill_line.rechnr == rechnr) &  (Bill_line.departement == 0)).all():
            if bill_line._recid in bill_line_obj_list:
                continue
            else:
                bill_line_obj_list.append(bill_line._recid)


            bline_nr = bline_nr + 1
            bl1_balance = bl1_balance + bill_line.betrag
            bl1_balance1 = bl1_balance1 + bill_line.fremdwbetrag
            bl_balance = bl_balance + bill_line.betrag
            bl_balance1 = bl_balance1 + bill_line.fremdwbetrag

            if artikel.zwkum == paidout:
                bl0_balance = bl0_balance + bill_line.betrag

            if curr_line >= printer.pglen:
                output_list.str = output_list.str + ""


                output_list = Output_list()
                output_list_list.append(output_list)

                curr_page = curr_page + 1
                curr_line = 1
                do_billhead()

            for loop_list in query(loop_list_list):
                curr_pos = 1

                if f_lmargin:
                    for n in range(1,lmargin + 1) :
                        put_string(" ")
                build_loop_line(loop_list.texte)
                output_list.str = output_list.str + ""


                output_list = Output_list()
                output_list_list.append(output_list)

                curr_line = curr_line + 1
        loop_list_list.clear()
        blloop = 0

    def do_spbillline2():

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        n:int = 0
        paidout:int = 0
        Resline = Res_line

        htparam = db_session.query(Htparam).filter(
                (Htparam.paramnr == 242)).first()
        paidout = htparam.finteger
        bl1_balance = 0
        bl1_balance1 = 0
        bline_list_list.clear()

        for t_spbill_list in query(t_spbill_list_list, filters=(lambda t_spbill_list :t_spbill_list.selected)):
            bill_line = db_session.query(Bill_line).filter((Bill_line._recid == t_spbill_list.bl_recid) &  (Bill_line.rechnr == rechnr)).first()
            if not bill_line:
                continue

            artikel = db_session.query(Artikel).filter((Artikel.artnr == bill_line.artnr) &  (Artikel.departement == 0) &  ((Artikel.artart == 6) |  (Artikel.artart == 7)) &  (Artikel.zwkum != paidout)).first()
            if not artikel:
                continue


            bline_list = query(bline_list_list, filters=(lambda bline_list :bline_list.artnr == bill_line.artnr and bline_list.dept == bill_line.departement and bline_list.bezeich == bill_line.bezeich and bline_list.datum == bill_line.bill_datum and bline_list.saldo == - bill_line.betrag), first=True)

            if bline_list:
                bline_list_list.remove(bline_list)
            else:

                mainres = db_session.query(Mainres).filter(
                        (Mainres.resnr == bill_line.massnr)).first()

                resline = db_session.query(Resline).filter(
                        (Resline.resnr == bill_line.massnr) &  (Resline.reslinnr == bill_line.billin_nr)).first()

                if not resline:

                    resline = db_session.query(Resline).filter(
                            (Resline.resnr == bill.resnr) &  (Resline.zinr == bill_line.zinr) &  (Resline.resstatus != 12) &  (Resline.resstatus != 9) &  (Resline.resstatus != 10) &  (Resline.resstatus != 99)).first()
                bline_list = Bline_list()
                bline_list_list.append(bline_list)

                buffer_copy(bill_line, bline_list)
                bline_list.bl_recid = bill_line._recid
                bline_list.datum = bill_line.bill_datum
                bline_list.dept = bill_line.departement
                bline_list.fsaldo = bill_line.fremdwbetrag
                bline_list.saldo = bill_line.betrag

                if resline:
                    bline_list.gname = resline.name

                if mainres:
                    bline_list.voucher = mainres.vesrdepot

        bill_line_obj_list = []
        for bill_line, artikel, bline_list in db_session.query(Bill_line, Artikel, Bline_list).join(Artikel,(Artikel.artnr == Bill_line.artnr) &  (Artikel.departement == 0) &  ((Artikel.artart == 6) |  (Artikel.artart == 7)) &  (Artikel.zwkum != paidout)).join(Bline_list,(Bline_list.bl_recid == to_int(Bill_line._recid))).filter(
                (Bill_line.rechnr == rechnr) &  (Bill_line.departement == 0)).all():
            if bill_line._recid in bill_line_obj_list:
                continue
            else:
                bill_line_obj_list.append(bill_line._recid)


            bline_nr = bline_nr + 1
            bl1_balance = bl1_balance + bill_line.betrag
            bl1_balance1 = bl1_balance1 + bill_line.fremdwbetrag
            bl_balance = bl_balance + bill_line.betrag
            bl_balance1 = bl_balance1 + bill_line.fremdwbetrag

            if artikel.zwkum == paidout:
                bl0_balance = bl0_balance + bill_line.betrag

            if curr_line >= printer.pglen:
                output_list.str = output_list.str + ""


                output_list = Output_list()
                output_list_list.append(output_list)

                curr_page = curr_page + 1
                curr_line = 1
                do_billhead()

            for loop_list in query(loop_list_list):
                curr_pos = 1

                if f_lmargin:
                    for n in range(1,lmargin + 1) :
                        put_string(" ")
                build_loop_line(loop_list.texte)
                output_list.str = output_list.str + ""


                output_list = Output_list()
                output_list_list.append(output_list)

                curr_line = curr_line + 1
        loop_list_list.clear()
        blloop = 0

    def do_pbill_line():

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        n:int = 0
        bl_balance = 0
        bl_balance1 = 0

        for t_list in query(t_list_list):
            bl_balance = bl_balance + t_list.betrag
            bl_balance1 = bl_balance

            if curr_line >= printer.pglen:
                output_list.str = output_list.str + ""


                output_list = Output_list()
                output_list_list.append(output_list)

                curr_page = curr_page + 1
                curr_line = 1
                do_billhead()

            for loop_list in query(loop_list_list):
                curr_pos = 1

                if f_lmargin:
                    for n in range(1,lmargin + 1) :
                        put_string(" ")
                build_loop_line(loop_list.texte)
                output_list.str = output_list.str + ""


                output_list = Output_list()
                output_list_list.append(output_list)

                curr_line = curr_line + 1
        loop_list_list.clear()
        blloop = 0

    def do_billhead():

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        n:int = 0
        headloop = 3
        header_list_list.clear()

        for loop1_list in query(loop1_list_list):
            header_list = Header_list()
            header_list_list.append(header_list)

            curr_pos = 1

            if f_lmargin:
                for n in range(1,lmargin + 1) :
                    put_string(" ")
            build_loop_line(loop1_list.texte)
        headloop = 0
        print_billhead()

    def print_billhead():

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        i:int = 0

        for header_list in query(header_list_list):
            curr_pos = 1
            for i in range(1,len(header_list.texte)  + 1) :
                output_list.str = output_list.str + to_string(substring(header_list.texte, i - 1, 1) , "x(1)")


            output_list.str = output_list.str + ""


            output_list = Output_list()
            output_list_list.append(output_list)

            curr_line = curr_line + 1

    def interprete_text(curr_texte:str, i:int):

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        found = False
        j:int = 0
        rowno:int = 0

        def generate_inner_output():
            return found
        j = i

        htp_list = query(htp_list_list, first=True)
        while None != htp_list and not found:

            if htp_list.fchar == substring(curr_texte, j - 1, len(htp_list.fchar)):
                found = True
                i = j + len(htp_list.fchar) - 1
                print_all_member = False

                if htp_list.paramnr == 1094:

                    if substring(curr_texte, i + 1 - 1, 1) == "*":
                        i = i + 1
                        print_all_member = True

                    if substring(curr_texte, i + 1 - 1, 1) >= "0" and substring(curr_texte, i + 1 - 1, 1) <= "9" and substring(curr_texte, i + 2 - 1, 1) >= "0" and substring(curr_texte, i + 2 - 1, 1) <= "9":
                        g_length = to_int(substring(curr_texte, i + 1 - 1, 2))
                        i = i + 2

                elif htp_list.paramnr == 1063:

                    if substring(curr_texte, i + 1 - 1, 1) >= "0" and substring(curr_texte, i + 1 - 1, 1) <= "9" and substring(curr_texte, i + 2 - 1, 1) >= "0" and substring(curr_texte, i + 2 - 1, 1) <= "9":
                        rowno = to_int(substring(curr_texte, i + 1 - 1, 2))

                        if rowno > printer.pglen:
                            rowno = printer.pglen
                        i = i + 2

                        if curr_line < rowno:
                            for j in range(1,(rowno - curr_line)  + 1) :
                                output_list.str = output_list.str + ""


                                output_list = Output_list()
                                output_list_list.append(output_list)

                            curr_line = rowno
                            curr_pos = 1

                        elif curr_line > rowno:
                            curr_page = curr_page + 1
                            curr_line = 1
                            do_billhead()
                            for j in range(1,(rowno - curr_line)  + 1) :
                                output_list.str = output_list.str + ""


                                output_list = Output_list()
                                output_list_list.append(output_list)

                            curr_line = rowno
                            curr_pos = 1

                    elif curr_line > rowno:
                        for j in range(1,(rowno - curr_line)  + 1) :
                            output_list.str = output_list.str + ""


                            output_list = Output_list()
                            output_list_list.append(output_list)

                        curr_line = rowno
                        curr_pos = 1

                    if curr_line >= printer.pglen:
                        curr_page = curr_page + 1
                        curr_line = 1
                        do_billhead()

                elif htp_list.paramnr == 1091:

                    if substring(curr_texte, i + 1 - 1, 1) >= "0" and substring(curr_texte, i + 1 - 1, 1) <= "9" and substring(curr_texte, i + 2 - 1, 1) >= "0" and substring(curr_texte, i + 2 - 1, 1) <= "9":
                        c_length = to_int(substring(curr_texte, i + 1 - 1, 2))
                        i = i + 2

                elif htp_list.paramnr == 1096:

                    if substring(curr_texte, i + 1 - 1, 1) >= "0" and substring(curr_texte, i + 1 - 1, 1) <= "9" and substring(curr_texte, i + 2 - 1, 1) >= "0" and substring(curr_texte, i + 2 - 1, 1) <= "9":
                        w_length = to_int(substring(curr_texte, i + 1 - 1, 2))
                        i = i + 2

                elif htp_list.paramnr == 1589:

                    if substring(curr_texte, i + 1 - 1, 1) >= "0" and substring(curr_texte, i + 1 - 1, 1) <= "9" and substring(curr_texte, i + 2 - 1, 1) >= "0" and substring(curr_texte, i + 2 - 1, 1) <= "9":
                        v_length = to_int(substring(curr_texte, i + 1 - 1, 2))
                        i = i + 2

                elif htp_list.paramnr == 664:

                    if substring(curr_texte, i + 1 - 1, 1) == "0":
                        print_member = False
                        i = i + 1

                elif htp_list.paramnr == 655:

                    if substring(curr_texte, i + 1 - 1, 1) == "0":
                        short_arrival = True
                        i = i + 1

                elif htp_list.paramnr == 656:

                    if substring(curr_texte, i + 1 - 1, 1) == "0":
                        short_depart = True
                        i = i + 1
                i = decode_key(curr_texte, htp_list.paramnr, i)

            htp_list = query(htp_list_list, next=True)

        if not found:
            put_string(substring(curr_texte, j - 1, 1))


        return generate_inner_output()

    def decode_key(curr_texte:str, paramnr:int, i:int):

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        out_str:str = ""
        status_code:int = 0
        n:int = 0
        m:int = 0

        if (paramnr <= 500):
            out_str, status_code = decode_key1(paramnr)

        elif ((paramnr >= 501) and (paramnr <= 649)) or (paramnr == 1110):
            out_str, status_code = decode_key2(paramnr)

        elif (paramnr >= 650) and (paramnr <= 699):
            out_str, status_code = decode_key3(paramnr)

        elif (paramnr == 1105) or (paramnr == 1107):
            out_str, status_code = decode_key4(paramnr)

        elif (paramnr >= 700) and (paramnr <= 1092):
            out_str, status_code = decode_key4(paramnr)

        elif (paramnr == 1095) or (paramnr == 1096):
            out_str, status_code = decode_key4(paramnr)

        elif (paramnr >= 1094) and (paramnr <= 2401):

            if proforma_inv:
                out_str, status_code = decode_key5p(paramnr)
            else:

                if inv_type == 1:
                    out_str, status_code = decode_key5a(paramnr)

                elif inv_type == 2:
                    out_str, status_code = decode_key5b(paramnr)

                elif inv_type == 3 or inv_type == 4:
                    out_str, status_code = decode_key5c(paramnr)

        if (status_code >= 1 and status_code <= 3) or status_code == 10:
            i = find_parameter(paramnr, curr_texte, status_code, i)

        if status_code == 1:
            m = curr_pos + 1

            if curr_pos > ntab:
                output_list.str = output_list.str + ""


                output_list = Output_list()
                output_list_list.append(output_list)

                curr_line = curr_line + 1
                curr_pos = 1
                for n in range(2,ntab + 1) :
                    put_string(" ")
            else:
                for n in range(m,ntab + 1) :
                    put_string(" ")
            curr_pos = ntab

        elif status_code == 2 and headloop == 0 and blloop == 0:
            for n in range(1,nskip + 1) :
                output_list.str = output_list.str + ""


                output_list = Output_list()
                output_list_list.append(output_list)

                curr_pos = 1
                curr_line = curr_line + 1

        elif status_code == 3:
            for n in range(1,lmargin + 1) :
                put_string(" ")

    def find_parameter(paramnr:int, curr_texte:str, status_code:int, i:int):

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        j:int = 0
        n:int = 0
        d_length:int = 24
        stopped:bool = False

        htp_list = query(htp_list_list, filters=(lambda htp_list :htp_list.paramnr == paramnr), first=True)
        j = i + 1
        while not stopped:

            if substring(curr_texte, j - 1, 1) < "0" or substring(curr_texte, j - 1, 1) > "9":
                stopped = True
            else:
                j = j + 1

        if j > (i + 1):
            j = j - 1
            n = to_int(substring(curr_texte, i + 1 - 1, j - i))

            if status_code == 1:
                ntab = n

            elif status_code == 2:
                nskip = n

            elif status_code == 3:
                lmargin = n

            elif status_code == 10:
                d_length = n
            i = j

    def decode_key1(paramnr:int):

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        out_str = ""
        status_code = 0
        summe:decimal = 0
        t_vat:decimal = 0

        def generate_inner_output():
            return out_str, status_code
        Gmember = Guest

        if paramnr == 100:

            if f_bill:

                if not spbill_flag:
                    t_vat = cal_vat()
                else:
                    t_vat = cal_spvat()

            if not long_digit:
                put_string(to_string(t_vat, "->>>,>>>,>>9.99"))
            else:
                put_string(to_string(t_vat, "->>,>>>,>>>,>>9"))

        elif paramnr == 361 and f_resnr:

            if not long_digit:
                put_string(to_string(reservation.depositgef2, "->>,>>>,>>9.99"))
            else:
                put_string(to_string(reservation.depositgef2, "->,>>>,>>>,>>9"))

        elif paramnr == 362 and f_resnr:
            put_string(to_string(reservation.limitdate2))

        elif paramnr == 365:

            if not long_digit:

                if price_decimal == 0:
                    put_string(to_string(exchg_rate, ">>,>>9.99"))
                else:
                    put_string(to_string(exchg_rate, ">>,>>9.999999"))
            else:
                put_string(to_string(exchg_rate, ">,>>>,>>9"))

        elif (paramnr == 366 or paramnr == 367) and f_resnr:
            summe = (reservation.depositbez + reservation.depositbez2)

            if not long_digit:
                put_string(to_string(summe, "->>,>>>,>>9.99"))
            else:
                put_string(to_string(summe, "->,>>>,>>>,>>9"))

        elif paramnr == 380 and f_resline:
            summe = (res_line.zipreis * res_line.zimmeranz * res_line.anztage)
            put_string(to_string(summe), "->,>>>,>>>,>>9.99")

        elif paramnr == 381:
            summe = 0

            for res_line in db_session.query(Res_line).filter(
                    (Res_line.resnr == bill.resnr) &  (Res_line.active_flag <= 1)).all():
                summe = summe + (res_line.zipreis * res_line.zimmeranz * res_line.anztage)
            put_string(to_string(summe, "->>,>>>,>>9.99"))

        elif paramnr == 382:

            if guest:
                put_string(to_string(guest.telefon, "x(24)"))

        elif paramnr == 383 and f_resnr:
            put_string(trim(reservation.useridanlage))

        elif paramnr == 386:
            put_string(to_string(bill.resnr, ">>,>>>,>>9"))

        elif paramnr == 397 and f_resnr:
            put_string(substring(res_line.flight_nr, 0, 6))

        elif paramnr == 413 and f_resline:

            gmember = db_session.query(Gmember).filter(
                    (Gmember.gastnr == res_line.gastnrmember)).first()
            put_string(to_string(gmember.mobil_telefon, "x(16)"))

        elif paramnr == 414 and f_resline:
            put_string(to_string(res_line.abreise - res_line.ankunft, ">>9"))


        return generate_inner_output()

    def decode_key2(paramnr:int):

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        out_str = ""
        status_code = 0
        n:int = 0

        def generate_inner_output():
            return out_str, status_code

        htparam = db_session.query(Htparam).filter(
                (Htparam.paramnr == paramnr)).first()

        if paramnr == 601:
            1

        elif paramnr == 602:
            put_string(to_string(curr_page))

        elif paramnr == 603:
            status_code = 1

        elif paramnr == 604:
            put_string(to_string(get_current_date()))

        elif paramnr == 1110:
            put_string(to_string(billdate))

        elif paramnr == 605:
            put_string(to_string(get_current_time_in_seconds(), "HH:mm:SS"))

        elif paramnr == 606:
            put_string(to_string(get_current_date()))

        elif paramnr == 607:

            if res_line and res_line.code != "":

                queasy = db_session.query(Queasy).filter(
                        (Queasy.key == 9) &  (Queasy.number1 == to_int(res_line.code))).first()

                if queasy:
                    put_string(queasy.char1)

        elif paramnr == 608:
            status_code = -1

        elif paramnr == 609:
            status_code = -2

        elif paramnr == 616:
            f_lmargin = True
            status_code = 3

        elif paramnr == 617:
            f_lmargin = False

        elif (paramnr >= 618) and (paramnr <= 629):

            printcod = db_session.query(Printcod).filter(
                    (Printcod.emu == printer.emu) &  (Printcod.code == htparam.fchar)).first()

            if printcod:
                put_string(trim(printcod.contcod))

        elif paramnr == 630:
            put_string(trim(guest.adresse1))

            if headloop == 0:
                output_list.str = output_list.str + ""


                output_list = Output_list()
                output_list_list.append(output_list)

                curr_line = curr_line + 1
                curr_pos = 1

            if f_lmargin:
                for n in range(1,lmargin + 1) :
                    put_string(" ")
            put_string(trim(guest.adresse2))

            if headloop == 0:
                output_list.str = output_list.str + ""


                output_list = Output_list()
                output_list_list.append(output_list)

                curr_line = curr_line + 1
                curr_pos = 1
            curr_line = curr_line + 1
            curr_pos = 1

            if f_lmargin:
                for n in range(1,lmargin + 1) :
                    put_string(" ")
            put_string(trim(guest.adresse3))

        elif paramnr == 635:

            if guest.geburtdatum1 != None:
                put_string(to_string(guest.geburtdatum1))
            else:
                put_string("          ")

        elif paramnr == 637:

            akt_kont = db_session.query(Akt_kont).filter(
                    (Akt_kont.gastnr == guest.gastnr) &  (Akt_kont.hauptkontakt)).first()

            if akt_kont:
                put_string(akt_kont.name + ", " + akt_kont.vorname + " " + akt_kont.anrede)

        elif paramnr == 638:
            Rline = Res_line

            if proforma_inv:

                rline = db_session.query(Rline).filter(
                        (Rline.resnr == resnr) &  (Rline.reslinnr == reslinnr)).first()

                if not rline:

                    rline = db_session.query(Rline).filter(
                            (Rline.resnr == resnr) &  (Rline.resstatus != 9) &  (Rline.resstatus != 10) &  (Rline.resstatus != 12) &  (Rline.resstatus != 99)).first()
                put_string(trim(rline.name))
            else:
                put_string(trim(guest.name))

        elif paramnr == 639:
            put_string(trim(guest.vorname1))

        elif paramnr == 641:
            put_string(trim(guest.anrede1))

        elif paramnr == 643:
            put_string(trim(guest.adresse1))

        elif paramnr == 644:
            put_string(trim(guest.adresse2))

        elif paramnr == 645:
            put_string(trim(guest.adresse3))

        elif paramnr == 646:
            put_string(trim(guest.land))

        elif paramnr == 647:
            put_string(to_string(guest.plz))

        elif paramnr == 648:
            put_string(trim(guest.wohnort))


        return generate_inner_output()

    def decode_key3(paramnr:int):

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        out_str = ""
        status_code = 0
        saldo:decimal = 0
        i:int = 0
        bemerk:str = ""
        ank_str:str = ""
        abr_str:str = ""
        wi_gastnr:int = 0
        ind_gastnr:int = 0
        billname:str = ""
        rechnr_str:str = ""

        def generate_inner_output():
            return out_str, status_code
        Guest1 = Guest
        Gmember = Guest


        if f_resline:

            gmember = db_session.query(Gmember).filter(
                    (Gmember.gastnr == res_line.gastnrmember)).first()

        if paramnr == 650:
            status_code = 6

        elif paramnr == 651:
            status_code = 7

        elif paramnr == 652 and f_resnr:
            put_string(to_string(reservation.resart))

        elif paramnr == 653 and f_resnr:
            put_string(to_string(reservation.refdatum))

        elif paramnr == 654 and f_resline:
            put_string(trim(res_line.arrangement))

        elif paramnr == 655 and f_resline:

            if bill and bill.resnr > 0 and bill.reslinnr == 0:
                put_string(to_string(master_ankunft))
            else:
                ank_str = to_string(res_line.ankunft)

                if res_line.ankzeit != 0 and not short_arrival:
                    ank_str = ank_str + " " + to_string(res_line.ankzeit, "HH:mm")
                put_string(ank_str)

        elif paramnr == 656 and f_resline:

            if bill and bill.resnr > 0 and bill.reslinnr == 0:
                put_string(to_string(master_abreise))
            else:
                abr_str = to_string(res_line.abreise)

                if res_line.abreisezeit != 0 and not short_depart:
                    abr_str = abr_str + " " + to_string(res_line.abreisezeit, "HH:mm")
                put_string(abr_str)

        elif paramnr == 657 and f_resline:

            zimkateg = db_session.query(Zimkateg).filter(
                    (Zimkateg.zikatnr == res_line.zikatnr)).first()
            put_string(zimkateg.kurzbez + " / " + to_string(res_line.zimmeranz))

        elif paramnr == 658 and f_resline:
            Gast = Guest

            htparam = db_session.query(Htparam).filter(
                    (Htparam.paramnr == 109)).first()
            wi_gastnr = htparam.finteger

            htparam = db_session.query(Htparam).filter(
                    (Htparam.paramnr == 123)).first()
            ind_gastnr = htparam.finteger

            gast = db_session.query(Gast).filter(
                    (Gast.gastnr == res_line.gastnr)).first()

            if gast.karteityp == 0 or gast.gastnr == wi_gastnr or gast.gastnr == ind_gastnr:
                put_string(trim(to_string(res_line.zipreis, ">>>,>>>,>>9.99")))

            elif res_line.gastnrmember == res_line.gastnrpay:
                put_string(trim(to_string(res_line.zipreis, ">>>,>>>,>>9.99")))
            else:
                put_string(to_string("", "x(14)"))

        elif paramnr == 660 and f_resnr:
            put_string(to_string(reservation.depositgef, "->,>>>,>>>,>>9"))

        elif paramnr == 661 and f_resnr:
            put_string(to_string(reservation.limitdate))

        elif paramnr == 662 and f_resline:
            put_string(trim(res_line.zinr))

        elif paramnr == 663 and f_resline:
            put_string(to_string(res_line.erwachs + res_line.gratis))

        elif paramnr == 664:
            Mbill = Bill

            if proforma_inv:

                mbill = db_session.query(Mbill).filter(
                        (Mbill.resnr == resnr) &  (Mbill.reslinnr == 0)).first()

                if mbill:

                    guest1 = db_session.query(Guest1).filter(
                            (Guest1.gastnr == mbill.gastnr)).first()
                else:

                    guest1 = db_session.query(Guest1).filter(
                            (Guest1.gastnr == reservation.gastnr)).first()
                put_string(guest1.name + ", " + guest1.vorname1 + " " + guest1.anrede1 + guest1.anredefirma)

            elif f_resline and reslinnr > 0:

                guest1 = db_session.query(Guest1).filter(
                        (Guest1.gastnr == res_line.gastnrpay)).first()
                put_string(guest1.name + ", " + guest1.vorname1 + " " + guest1.anrede1 + guest1.anredefirma)

            elif f_bill:

                guest1 = db_session.query(Guest1).filter(
                        (Guest1.gastnr == bill.gastnr)).first()
                billname = guest1.name + ", " + guest1.vorname1 + " " + guest1.anrede1 + guest1.anredefirma

                if guest1.karteityp > 0 and f_resline and print_member:

                    if gmember and gmember.gastnr != guest1.gastnr and gmember.karteityp == 0:
                        billname = billname + " / " + res_line.name
            put_string(billname)

        elif paramnr == 665:
            put_string(to_string(resnr))

        elif paramnr == 666 and f_resnr:

            guest1 = db_session.query(Guest1).filter(
                    (Guest1.gastnr == reservation.gastnr)).first()
            put_gname(guest1.name + ", " + guest1.vorname1 + " " + guest1.anrede1 + guest1.anredefirma)

        elif paramnr == 667 and f_resnr:
            put_string(trim(reservation.groupname))

        elif paramnr == 668:
            status_code = 10

        elif paramnr == 670:
            status_code = 8

        elif paramnr == 671:
            status_code = 9

        elif paramnr == 672 and f_bill:
            put_string(to_string(bill.datum))

        elif paramnr == 673 and f_bill:

            if bill.flag == 0:
                put_string(to_string(bill.rechnr))
                put_string(" / ")
                put_string(to_string(bill.printnr))

            elif bill.flag == 1:
                rechnr_str = to_string(bill.rechnr) + translateExtended ("(DUPLICATE)", lvcarea, "")
                put_string(rechnr_str)

        elif paramnr == 674:
            saldo = 0

            if f_bill:

                bill = db_session.query(Bill).filter(
                        (Bill.rechnr == rechnr)).first()
                saldo = bill.saldo

            if not long_digit:
                put_string(to_string(saldo, "->>>,>>>,>>9.99"))
            else:
                put_string(to_string(saldo, "->>>,>>>,>>>,>>9"))

        elif paramnr == 680:

            akt_kont = db_session.query(Akt_kont).filter(
                    (Akt_kont.gastnr == guest.gastnr) &  (Akt_kont.hauptkontakt)).first()

            if akt_kont:
                put_string(trim(akt_kont.name))

        elif paramnr == 681:

            akt_kont = db_session.query(Akt_kont).filter(
                    (Akt_kont.gastnr == guest.gastnr) &  (Akt_kont.hauptkontakt)).first()

            if akt_kont:
                put_string(trim(akt_kont.vorname))

        elif paramnr == 682:

            akt_kont = db_session.query(Akt_kont).filter(
                    (Akt_kont.gastnr == guest.gastnr) &  (Akt_kont.hauptkontakt)).first()

            if akt_kont:
                put_string(trim(akt_kont.funktion))

        elif paramnr == 683:

            akt_kont = db_session.query(Akt_kont).filter(
                    (Akt_kont.gastnr == guest.gastnr) &  (Akt_kont.hauptkontakt)).first()

            if akt_kont:
                put_string(trim(akt_kont.abteilung))

        elif paramnr == 684:

            akt_kont = db_session.query(Akt_kont).filter(
                    (Akt_kont.gastnr == guest.gastnr) &  (Akt_kont.hauptkontakt)).first()

            if akt_kont:
                put_string(trim(akt_kont.anrede))

        elif paramnr == 686 and f_resline:

            zimmer = db_session.query(Zimmer).filter(
                    (Zimmer.zinr == res_line.zinr)).first()

            if zimmer:
                put_string(trim(zimmer.bezeich))

        elif paramnr == 689:

            if guest.karteityp > 0:
                put_string(trim(guest.name))

        elif paramnr == 690:
            put_string(trim(guest.anredefirma))

        elif paramnr == 691:
            put_string(trim(guest.fax))

        elif paramnr == 692:
            bemerk = ""
            for i in range(1,len(guest.bemerk)  + 1) :

                if substring(guest.bemerk, i - 1, 1) == chr (10):
                    bemerk = bemerk + " "
                else:
                    bemerk = bemerk + substring(guest.bemerk, i - 1, 1)
            put_string(substring(trim(bemerk), 0, 48))

        elif paramnr == 693:
            put_string(to_string(guest.gastnr))

        elif paramnr == 694:

            if gmember:
                put_string(trim(gmember.nation1))
            else:
                put_string(trim(guest.nation1))

        elif paramnr == 695:

            if gmember:
                put_string(trim(gmember.geburt_ort1))
            else:
                put_string(trim(guest.geburt_ort1))

        elif paramnr == 696:

            if gmember:
                put_string(trim(gmember.beruf))
            else:
                put_string(trim(guest.beruf))

        elif paramnr == 697:

            if gmember:
                put_string(trim(gmember.ausweis_art))
            else:
                put_string(trim(guest.ausweis_art))

        elif paramnr == 698:

            if gmember:
                put_string(trim(gmember.ausweis_nr1))
            else:
                put_string(trim(guest.ausweis_nr1))

        elif paramnr == 699:

            if gmember:
                put_string(trim(gmember.autonr))
            else:
                put_string(trim(guest.autonr))


        return generate_inner_output()

    def decode_key4(paramnr:int):

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        out_str = ""
        status_code = 0
        i:int = 0
        pos1:int = 0
        bemerk:str = ""
        gname:str = ""
        voucher:str = ""
        vat_str:str = ""
        ct:str = ""
        anz:int = 0
        cc_str:str = ""
        cc_nr:str = ""
        mm:int = 0
        yy:int = 0
        cc_valid:bool = True
        discval:decimal = 0
        do_it:bool = True
        publish_rate:decimal = 0
        progname:str = ""
        str1:str = ""
        str2:str = ""
        str3:str = ""
        exrate:decimal = 1

        def generate_inner_output():
            return out_str, status_code
        Resline = Res_line
        Gmember = Guest
        Rsvguest = Guest

        if paramnr == 711:

            if f_bill:

                gmember = db_session.query(Gmember).filter(
                        (Gmember.gastnr == bill.gastnr)).first()
                put_string(to_string(gmember.sternzeichen, "x(20)"))
            else:
                put_string(to_string("", "x(20)"))

        elif paramnr == 713 and f_resline:
            put_string(substring(res_line.flight_nr, 6, 5))

        elif paramnr == 714 and f_resline:
            put_string(substring(res_line.flight_nr, 11, 6))

        elif paramnr == 715 and f_resline:
            put_string(substring(res_line.flight_nr, 17, 5))

        elif paramnr == 717:
            put_string("(R)")

        elif paramnr == 725 and f_resline:

            gmember = db_session.query(Gmember).filter(
                    (Gmember.gastnr == res_line.gastnrmember)).first()
            put_string(to_string(gmember.telex, "x(24)"))

        elif paramnr == 726 and f_resline:

            gmember = db_session.query(Gmember).filter(
                    (Gmember.gastnr == res_line.gastnrmember)).first()

            if gmember.geburtdatum2 != None:
                put_string(to_string(gmember.geburtdatum2, "99/99/9999"))
            else:
                put_string(to_string("", "x(10)"))

        elif paramnr == 730 and f_resline:
            for anz in range(1,num_entries(res_line.zimmer_wunsch, ";") - 1 + 1) :
                ct = entry(anz - 1, res_line.zimmer_wunsch, ";")

                if substring(ct, 0, 8) == "segm__pur":
                    ct = substring(ct, 8)

                    queasy = db_session.query(Queasy).filter(
                            (Queasy.key == 143) &  (Queasy.number1 == to_int(ct))).first()

                    if queasy:
                        ct = queasy.char3
                    return generate_inner_output()
            put_string(to_string(ct, "x(12)"))

        elif paramnr == 731 and f_resline:

            gmember = db_session.query(Gmember).filter(
                    (Gmember.gastnr == res_line.gastnrmember)).first()
            put_string(to_string(gmember.mobil_telefon, "x(16)"))

        elif paramnr == 733 and f_resline:

            gmember = db_session.query(Gmember).filter(
                    (Gmember.gastnr == res_line.gastnrmember)).first()

            if gmember.master_gastnr != 0:
                Gbuff = Guest

                gbuff = db_session.query(Gbuff).filter(
                        (Gbuff.gastnr == gmember.master_gastnr)).first()

                if gbuff:
                    put_string(to_string((gbuff.name + ", " + gbuff.anredefirma), "x(24)"))

        elif paramnr == 743 and f_resline:
            put_string(to_string(res_line.erwachs))

        elif paramnr == 746 and f_resline:
            put_string(to_string(res_line.gratis))

        elif paramnr == 759 and f_resnr:

            rsvguest = db_session.query(Rsvguest).filter(
                    (Rsvguest.gastnr == reservation.gastnr)).first()
            put_string(rsvguest.adresse1)

        elif paramnr == 760 and f_resnr:

            rsvguest = db_session.query(Rsvguest).filter(
                    (Rsvguest.gastnr == reservation.gastnr)).first()
            put_string(rsvguest.adresse2)

        elif paramnr == 761 and f_resnr:

            rsvguest = db_session.query(Rsvguest).filter(
                    (Rsvguest.gastnr == reservation.gastnr)).first()
            put_string(rsvguest.adresse3)

        elif paramnr == 762 and f_resnr:

            rsvguest = db_session.query(Rsvguest).filter(
                    (Rsvguest.gastnr == reservation.gastnr)).first()
            put_string(rsvguest.wohnort)

        elif paramnr == 763 and f_resnr:

            rsvguest = db_session.query(Rsvguest).filter(
                    (Rsvguest.gastnr == reservation.gastnr)).first()
            put_string(rsvguest.plz)

        elif paramnr == 765 and f_resnr:

            rsvguest = db_session.query(Rsvguest).filter(
                    (Rsvguest.gastnr == reservation.gastnr)).first()
            put_string(rsvguest.land)

        elif paramnr == 766 and f_resnr:

            gmember = db_session.query(Gmember).filter(
                    (Gmember.gastnr == res_line.gastnrmember)).first()

            if gmember.ausweis_nr2 != "":
                cc_str = entry(0, gmember.ausweis_nr2, "|")
                cc_nr = entry(1, cc_str, "\\")
                mm = to_int(substring(entry(2, cc_str, "\\") , 0, 2))
                yy = to_int(substring(entry(2, cc_str, "\\") , 2))

                if cc_nr == "":
                    cc_valid = False

                if cc_valid:

                    if yy < get_year(get_current_date()):
                        cc_valid = False

                if cc_valid:

                    if (yy == get_year(get_current_date()) and mm < get_month(get_current_date())):
                        cc_valid = False

                if cc_valid:
                    cc_nr = substring(cc_nr, 0, 1) +\
                            fill("X", len(cc_nr) - 5) +\
                            substring(cc_nr, len(cc_nr) - 3 - 1)
                    cc_nr = cc_nr + ", " + substring(entry(2, cc_str, "\\") , 0, 2) + "/" +\
                            substring(entry(2, cc_str, "\\") , 2)


                    put_string(cc_nr)

        elif paramnr == 764:
            vat_str = get_output(bill_vatsum(rechnr, curr_pos))
            put_string(vat_str)

        elif paramnr == 847 and f_resnr:
            put_string(reservation.vesrdepot)

        elif paramnr == 849:

            master = db_session.query(Master).filter(
                    (Master.resnr == resnr)).first()

            if master:
                read_proforma_inv()
            else:
                read_proforma_inv1()
            proforma_inv = True

        elif paramnr == 1087:
            put_string(trim(guest.email_adr))

        elif paramnr == 1088 and f_resnr:
            put_string(to_string(reservation.source_code))

        elif paramnr == 1091 and f_resline:
            bemerk = ""
            for i in range(1,len(res_line.bemerk)  + 1) :

                if substring(res_line.bemerk, i - 1, 1) == chr (10):
                    bemerk = bemerk + " "
                else:
                    bemerk = bemerk + substring(res_line.bemerk, i - 1, 1)
            for i in range(1,c_length + 1) :

                if len(bemerk) < i:
                    put_string(" ")
                else:
                    put_string(substring(bemerk, i - 1, 1))

        elif paramnr == 1092 and f_resnr:
            bemerk = ""
            for i in range(1,len(reservation.bemerk)  + 1) :

                if substring(reservation.bemerk, i - 1, 1) == chr (10):
                    bemerk = bemerk + " "
                else:
                    bemerk = bemerk + substring(reservation.bemerk, i - 1, 1)
            put_string(substring(trim(bemerk), 0, 48))

        elif paramnr == 1077 and f_bill:
            put_string(to_string(bill.rechnr2))

        elif paramnr == 1078 and f_bill:
            Mresline = Res_line

            if bill.flag == 0 and bill.zinr != "":

                mresline = db_session.query(Mresline).filter(
                        (Mresline.resnr == bill.resnr) &  (Mresline.reslinnr == bill.parent_nr)).first()

                guest_pr = db_session.query(Guest_pr).filter(
                        (Guest_pr.gastnr == reservation.gastnr)).first()

                if guest_pr and mresline.zipreis > 0:

                    reslin_queasy = db_session.query(Reslin_queasy).filter(
                            (func.lower(Reslin_queasy.key) == "arrangement") &  (Reslin_queasy.resnr == bill.resnr) &  (Reslin_queasy.reslinnr == bill.parent_nr)).first()
                    do_it = None != reslin_queasy

                if do_it and mresline.zipreis > 0:

                    arrangement = db_session.query(Arrangement).filter(
                            (Arrangement == mresline.arrangement)).first()

                    katpreis = db_session.query(Katpreis).filter(
                            (Katpreis.zikatnr == mresline.zikatnr) &  (Katpreis.argtnr == arrangement.argtnr) &  (Katpreis.startperiode <= billdate) &  (Katpreis.endperiode >= billdate) &  (Katpreis.betriebsnr == wd_array[get_weekday(billdate) - 1])).first()

                    if not katpreis:

                        katpreis = db_session.query(Katpreis).filter(
                                (Katpreis.zikatnr == mresline.zikatnr) &  (Katpreis.argtnr == arrangement.argtnr) &  (Katpreis.startperiode <= billdate) &  (Katpreis.endperiode >= billdate) &  (Katpreis.betriebsnr == 0)).first()

                    if katpreis:
                        publish_rate = get_rackrate (mresline.erwachs, mresline.kind1, mresline.kind2)

                if publish_rate > 0:
                    discval = (1 - (mresline.zipreis / publish_rate)) * 100
                discval = round(discval, 0)

                if discval == 0:
                    put_string(" ")
                else:
                    put_string(to_string(discval))

        elif paramnr == 1094 and f_bill and not print_all_member:

            if bill.resnr > 0:

                resline = db_session.query(Resline).filter(
                        (Resline.resnr == bill_line.massnr) &  (Resline.reslinnr == bill_line.billin_nr)).first()

                if not resline:

                    resline = db_session.query(Resline).filter(
                            (Resline.resnr == bill.resnr) &  (Resline.zinr == bill_line.zinr) &  (Resline.resstatus != 12) &  (Resline.resstatus != 9) &  (Resline.resstatus != 10) &  (Resline.resstatus != 99)).first()

            elif bill_line.zinr != "":

                resline = db_session.query(Resline).filter(
                        (Resline.resnr == bill_line.massnr) &  (Resline.reslinnr == bill_line.billin_nr)).first()

                if not resline:

                    if bill.datum > bill_line.bill_datum:

                        resline = db_session.query(Resline).filter(
                                (Resline.zinr == bill_line.zinr) &  (Resline.resstatus != 12) &  (Resline.resstatus != 9) &  (Resline.resstatus != 10) &  (Resline.resstatus != 99) &  (Resline.ankunft <= bill_line.bill_datum) &  (Resline.abreise > bill_line.bill_datum)).first()
                    else:

                        resline = db_session.query(Resline).filter(
                                (Resline.zinr == bill_line.zinr) &  (Resline.resstatus != 12) &  (Resline.resstatus != 9) &  (Resline.resstatus != 10) &  (Resline.resstatus != 99) &  (Resline.ankunft <= bill_line.bill_datum) &  (Resline.abreise >= bill_line.bill_datum)).first()

            if resline:
                gname = resline.name

            elif bline_list:
                gname = bline_list.gname

            if mainres:
                voucher = mainres.vesrdepot
            for i in range(1,g_length + 1) :

                if len(gname) < i:
                    output_list.str = output_list.str + " "


                else:
                    output_list.str = output_list.str + to_string(substring(gname, i - 1, 1) , "x(1)")


            curr_pos = curr_pos + g_length

        elif paramnr == 1094 and f_bill and print_all_member:

            for resline in db_session.query(Resline).filter(
                    (Resline.resnr == bill.resnr) &  (Resline.resstatus != 12) &  (Resline.resstatus != 9) &  (Resline.resstatus != 10) &  (Resline.resstatus != 13) &  (Resline.resstatus != 99)).all():
                gname = resline.name

                if pos1 != 0:
                    output_list.str = output_list.str + ""


                    output_list = Output_list()
                    output_list_list.append(output_list)

                    curr_line = curr_line + 1
                    for i in range(1,pos1 + 1) :
                        output_list.str = output_list.str + to_string(" ", "x(1)")


                for i in range(1,g_length + 1) :

                    if len(gname) < i:
                        output_list.str = output_list.str + " "


                    else:
                        output_list.str = output_list.str + to_string(substring(gname, i - 1, 1) , "x(1)")


                output_list.str = output_list.str + to_string(" #", "x(2)")


                output_list.str = output_list.str + to_string(resline.zinr, "x(6)")

                if pos1 == 0:
                    pos1 = curr_pos - 1
                    curr_pos = curr_pos + g_length + 7

        elif paramnr == 1095:
            put_string(to_string(bline_nr, ">>9"))

        elif paramnr == 1096:

            if briefnr == briefnr2 or briefnr == briefnr21:

                htparam = db_session.query(Htparam).filter(
                        (Htparam.paramnr == 416)).first()
            else:

                htparam = db_session.query(Htparam).filter(
                        (Htparam.paramnr == 410)).first()
            progname = htparam.fchar

            if (progname != "") and bill:

                if progname.lower()  == "word__chinese.p":

                    if briefnr == briefnr2:
                        str1, str2, str3 = value(progname) (bl0_balance1, w_length)
                    else:

                        if bl0_balance != 0:
                            str1, str2, str3 = value(progname) (bl0_balance, w_length)

                        elif inv_type == 2 or spbill_flag:
                            str1, str2, str3 = value(progname) (bl_balance, w_length)
                        else:
                            str1, str2, str3 = value(progname) (bill.saldo, w_length)
                else:

                    if briefnr == briefnr2 or briefnr == briefnr21:
                        str1, str2 = value(progname) (bl0_balance1, w_length)
                    else:

                        if bl0_balance != 0:
                            str1, str2 = value(progname) (bl0_balance, w_length)

                        elif inv_type == 2 or spbill_flag:
                            str1, str2 = value(progname) (bl_balance, w_length)
                        else:
                            str1, str2 = value(progname) (bill.saldo, w_length)

                if str3 != "":
                    for i in range(1,len(str3)  + 1) :
                        output_list.str = output_list.str + to_string(substring(str3, i - 1, 1) , "x(1)")


                    output_list.str = output_list.str + " "


                    output_list = Output_list()
                    output_list_list.append(output_list)

                    curr_line = curr_line + 1
                    for i in range(1,(curr_pos - 1)  + 1) :
                        output_list.str = output_list.str + to_string(" ", "x(1)")


                for i in range(1,len(str1)  + 1) :
                    output_list.str = output_list.str + to_string(substring(str1, i - 1, 1) , "x(1)")

                if str2 == "":
                    curr_pos = curr_pos + len(str1)
                else:
                    output_list.str = output_list.str + ""


                    output_list = Output_list()
                    output_list_list.append(output_list)

                    curr_line = curr_line + 1
                    for i in range(1,(curr_pos - 1)  + 1) :
                        output_list.str = output_list.str + to_string(" ", "x(1)")


                    for i in range(1,len(str2)  + 1) :
                        output_list.str = output_list.str + to_string(substring(str2, i - 1, 1) , "x(1)")


                    curr_pos = curr_pos + len(str2)

        elif paramnr == 1107:
            Exchg_buff = exrate

            if f_resline:

                if res_line.reserve_dec != 0:

                    if res_line.ankunft == billdate:

                        waehrung = db_session.query(Waehrung).filter(
                                (Waehrungsnr == res_line.betriebsnr)).first()

                        if waehrung:
                            exrate = waehrung.ankauf / waehrung.einheit
                        else:
                            exrate = res_line.reserve_dec
                    else:

                        exchg_buff = db_session.query(Exchg_buff).filter(
                                (Exchg_buff.datum == res_line.ankunft) &  (Exchg_buff.artnr == res_line.betriebsnr)).first()

                        if exchg_buff:
                            exrate = exchg_buff.betrag
                        else:
                            exrate = res_line.reserve_dec
                else:

                    waehrung = db_session.query(Waehrung).filter(
                            (Waehrungsnr == res_line.betriebsnr)).first()

                    if waehrung:
                        exrate = waehrung.ankauf / waehrung.einheit

            if not long_digit:

                if price_decimal == 0:
                    put_string(to_string(exrate, ">>,>>9.99"))
                else:
                    put_string(to_string(exrate, ">>,>>9.999999"))
            else:
                put_string(to_string(exrate, ">,>>>,>>9"))

        elif paramnr == 1105:

            if f_resline:

                waehrung = db_session.query(Waehrung).filter(
                        (Waehrungsnr == res_line.betriebsnr)).first()

                if waehrung:
                    put_string(to_string(waehrung.wabkurz, "x(4)"))
                else:
                    put_string(to_string("    ", "x(4)"))
            else:
                put_string(to_string("    ", "x(4)"))

        elif paramnr == 1589:

            if bill_line.zinr != "":

                mainres = db_session.query(Mainres).filter(
                        (Mainres.resnr == bill_line.massnr)).first()

            if mainres:
                voucher = mainres.vesrdepot
            for i in range(1,v_length + 1) :

                if len(voucher) < i:
                    output_list.str = output_list.str + " "


                else:
                    output_list.str = output_list.str + to_string(substring(voucher, i - 1, 1) , "x(1)")


            curr_pos = curr_pos + v_length


        return generate_inner_output()

    def decode_key5a(paramnr:int):

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        out_str = ""
        status_code = 0
        stime:str = ""
        i:int = 0
        netto:decimal = 0
        gname:str = ""
        voucher:str = ""
        pos1:int = 0
        fbal:decimal = 0
        gname1:str = ""

        def generate_inner_output():
            return out_str, status_code
        Foart = Artikel
        Resline = Res_line
        Guest1 = Guest

        if paramnr == 1094 and not print_all_member:

            if f_resline and reslinnr > 0:
                gname = res_line.name

            elif f_resline and reslinnr == 0:

                if not bill_line:

                    bill_line = db_session.query(Bill_line).filter(
                            (Bill_line.rechnr == bill.rechnr) &  (Bill_line.zinr != "")).first()

                if not bill_line:

                    bill_line = db_session.query(Bill_line).filter(
                            (Bill_line.rechnr == bill.rechnr)).first()

                if bill_line and bill_line.zinr != "":

                    resline = db_session.query(Resline).filter(
                            (Resline.resnr == bill_line.massnr) &  (Resline.reslinnr == bill_line.billin_nr)).first()

                    if not resline:

                        resline = db_session.query(Resline).filter(
                                (Resline.zinr == bill_line.zinr) &  (Resline.resstatus != 12) &  (Resline.resstatus != 9) &  (Resline.resstatus != 10) &  (Resline.resstatus != 99) &  (Resline.active_flag >= 1) &  (Resline.active_flag <= 2) &  (Resline.ankunft <= bill_line.bill_datum) &  (Resline.abreise > bill_line.bill_datum)).first()

                    if resline:
                        gname = resline.name
            for i in range(1,g_length + 1) :

                if len(gname) < i:
                    output_list.str = output_list.str + " "


                else:
                    output_list.str = output_list.str + to_string(substring(gname, i - 1, 1) , "x(1)")


            curr_pos = curr_pos + g_length

        elif paramnr == 1094 and print_all_member:

            for resline in db_session.query(Resline).filter(
                    (Resline.resnr == bill.resnr) &  (Resline.resstatus != 12) &  (Resline.resstatus != 9) &  (Resline.resstatus != 10) &  (Resline.resstatus != 13) &  (Resline.resstatus != 99)).all():
                gname = resline.name

                if pos1 != 0:
                    output_list.str = output_list.str + ""


                    output_list = Output_list()
                    output_list_list.append(output_list)

                    curr_line = curr_line + 1
                    for i in range(1,pos1 + 1) :
                        output_list.str = output_list.str + to_string(" ", "x(1)")


                for i in range(1,g_length + 1) :

                    if len(gname) < i:
                        output_list.str = output_list.str + " "


                    else:
                        output_list.str = output_list.str + to_string(substring(gname, i - 1, 1) , "x(1)")


                output_list.str = output_list.str + to_string(" #", "x(2)")


                output_list.str = output_list.str + to_string(resline.zinr, "x(6)")

                if pos1 == 0:
                    pos1 = curr_pos - 1
                    curr_pos = curr_pos + g_length + 7

        elif paramnr == 1103:

            if f_resline and reslinnr > 0:
                output_list.str = output_list.str + to_string(res_line.ankunft)

            elif f_resline and reslinnr == 0:

                if bill_line.zinr != "":

                    resline = db_session.query(Resline).filter(
                            (Resline.resnr == bill_line.massnr) &  (Resline.reslinnr == bill_line.billin_nr)).first()

                    if not resline:

                        resline = db_session.query(Resline).filter(
                                (Resline.zinr == bill_line.zinr) &  (Resline.resstatus != 12) &  (Resline.resstatus != 9) &  (Resline.resstatus != 10) &  (Resline.resstatus != 99) &  (Resline.active_flag >= 1) &  (Resline.active_flag <= 2) &  (Resline.ankunft <= bill_line.bill_datum) &  (Resline.abreise > bill_line.bill_datum)).first()

                    if resline:
                        output_list.str = output_list.str + to_string(resline.ankunft)


                    else:
                        output_list.str = output_list.str + to_string("", "x(8)")


                else:
                    output_list.str = output_list.str + to_string("", "x(8)")


            curr_pos = curr_pos + 8

        elif paramnr == 1104:

            if f_resline and reslinnr > 0:
                output_list.str = output_list.str + to_string(res_line.abreise)

            elif f_resline and reslinnr == 0:

                if bill_line.zinr != "":

                    resline = db_session.query(Resline).filter(
                            (Resline.resnr == bill_line.massnr) &  (Resline.reslinnr == bill_line.billin_nr)).first()

                    if not resline:

                        resline = db_session.query(Resline).filter(
                                (Resline.zinr == bill_line.zinr) &  (Resline.resstatus != 12) &  (Resline.resstatus != 9) &  (Resline.resstatus != 10) &  (Resline.resstatus != 99) &  (Resline.active_flag >= 1) &  (Resline.active_flag <= 2) &  (Resline.ankunft <= bill_line.bill_datum) &  (Resline.abreise > bill_line.bill_datum)).first()

                    if resline:
                        output_list.str = output_list.str + to_string(resline.abreise)


                    else:
                        output_list.str = output_list.str + to_string("", "x(8)")


                else:
                    output_list.str = output_list.str + to_string("", "x(8)")


            curr_pos = curr_pos + 8

        elif paramnr == 1117:
            output_list.str = output_list.str + to_string(bill_line.userinit, "x(4)")


            curr_pos = curr_pos + 4

        elif paramnr == 1380:

            if bill_line.orts_tax != 0:
                curr_bl_vat = get_vat(bill_line.origin_id)
            else:

                foart = db_session.query(Foart).filter(
                        (Foart.artnr == bill_line.artnr) &  (Foart.departement == bill_line.departement)).first()

                if foart:

                    htparam = db_session.query(Htparam).filter(
                            (Htparam.paramnr == foart.mwst_code)).first()

                    if htparam:
                        curr_bl_vat = htparam.fdecimal
                    else:
                        curr_bl_vat = 0

            if curr_bl_vat == 1000:
                output_list.str = output_list.str + to_string("     ", "x(5)")


            else:
                output_list.str = output_list.str + to_string(curr_bl_vat, ">9.99")


            curr_pos = curr_pos + 5

        elif paramnr == 1400:

            if (artikel.artnr == vat_artnr[0] or artikel.artnr == vat_artnr[1] or artikel.artnr == vat_artnr[2] or artikel.artnr == vat_artnr[3] or artikel.artnr == vat_artnr[4]) and artikel.departement == 0:
                netto = 0

            elif bill_line.orts_tax != 0:
                netto = bill_line.betrag - bill_line.orts_tax
            else:

                foart = db_session.query(Foart).filter(
                        (Foart.artnr == bill_line.artnr) &  (Foart.departement == bill_line.departement)).first()

                if foart:

                    htparam = db_session.query(Htparam).filter(
                            (Htparam.paramnr == foart.mwst_code)).first()

                    if htparam:
                        curr_bl_vat = htparam.fdecimal
                    else:
                        curr_bl_vat = 0
                netto = bill_line.betrag / (1 + curr_bl_vat / 100)
                netto = round (netto, price_decimal)
            bl_netto = bl_netto + netto

            if not long_digit:
                output_list.str = output_list.str + to_string(netto, "->>,>>>,>>9.99")


                curr_pos = curr_pos + 14
            else:
                output_list.str = output_list.str + to_string(netto, "->>>,>>>,>>>,>>9")


                curr_pos = curr_pos + 16

        elif paramnr == 1401:

            if not long_digit:
                output_list.str = output_list.str + to_string(bl_netto, "->>,>>>,>>9.99")


                curr_pos = curr_pos + 14
            else:
                output_list.str = output_list.str + to_string(bl_netto, "->>>,>>>,>>>,>>9")


                curr_pos = curr_pos + 16

        elif paramnr == 1589:

            mainres = db_session.query(Mainres).filter(
                    (Mainres.resnr == bill_line.massnr)).first()

            if mainres:
                voucher = mainres.vesrdepot
            for i in range(1,v_length + 1) :

                if len(voucher) < i:
                    output_list.str = output_list.str + " "


                else:
                    output_list.str = output_list.str + to_string(substring(voucher, i - 1, 1) , "x(1)")


            curr_pos = curr_pos + v_length

        elif paramnr == 2304:
            output_list.str = output_list.str + to_string(bill_line.artnr, ">>>9")


            curr_pos = curr_pos + 4

        elif paramnr == 2305:
            output_list.str = output_list.str + to_string(bill_line.anzahl, "->>9")


            curr_pos = curr_pos + 4

        elif paramnr == 2306:
            for i in range(1,d_length + 1) :

                if len(bill_line.bezeich) < i:
                    output_list.str = output_list.str + " "


                else:
                    output_list.str = output_list.str + to_string(substring(bill_line.bezeich, i - 1, 1) , "x(1)")


            curr_pos = curr_pos + d_length

        elif paramnr == 2307:

            if not long_digit:
                output_list.str = output_list.str + to_string(bill_line.epreis, "->,>>>,>>9.99")


            else:
                output_list.str = output_list.str + to_string(bill_line.epreis, "->>>>,>>>,>>9")


            curr_pos = curr_pos + 13

        elif paramnr == 2308:

            if not long_digit:

                if longer_billamt:
                    output_list.str = output_list.str + to_string(bill_line.betrag, "->>>>,>>>,>>9.99")


                    curr_pos = curr_pos + 16

                elif long_billamt:
                    output_list.str = output_list.str + to_string(bill_line.betrag, "->>>,>>>,>>9.99")


                    curr_pos = curr_pos + 15
                else:
                    output_list.str = output_list.str + to_string(bill_line.betrag, "->>,>>>,>>9.99")


                    curr_pos = curr_pos + 14
            else:
                output_list.str = output_list.str + to_string(bill_line.betrag, "->>>,>>>,>>>,>>9")


                curr_pos = curr_pos + 16

        elif paramnr == 2318:
            output_list.str = output_list.str + to_string(bill_line.fremdwbetrag, "->>,>>9.99")


            curr_pos = curr_pos + 10

        elif paramnr == 2309:

            if bill_line.zinr != "":
                output_list.str = output_list.str + to_string(bill_line.zinr, "x(6)")


            else:
                output_list.str = output_list.str + to_string("    ")


            curr_pos = curr_pos + 4

        elif paramnr == 2310:

            if inv_type == 1:
                output_list.str = output_list.str + to_string(bill_line.bill_datum)


            else:
                output_list.str = output_list.str + to_string("        ")


            curr_pos = curr_pos + 8

        elif paramnr == 2316:

            if not long_digit:
                output_list.str = output_list.str + to_string(bl_balance, "->>>,>>>,>>9.99")


                curr_pos = curr_pos + 15
            else:
                output_list.str = output_list.str + to_string(bl_balance, "->>>,>>>,>>>,>>9")


                curr_pos = curr_pos + 16

        elif paramnr == 2319:

            if bline_flag == 0:

                if fixrate_flag and res_line and res_line.reserve_dec != 0 and bl0_balance != 0:
                    bl0_balance1 = bl0_balance / res_line.reserve_dec

                if bl0_balance1 != 0:

                    if bl0_balance1 >= 100000 or bl0_balance1 <= -100000:
                        output_list.str = output_list.str + to_string(bl0_balance1, "->>>,>>>,>>>,>>9.99")


                        curr_pos = curr_pos + 16
                    else:
                        output_list.str = output_list.str + to_string(bl0_balance1, "->>,>>9.99")


                        curr_pos = curr_pos + 10
                else:
                    fbal = (bl0_balance / exchg_rate)

                    if fbal >= 100000 or fbal <= -100000:
                        output_list.str = output_list.str + to_string(fbal, "->>>,>>>,>>>,>>9")


                        curr_pos = curr_pos + 16
                    else:
                        output_list.str = output_list.str + to_string(fbal, "->>,>>9.99")


                        curr_pos = curr_pos + 10
            else:

                if bl_balance1 >= 100000 or bl_balance1 <= -100000:
                    output_list.str = output_list.str + to_string(bl_balance1, "->>>,>>>,>>>,>>9")


                    curr_pos = curr_pos + 16
                else:
                    output_list.str = output_list.str + to_string(bl_balance1, "->>,>>9.99")


                    curr_pos = curr_pos + 10

        elif paramnr == 2317:

            guest1 = db_session.query(Guest1).filter(
                    (Guest1.gastnr == res_line.gastnrmember)).first()

            if guest1:
                gname1 = guest1.name + ", " + guest1.vorname1 + " " + guest1.anrede1
                put_string(gname1)
                curr_pos = curr_pos + 32

        elif paramnr == 2311:
            stime = to_string(time, "HH:mm")
            put_string(stime)

        elif paramnr == 2312:
            put_string(user_init)

        elif paramnr == 2401:
            put_string(to_string(bediener.username, "x(16)"))


        return generate_inner_output()

    def decode_key5b(paramnr:int):

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        out_str = ""
        status_code = 0
        stime:str = ""
        i:int = 0
        bezeich:str = ""
        netto:decimal = 0
        voucher:str = ""
        gname:str = ""

        def generate_inner_output():
            return out_str, status_code
        Foart = Artikel
        Resline = Res_line
        Htp = Htparam
        Guest1 = Guest

        if paramnr == 1103:

            if f_resline and reslinnr > 0:
                output_list.str = output_list.str + to_string(res_line.ankunft)

            elif f_resline and reslinnr == 0:

                if bline_list.zinr != "":

                    resline = db_session.query(Resline).filter(
                            (Resline.resnr == bline_list.massnr) &  (Resline.reslinnr == bline_list.billin_nr)).first()

                    if not resline:

                        resline = db_session.query(Resline).filter(
                                (Resline.zinr == bline_list.zinr) &  (Resline.resstatus != 12) &  (Resline.resstatus != 9) &  (Resline.resstatus != 10) &  (Resline.resstatus != 99) &  (Resline.active_flag >= 1) &  (Resline.active_flag <= 2) &  (Resline.ankunft <= bline_list.datum) &  (Resline.abreise > bline_list.datum)).first()

                    if resline:
                        output_list.str = output_list.str + to_string(resline.ankunft)


                    else:
                        output_list.str = output_list.str + to_string("", "x(8)")


                else:
                    output_list.str = output_list.str + to_string("", "x(8)")


            curr_pos = curr_pos + 8

        elif paramnr == 1104:

            if f_resline and reslinnr > 0:
                output_list.str = output_list.str + to_string(res_line.abreise)

            elif f_resline and reslinnr == 0:

                if bline_list.zinr != "":

                    resline = db_session.query(Resline).filter(
                            (Resline.resnr == bline_list.massnr) &  (Resline.reslinnr == bline_list.billin_nr)).first()

                    if not resline:

                        resline = db_session.query(Resline).filter(
                                (Resline.zinr == bline_list.zinr) &  (Resline.resstatus != 12) &  (Resline.resstatus != 9) &  (Resline.resstatus != 10) &  (Resline.resstatus != 99) &  (Resline.active_flag >= 1) &  (Resline.active_flag <= 2) &  (Resline.ankunft <= bline_list.datum) &  (Resline.abreise > bline_list.datum)).first()

                    if resline:
                        output_list.str = output_list.str + to_string(resline.abreise)


                    else:
                        output_list.str = output_list.str + to_string(to_string("", "x(8)"))


                else:
                    output_list.str = output_list.str + to_string("", "x(8)")


            curr_pos = curr_pos + 8

        elif paramnr == 1380:

            if bill_line and bill_line.orts_tax != 0:
                curr_bl_vat = get_vat(bill_line.origin_id)
            else:

                foart = db_session.query(Foart).filter(
                        (Foart.artnr == bline_list.artnr) &  (Foart.departement == bline_list.dept)).first()

                if foart:

                    htparam = db_session.query(Htparam).filter(
                            (Htparam.paramnr == foart.mwst_code)).first()

                    if htparam:
                        curr_bl_vat = htparam.fdecimal
                    else:
                        curr_bl_vat = 0

            if curr_bl_vat == 1000:
                output_list.str = output_list.str + to_string("     ", "x(5)")


            else:
                output_list.str = output_list.str + to_string(curr_bl_vat, ">9.99")


            curr_pos = curr_pos + 5

        elif paramnr == 1400:

            if bline_list.netto != 0:
                netto = bline_list.netto

            elif (bline_list.artnr == vat_artnr[0] or bline_list.artnr == vat_artnr[1] or bline_list.artnr == vat_artnr[2] or bline_list.artnr == vat_artnr[3] or bline_list.artnr == vat_artnr[4]) and bline_list.dept == 0:
                netto = 0

            elif bline_list.orts_tax != 0:
                netto = bline_list.saldo - bline_list.orts_tax
            else:

                foart = db_session.query(Foart).filter(
                        (Foart.artnr == bline_list.artnr) &  (Foart.departement == bline_list.dept)).first()

                if foart:

                    htparam = db_session.query(Htparam).filter(
                            (Htparam.paramnr == foart.mwst_code)).first()

                    if htparam:
                        curr_bl_vat = htparam.fdecimal
                    else:
                        curr_bl_vat = 0
                netto = bline_list.saldo / (1 + curr_bl_vat / 100)
            netto = round (netto, price_decimal)
            bl_netto = bl_netto + netto

            if not long_digit:
                output_list.str = output_list.str + to_string(netto, "->>,>>>,>>9.99")


                curr_pos = curr_pos + 14
            else:
                output_list.str = output_list.str + to_string(netto, "->>>,>>>,>>>,>>9")


                curr_pos = curr_pos + 16

        elif paramnr == 1401:

            if not long_digit:
                output_list.str = output_list.str + to_string(bl_netto, "->>,>>>,>>9.99")


                curr_pos = curr_pos + 14
            else:
                output_list.str = output_list.str + to_string(bl_netto, "->>>,>>>,>>>,>>9")


                curr_pos = curr_pos + 16

        elif paramnr == 1589:

            if bline_list.zinr != "":

                mainres = db_session.query(Mainres).filter(
                        (Mainres.resnr == bline_list.massnr)).first()

            if mainres:
                voucher = mainres.vesrdepot
            for i in range(1,v_length + 1) :

                if len(voucher) < i:
                    output_list.str = output_list.str + to_string(" ")


                else:
                    output_list.str = output_list.str + to_string(substring(voucher, i - 1, 1) , "x(1)")


            curr_pos = curr_pos + v_length

        elif paramnr == 2304:
            output_list.str = output_list.str + to_string(0, ">>>>")


            curr_pos = curr_pos + 4

        elif paramnr == 2305:
            output_list.str = output_list.str + to_string(1, "->>9")


            curr_pos = curr_pos + 4

        elif paramnr == 2306:
            bezeich = bline_list.bezeich
            for i in range(1,d_length + 1) :

                if len(bezeich) < i:
                    output_list.str = output_list.str + to_string(" ")


                else:
                    output_list.str = output_list.str + to_string(substring(bezeich, i - 1, 1) , "x(1)")


            curr_pos = curr_pos + d_length

        elif paramnr == 2307:
            output_list.str = output_list.str + to_string(0, "->>>>,>>>,>>>")


            curr_pos = curr_pos + 13

        elif paramnr == 2308:

            if not long_digit:

                if longer_billamt:
                    output_list.str = output_list.str + to_string(bline_list.saldo, "->>>>,>>>,>>9.99")


                    curr_pos = curr_pos + 16

                elif long_billamt:
                    output_list.str = output_list.str + to_string(bline_list.saldo, "->>>,>>>,>>9.99")


                    curr_pos = curr_pos + 15
                else:
                    output_list.str = output_list.str + to_string(bline_list.saldo, "->>,>>>,>>9.99")


                    curr_pos = curr_pos + 14
            else:
                output_list.str = output_list.str + to_string(bline_list.saldo, "->>>,>>>,>>>,>>9")


                curr_pos = curr_pos + 16

        elif paramnr == 2318:
            output_list.str = output_list.str + to_string(bline_list.fsaldo, "->>,>>9.99")


            curr_pos = curr_pos + 10

        elif paramnr == 2309:
            output_list.str = output_list.str + to_string("    ")


            curr_pos = curr_pos + 4

        elif paramnr == 2310:
            output_list.str = output_list.str + to_string("        ", "x(8)")


            curr_pos = curr_pos + 8

        elif paramnr == 1117:
            output_list.str = output_list.str + to_string("  ", "x(4)")


            curr_pos = curr_pos + 4

        elif paramnr == 2316:

            if not long_digit:
                output_list.str = output_list.str + to_string(bl_balance, "->>>,>>>,>>9.99")


                curr_pos = curr_pos + 15
            else:
                output_list.str = output_list.str + to_string(bl_balance, "->>>,>>>,>>>,>>9")


                curr_pos = curr_pos + 16

        elif paramnr == 2319:

            if bl_balance1 >= 100000 or bl_balance1 <= -100000:
                output_list.str = output_list.str + to_string(bl_balance1, "->>>,>>>,>>>,>>9.99")


                curr_pos = curr_pos + 16
            else:
                output_list.str = output_list.str + to_string(bl_balance1, "->>,>>9.99")


                curr_pos = curr_pos + 10

        elif paramnr == 2317:

            guest1 = db_session.query(Guest1).filter(
                    (Guest1.gastnr == res_line.gastnrmember)).first()
            gname = guest1.name + ", " + guest1.vorname1 + " " + guest1.anrede1
            put_string(gname)
            curr_pos = curr_pos + 32

        elif paramnr == 2311:
            stime = to_string(time, "HH:mm")
            put_string(stime)

        elif paramnr == 2312:
            put_string(user_init)

        elif paramnr == 2401:
            put_string(to_string(bediener.username, "x(16)"))


        return generate_inner_output()

    def decode_key5c(paramnr:int):

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        out_str = ""
        status_code = 0
        stime:str = ""
        i:int = 0
        netto:decimal = 0
        pos1:int = 0
        gname:str = ""
        fbal:decimal = 0

        def generate_inner_output():
            return out_str, status_code
        Guest1 = Guest
        Foart = Artikel
        Resline = Res_line

        if paramnr == 1380:

            if bline_list.orts_tax != 0:
                curr_bl_vat = get_vat(bline_list.origin_id)
            else:

                foart = db_session.query(Foart).filter(
                        (Foart.artnr == bline_list.artnr) &  (Foart.departement == bline_list.dept)).first()

                if foart:

                    htparam = db_session.query(Htparam).filter(
                            (Htparam.paramnr == foart.mwst_code)).first()

                    if htparam:
                        curr_bl_vat = htparam.fdecimal
                    else:
                        curr_bl_vat = 0

            if curr_bl_vat == 1000:
                output_list.str = output_list.str + to_string("     ", "x(5)")


            else:
                output_list.str = output_list.str + to_string(curr_bl_vat, ">9.99")


            curr_pos = curr_pos + 5

        elif paramnr == 1400:

            if (bline_list.artnr == vat_artnr[0] or bline_list.artnr == vat_artnr[1] or bline_list.artnr == vat_artnr[2] or bline_list.artnr == vat_artnr[3] or bline_list.artnr == vat_artnr[4]) and bline_list.dept == 0:
                netto = 0

            elif bline_list.orts_tax != 0:
                netto = bline_list.saldo - bline_list.orts_tax
            else:

                foart = db_session.query(Foart).filter(
                        (Foart.artnr == bline_list.artnr) &  (Foart.departement == bline_list.dept)).first()

                if foart:

                    htparam = db_session.query(Htparam).filter(
                            (Htparam.paramnr == foart.mwst_code)).first()

                    if htparam:
                        curr_bl_vat = htparam.fdecimal
                    else:
                        curr_bl_vat = 0
                netto = bline_list.saldo / (1 + curr_bl_vat / 100)
                netto = round (netto, price_decimal)
            bl_netto = bl_netto + netto

            if not long_digit:
                output_list.str = output_list.str + to_string(netto, "->>,>>>,>>9.99")


                curr_pos = curr_pos + 14
            else:
                output_list.str = output_list.str + to_string(netto, "->>>,>>>,>>>,>>9")


                curr_pos = curr_pos + 16

        elif paramnr == 1401:

            if not long_digit:
                output_list.str = output_list.str + to_string(bl_netto, "->>,>>>,>>9.99")


                curr_pos = curr_pos + 14
            else:
                output_list.str = output_list.str + to_string(bl_netto, "->>>,>>>,>>>,>>9")


                curr_pos = curr_pos + 16

        elif paramnr == 1094 and not print_all_member:
            for i in range(1,g_length + 1) :

                if len(bline_list.gname) < i:
                    output_list.str = output_list.str + " "


                else:
                    output_list.str = output_list.str + to_string(substring(bline_list.gname, i - 1, 1) , "x(1)")


            curr_pos = curr_pos + g_length

        elif paramnr == 1094 and print_all_member:

            for resline in db_session.query(Resline).filter(
                    (Resline.resnr == bill.resnr) &  (Resline.resstatus != 12) &  (Resline.resstatus != 9) &  (Resline.resstatus != 10) &  (Resline.resstatus != 13) &  (Resline.resstatus != 99)).all():
                gname = resline.name

                if pos1 != 0:
                    output_list.str = output_list.str + ""


                    output_list = Output_list()
                    output_list_list.append(output_list)

                    curr_line = curr_line + 1
                    for i in range(1,pos1 + 1) :
                        output_list.str = output_list.str + to_string(" ", "x(1)")


                for i in range(1,g_length + 1) :

                    if len(gname) < i:
                        output_list.str = output_list.str + " "


                    else:
                        output_list.str = output_list.str + to_string(substring(gname, i - 1, 1) , "x(1)")


                output_list.str = output_list.str + to_string(" #", "x(2)")


                output_list.str = output_list.str + to_string(resline.zinr, "x(6)")

                if pos1 == 0:
                    pos1 = curr_pos - 1
                    curr_pos = curr_pos + g_length + 7

        elif paramnr == 1103:

            if f_resline and reslinnr > 0:
                output_list.str = output_list.str + to_string(res_line.ankunft)

            elif f_resline and reslinnr == 0:

                if bline_list.zinr != "":

                    resline = db_session.query(Resline).filter(
                            (Resline.resnr == bline_list.massnr) &  (Resline.reslinnr == bline_list.billin_nr)).first()

                    if not resline:

                        resline = db_session.query(Resline).filter(
                                (Resline.zinr == bline_list.zinr) &  (Resline.resstatus != 12) &  (Resline.resstatus != 9) &  (Resline.resstatus != 10) &  (Resline.resstatus != 99) &  (Resline.active_flag >= 1) &  (Resline.active_flag <= 2) &  (Resline.ankunft <= bline_list.datum) &  (Resline.abreise > bline_list.datum)).first()

                    if resline:
                        output_list.str = output_list.str + to_string(resline.ankunft)


                    else:
                        output_list.str = output_list.str + to_string("", "x(8)")


                else:
                    output_list.str = output_list.str + to_string("", "x(8)")


            curr_pos = curr_pos + 8

        elif paramnr == 1104:

            if f_resline and reslinnr > 0:
                output_list.str = output_list.str + to_string(res_line.abreise)

            elif f_resline and reslinnr == 0:

                if bline_list.zinr != "":

                    resline = db_session.query(Resline).filter(
                            (Resline.resnr == bline_list.massnr) &  (Resline.reslinnr == bline_list.billin_nr)).first()

                    if not resline:

                        resline = db_session.query(Resline).filter(
                                (Resline.zinr == bline_list.zinr) &  (Resline.resstatus != 12) &  (Resline.resstatus != 9) &  (Resline.resstatus != 10) &  (Resline.resstatus != 99) &  (Resline.active_flag >= 1) &  (Resline.active_flag <= 2) &  (Resline.ankunft <= bline_list.datum) &  (Resline.abreise > bline_list.datum)).first()

                    if resline:
                        output_list.str = output_list.str + to_string(resline.abreise)


                    else:
                        output_list.str = output_list.str + to_string("", "x(8)")


                else:
                    output_list.str = output_list.str + to_string("", "x(8)")


            curr_pos = curr_pos + 8

        elif paramnr == 1589:
            for i in range(1,v_length + 1) :

                if len(bline_list.voucher) < i:
                    output_list.str = output_list.str + " "


                else:
                    output_list.str = output_list.str + to_string(substring(bline_list.voucher, i - 1, 1) , "x(1)")


            curr_pos = curr_pos + v_length

        elif paramnr == 2304:
            output_list.str = output_list.str + to_string(bline_list.artnr, ">>>9")


            curr_pos = curr_pos + 4

        elif paramnr == 2305:
            output_list.str = output_list.str + to_string(bline_list.anzahl, "->>9")


            curr_pos = curr_pos + 4

        elif paramnr == 2306:
            for i in range(1,d_length + 1) :

                if len(bline_list.bezeich) < i:
                    output_list.str = output_list.str + " "


                else:
                    output_list.str = output_list.str + to_string(substring(bline_list.bezeich, i - 1, 1) , "x(1)")


            curr_pos = curr_pos + d_length

        elif paramnr == 2307:

            if not long_digit:
                output_list.str = output_list.str + to_string(bline_list.epreis, "->,>>>,>>9.99")


            else:
                output_list.str = output_list.str + to_string(bline_list.epreis, "->>>>,>>>,>>9")


            curr_pos = curr_pos + 13

        elif paramnr == 2308:

            if not long_digit:

                if longer_billamt:
                    output_list.str = output_list.str + to_string(bline_list.saldo, "->>>>,>>>,>>9.99")


                    curr_pos = curr_pos + 16

                elif long_billamt:
                    output_list.str = output_list.str + to_string(bline_list.saldo, "->>>,>>>,>>9.99")


                    curr_pos = curr_pos + 15
                else:
                    output_list.str = output_list.str + to_string(bline_list.saldo, "->>,>>>,>>9.99")


                    curr_pos = curr_pos + 14
            else:
                output_list.str = output_list.str + to_string(bline_list.saldo, "->>>,>>>,>>>,>>9")


                curr_pos = curr_pos + 16

        elif paramnr == 2318:
            output_list.str = output_list.str + to_string(bline_list.fsaldo, "->>,>>9.99")


            curr_pos = curr_pos + 10

        elif paramnr == 2309:

            if bline_list.zinr != "":
                output_list.str = output_list.str + to_string(bline_list.zinr, "x(6)")


            else:
                output_list.str = output_list.str + "    "


            curr_pos = curr_pos + 4

        elif paramnr == 2310:

            if bline_list.datum == None:
                output_list.str = output_list.str + to_string("        ", "x(8)")


            else:
                output_list.str = output_list.str + to_string(bline_list.datum)


            curr_pos = curr_pos + 8

        elif paramnr == 1117:
            output_list.str = output_list.str + to_string(bline_list.userinit, "x(4)")


            curr_pos = curr_pos + 4

        elif paramnr == 2316:

            if bline_flag == -1:

                if not long_digit:
                    output_list.str = output_list.str + to_string(bl_balance, "->>>,>>>,>>9.99")


                    curr_pos = curr_pos + 15
                else:
                    output_list.str = output_list.str + to_string(bl_balance, "->>>,>>>,>>>,>>9")


                    curr_pos = curr_pos + 16

            elif bline_flag == 0:

                if not long_digit:
                    output_list.str = output_list.str + to_string(bl0_balance, "->>,>>>,>>9.99")


                    curr_pos = curr_pos + 14
                else:
                    output_list.str = output_list.str + to_string(bl0_balance, "->>>,>>>,>>>,>>9")


                    curr_pos = curr_pos + 16

        elif paramnr == 2319:

            if bline_flag == -1:

                if bl_balance1 >= 100000 or bl_balance1 <= -100000:
                    output_list.str = output_list.str + to_string(bl_balance1, "->>>,>>>,>>>,>>9")


                    curr_pos = curr_pos + 16
                else:
                    output_list.str = output_list.str + to_string(bl_balance1, "->>,>>9.99")


                    curr_pos = curr_pos + 10

            elif bline_flag == 0:

                if bl0_balance1 != 0:
                    fbal = bl0_balance1
                else:
                    fbal = bl0_balance / exchg_rate

                if fbal >= 100000 or fbal <= -100000:
                    output_list.str = output_list.str + to_string(fbal, "->>>,>>>,>>>,>>9")


                    curr_pos = curr_pos + 16
                else:
                    output_list.str = output_list.str + to_string(fbal, "->>,>>9.99")


                    curr_pos = curr_pos + 10

        elif paramnr == 2317:

            guest1 = db_session.query(Guest1).filter(
                    (Guest1.gastnr == res_line.gastnrmember)).first()
            gname = guest1.name + ", " + guest1.vorname1 + " " + guest1.anrede1
            put_string(gname)
            curr_pos = curr_pos + 32

        elif paramnr == 2311:
            stime = to_string(time, "HH:mm")
            put_string(stime)

        elif paramnr == 2312:
            put_string(user_init)

        elif paramnr == 2401:
            put_string(to_string(bediener.username, "x(16)"))


        return generate_inner_output()

    def decode_key5p(paramnr:int):

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        out_str = ""
        status_code = 0
        stime:str = ""
        i:int = 0
        ch:str = ""

        def generate_inner_output():
            return out_str, status_code
        Guest1 = Guest

        if paramnr == 2304:
            output_list.str = output_list.str + to_string(t_list.nr, ">>>>")


            curr_pos = curr_pos + 4

        elif paramnr == 2305:
            output_list.str = output_list.str + to_string(t_list.qty, "->>9")


            curr_pos = curr_pos + 4

        elif paramnr == 2306:

            if t_list.rmcat != "":
                ch = (t_list.rmcat + " " + t_list.bezeich)
            else:
                ch = t_list.bezeich
            for i in range(1,d_length + 1) :

                if len(ch) < i:
                    output_list.str = output_list.str + " "


                else:
                    output_list.str = output_list.str + to_string(substring(ch, i - 1, 1) , "x(1)")


            curr_pos = curr_pos + d_length

        elif paramnr == 2307:

            if not long_digit:
                output_list.str = output_list.str + to_string(t_list.preis, "->,>>>,>>9.99")


            else:
                output_list.str = output_list.str + to_string(t_list.preis, "->>>>,>>>,>>9")


            curr_pos = curr_pos + 13

        elif paramnr == 2308:

            if not long_digit:

                if longer_billamt:
                    output_list.str = output_list.str + to_string(t_list.betrag, "->>>>,>>>,>>9.99")


                    curr_pos = curr_pos + 16

                elif long_billamt:
                    output_list.str = output_list.str + to_string(t_list.betrag, "->>>,>>>,>>9.99")


                    curr_pos = curr_pos + 15
                else:
                    output_list.str = output_list.str + to_string(t_list.betrag, "->>,>>>,>>9.99")


                    curr_pos = curr_pos + 14
            else:
                output_list.str = output_list.str + to_string(t_list.betrag, "->>>,>>>,>>>,>>9")


                curr_pos = curr_pos + 16

        elif paramnr == 2318:
            output_list.str = output_list.str + to_string(t_list.betrag, "->>,>>9.99")


            curr_pos = curr_pos + 10

        elif paramnr == 2309:
            output_list.str = output_list.str + to_string(t_list.tage, ">>9")


            curr_pos = curr_pos + 3

        elif paramnr == 2310:
            output_list.str = output_list.str + to_string(t_list.date1)


            curr_pos = curr_pos + 8

        elif paramnr == 1117:
            output_list.str = output_list.str + to_string(" ", "x(4)")


            curr_pos = curr_pos + 4

        elif paramnr == 2316:

            if not long_digit:
                output_list.str = output_list.str + to_string(bl_balance, "->>>,>>>,>>9.99")


                curr_pos = curr_pos + 15
            else:
                output_list.str = output_list.str + to_string(bl_balance, "->>>,>>>,>>>,>>9")


                curr_pos = curr_pos + 16

        elif paramnr == 2319:

            if bl_balance1 >= 100000 or bl_balance1 <= -100000:
                output_list.str = output_list.str + to_string(bl_balance1, " ->>>,>>>,>>9.99")


                curr_pos = curr_pos + 16
            else:
                output_list.str = output_list.str + to_string(bl_balance1, "->>,>>9.99")


                curr_pos = curr_pos + 10

        elif paramnr == 2317:

            guest1 = db_session.query(Guest1).filter(
                    (Guest1.gastnr == res_line.gastnrmember)).first()
            put_string(guest1.name + ", " + guest1.vorname1 + " " + guest1.anrede1)
            curr_pos = curr_pos + len(guest1.name + ", " + guest1.vorname1 + " " + guest1.anrede1)

        elif paramnr == 2311:
            stime = to_string(time, "HH:mm")
            put_string(stime)

        elif paramnr == 2312:
            put_string(user_init)

        elif paramnr == 2401:
            put_string(to_string(bediener.username, "x(16)"))


        return generate_inner_output()

    def put_string(str:str):

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        len_:int = 0
        i:int = 0
        len_ = len(str)
        for i in range(1,len + 1) :

            if headloop == 0:
                output_list.str = output_list.str + to_string(substring(str, i - 1, 1) , "x(1)")

            elif headloop == 3:
                header_list.texte = header_list.texte + substring(str, i - 1, 1)

            if substring(str, i - 1, 1) == chr(10):
                curr_pos = 1
        curr_pos = curr_pos + len

    def put_gname(str:str):

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        len_:int = 0
        i:int = 0
        len_ = round(len(str) / 2 + 0.4, 0)
        for i in range(1,len + 1) :
            output_list.str = output_list.str + to_string(substring(str, (i * 2 - 1) - 1, 2) , "x(2)")


        curr_pos = curr_pos + len_ * 2

    def create_bonus():

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        i:int = 0
        j:int = 1
        k:int = 0
        n:int = 0
        stay:int = 0
        pay:int = 0
        num_bonus:int = 0
        for i in range(1,999 + 1) :
            bonus_array[i - 1] = False
        j = 1
        for i in range(1,4 + 1) :
            stay = to_int(substring(arrangement.options, j - 1, 2))
            pay = to_int(substring(arrangement.options, j + 2 - 1, 2))

            if (stay - pay) > 0:
                n = num_bonus + pay + 1
                for k in range(n,stay + 1) :
                    bonus_array[k - 1] = True
                num_bonus = stay - pay
            j = j + 4

    def read_proforma_inv():

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        datum:date = None
        co_date:date = None
        add_it:bool = False
        ankunft:date = None
        abreise:date = None
        rm_rate:decimal = 0
        argt_rate:decimal = 0
        argt_defined:bool = False
        delta:int = 0
        start_date:date = None
        fixed_rate:bool = False
        qty:int = 0
        it_exist:bool = False
        exrate1:decimal = 1
        ex2:decimal = 1
        pax:int = 0
        child1:int = 0
        bill_date:date = None
        curr_zikatnr:int = 0
        ebdisc_flag:bool = False
        kbdisc_flag:bool = False
        rate_found:bool = False
        early_flag:bool = False
        kback_flag:bool = False
        i:int = 0
        j:int = 0
        qty1:int = 0
        ct:str = ""
        contcode:str = ""
        W1 = Waehrung
        Resline = Res_line

        for resline in db_session.query(Resline).filter(
                (Resline.resnr == resnr) &  (Resline.active_flag <= 2) &  (Resline.resstatus != 12) &  (Resline.resstatus != 9) &  (Resline.resstatus != 10) &  (Resline.resstatus != 99)).all():
            ebdisc_flag = re.match(".*ebdisc.*",resline.zimmer_wunsch)
            kbdisc_flag = re.match(".*kbdisc.*",resline.zimmer_wunsch)

            if resline.l_zuordnung[0] != 0:
                curr_zikatnr = resline.l_zuordnung[0]
            else:
                curr_zikatnr = resline.zikatnr

            zimkateg = db_session.query(Zimkateg).filter(
                    (Zimkateg.zikatnr == resline.zikatnr)).first()

            arrangement = db_session.query(Arrangement).filter(
                    (Arrangement == resline.arrangement)).first()
            ankunft = resline.ankunft
            abreise = resline.abreise
            fixed_rate = False

            if resline.was_status == 1:
                fixed_rate = True
            co_date = resline.abreise

            if co_date > resline.ankunft:
                co_date = co_date - 1
            create_bonus()
            for datum in range(resline.ankunft,co_date + 1) :
                bill_date = datum
                argt_rate = 0
                rm_rate = resline.zipreis
                pax = resline.erwachs

                if fixed_rate:

                    reslin_queasy = db_session.query(Reslin_queasy).filter(
                            (func.lower(Reslin_queasy.key) == "arrangement") &  (Reslin_queasy.resnr == resline.resnr) &  (Reslin_queasy.reslinnr == resline.reslinnr) &  (Reslin_queasy.datum >= Reslin_queasy.date1) &  (Reslin_queasy.datum <= Reslin_queasy.date2)).first()

                    if reslin_queasy:
                        rm_rate = reslin_queasy.deci1

                        if reslin_queasy.number3 != 0:
                            pax = reslin_queasy.number3
                    rm_rate, it_exist = usr_prog1(datum, rm_rate)
                else:

                    guest = db_session.query(Guest).filter(
                            (Guest.gastnr == resline.gastnr)).first()

                    guest_pr = db_session.query(Guest_pr).filter(
                            (Guest_pr.gastnr == guest.gastnr)).first()

                    if guest_pr:

                        queasy = db_session.query(Queasy).filter(
                                (Queasy.key == 18) &  (Queasy.number1 == resline.reserve_int)).first()

                        if queasy and queasy.logi3:
                            bill_date = resline.ankunft

                        if new_contrate:
                            rate_found, rm_rate, early_flag, kback_flag = get_output(ratecode_rate(ebdisc_flag, kbdisc_flag, resline.resnr, resline.reslinnr, guest_pr.CODE, None, bill_date, resline.ankunft, resline.abreise, resline.reserve_int, arrangement.argtnr, curr_zikatnr, resline.erwachs, resline.kind1, resline.kind2, resline.reserve_dec, resline.betriebsnr))
                        else:
                            rm_rate, rate_found = get_output(pricecod_rate(resline.resnr, resline.reslinnr, guest_pr.CODE, bill_date, resline.ankunft, resline.abreise, resline.reserve_int, arrangement.argtnr, curr_zikatnr, resline.erwachs, resline.kind1, resline.kind2, resline.reserve_dec, resline.betriebsnr))
                            rm_rate, it_exist = usr_prog2(datum, rm_rate)

                            if it_exist:
                                rate_found = True

                            if not it_exist and bonus_array[datum - resline.ankunft + 1 - 1] :
                                rm_rate = 0

                s_list = query(s_list_list, filters=(lambda s_list :s_list.bezeich == arrangement.argt_rgbez and s_list.rmcat == zimkateg.kurzbez and s_list.preis == rm_rate and s_list.datum == datum and s_list.ankunft == resline.ankunft and s_list.abreise == resline.abreise and s_list.erwachs == pax and s_list.kind1 == resline.kind1 and s_list.kind2 == resline.kind2), first=True)

                if not s_list:
                    s_list = S_list()
                    s_list_list.append(s_list)

                    s_list.bezeich = arrangement.argt_rgbez
                    s_list.rmcat = zimkateg.kurzbez
                    s_list.preis = rm_rate
                    s_list.datum = datum
                    s_list.ankunft = resline.ankunft
                    s_list.abreise = resline.abreise
                    s_list.erwachs = pax
                    s_list.kind1 = resline.kind1
                    s_list.kind2 = resline.kind2
                s_list.qty = s_list.qty + resline.zimmeranz

                for fixleist in db_session.query(Fixleist).filter(
                        (Fixleist.resnr == resline.resnr) &  (Fixleist.reslinnr == resline.reslinnr)).all():
                    add_it = False
                    argt_rate = 0

                    if fixleist.sequenz == 1:
                        add_it = True

                    elif fixleist.sequenz == 2 or fixleist.sequenz == 3:

                        if resline.ankunft == datum:
                            add_it = True

                    elif fixleist.sequenz == 4 and get_day(datum) == 1:
                        add_it = True

                    elif fixleist.sequenz == 5 and get_day(datum + 1) == 1:
                        add_it = True

                    elif fixleist.sequenz == 6:

                        if fixleist.lfakt == None:
                            delta = 0
                        else:
                            delta = fixleist.lfakt - resline.ankunft

                            if delta < 0:
                                delta = 0
                        start_date = resline.ankunft + delta

                        if (resline.abreise - start_date) < fixleist.dekade:
                            start_date = resline.ankunft

                        if datum <= (start_date + (fixleist.dekade - 1)):
                            add_it = True

                        if datum < start_date:
                            add_it = False

                    if add_it:

                        artikel = db_session.query(Artikel).filter(
                                (Artikel.artnr == fixleist.artnr) &  (Artikel.departement == fixleist.departement)).first()
                        argt_rate = fixleist.betrag * fixleist.number

                        if not fixed_rate and guest_pr:
                            contcode = guest_pr.CODE
                            ct = resline.zimmer_wunsch

                            if re.match(".*\$CODE\$.*",ct):
                                ct = substring(ct,0 + get_index(ct, "$CODE$") + 6)
                                contcode = substring(ct, 0,1 + get_index(ct, ";") - 1)

                            reslin_queasy = db_session.query(Reslin_queasy).filter(
                                    (func.lower(Reslin_queasy.key) == "argt_line") &  (func.lower(Reslin_queasy.char1) == (contcode).lower()) &  (Reslin_queasy.number1 == resline.reserve_int) &  (Reslin_queasy.number2 == arrangement.argtnr) &  (Reslin_queasy.reslinnr == resline.zikatnr) &  (Reslin_queasy.number3 == fixleist.artnr) &  (Reslin_queasy.resnr == fixleist.departement) &  (Reslin_queasy.bill_date >= Reslin_queasy.date1) &  (Reslin_queasy.bill_date <= Reslin_queasy.date2)).first()

                            if reslin_queasy:
                                argt_rate = reslin_queasy.deci1 * fixleist.number

                    if argt_rate != 0:

                        s_list = query(s_list_list, filters=(lambda s_list :s_list.bezeich == artikel.bezeich and s_list.preis == (argt_rate / fixleist.number) and s_list.datum == datum and s_list.ankunft == resline.ankunft and s_list.abreise == resline.abreise and s_list.erwachs == pax and s_list.kind1 == resline.kind1 and s_list.kind2 == resline.kind2), first=True)

                        if not s_list:
                            s_list = S_list()
                            s_list_list.append(s_list)

                            s_list.nr = artikel.artnr
                            s_list.bezeich = artikel.bezeich
                            s_list.preis = argt_rate / fixleist.number
                            s_list.datum = datum
                            s_list.ankunft = resline.ankunft
                            s_list.abreise = resline.abreise
                            s_list.erwachs = pax
                            s_list.kind1 = resline.kind1
                            s_list.kind2 = resline.kind2
                        s_list.qty = s_list.qty + (fixleist.number * resline.zimmeranz)

        for s_list in query(s_list_list):

            if s_list.nr == 0:

                t_list = query(t_list_list, filters=(lambda t_list :t_list.bezeich == s_list.bezeich and t_list.rmcat == s_list.rmcat and t_list.preis == s_list.preis and t_list.ankunft == s_list.ankunft and t_list.abreise == s_list.abreise and t_list.erwachs == s_list.erwachs and t_list.kind1 == s_list.kind1 and t_list.kind2 == s_list.kind2), first=True)

                if not t_list:
                    t_list = T_list()
                    t_list_list.append(t_list)

                    t_list.nr = s_list.nr
                    t_list.bezeich = s_list.bezeich
                    t_list.rmcat = s_list.rmcat
                    t_list.preis = s_list.preis
                    t_list.date1 = s_list.datum
                    t_list.ankunft = s_list.ankunft
                    t_list.abreise = s_list.abreise
                    t_list.erwachs = s_list.erwachs
                    t_list.kind1 = s_list.kind1
                    t_list.kind2 = s_list.kind2

                if s_list.qty >= t_list.qty:
                    t_list.tage = t_list.tage + 1
                t_list.date2 = s_list.datum

                if s_list.datum == t_list.date1:
                    t_list.qty = t_list.qty + s_list.qty

                if s_list.qty != t_list.qty and s_list.preis == t_list.preis:
                    qty1 = t_list.qty
                    t_list = T_list()
                    t_list_list.append(t_list)

                    t_list.nr = s_list.nr
                    t_list.bezeich = s_list.bezeich
                    t_list.rmcat = s_list.rmcat
                    t_list.preis = s_list.preis
                    t_list.date1 = s_list.datum
                    t_list.ankunft = s_list.ankunft
                    t_list.abreise = s_list.abreise
                    t_list.erwachs = s_list.erwachs
                    t_list.kind1 = s_list.kind1
                    t_list.kind2 = s_list.kind2
                    t_list.date1 = s_list.datum
                    t_list.tage = 1

                    if s_list.qty > qty1:
                        j = s_list.qty - qty1
                        t_list.qty = j


                    else:
                        j = qty1 - s_list.qty
                        t_list.qty = s_list.qty


            else:

                t_list = query(t_list_list, filters=(lambda t_list :t_list.bezeich == s_list.bezeich and t_list.preis == s_list.preis and t_list.ankunft == s_list.ankunft and t_list.abreise == s_list.abreise and t_list.erwachs == s_list.erwachs and t_list.kind1 == s_list.kind1 and t_list.kind2 == s_list.kind2), first=True)

                if not t_list:
                    t_list = T_list()
                    t_list_list.append(t_list)

                    t_list.nr = s_list.nr
                    t_list.bezeich = s_list.bezeich
                    t_list.preis = s_list.preis
                    t_list.date1 = s_list.datum
                    t_list.ankunft = s_list.ankunft
                    t_list.abreise = s_list.abreise
                    t_list.erwachs = s_list.erwachs
                    t_list.kind1 = s_list.kind1
                    t_list.kind2 = s_list.kind2
                t_list.tage = t_list.tage + 1
                t_list.date2 = s_list.datum

                if s_list.datum == t_list.date1:
                    t_list.qty = t_list.qty + s_list.qty
            s_list_list.remove(s_list)

        for t_list in query(t_list_list):
            t_list.betrag = t_list.qty * t_list.tage * t_list.preis

    def read_proforma_inv1():

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        datum:date = None
        co_date:date = None
        add_it:bool = False
        ankunft:date = None
        abreise:date = None
        rm_rate:decimal = 0
        argt_rate:decimal = 0
        argt_defined:bool = False
        delta:int = 0
        start_date:date = None
        fixed_rate:bool = False
        qty:int = 0
        it_exist:bool = False
        exrate1:decimal = 1
        ex2:decimal = 1
        pax:int = 0
        child1:int = 0
        bill_date:date = None
        curr_zikatnr:int = 0
        curr_no:int = 1000
        do_it:bool = False
        curr_date:date = None
        lrate:decimal = 0
        ebdisc_flag:bool = False
        kbdisc_flag:bool = False
        rate_found:bool = False
        early_flag:bool = False
        kback_flag:bool = False
        ct:str = ""
        contcode:str = ""
        W1 = Waehrung
        Resline = Res_line

        for resline in db_session.query(Resline).filter(
                (Resline.resnr == resnr) &  (Resline.reslinnr == reslinnr)).all():
            ebdisc_flag = re.match(".*ebdisc.*",resline.zimmer_wunsch)
            kbdisc_flag = re.match(".*kbdisc.*",resline.zimmer_wunsch)

            if resline.l_zuordnung[0] != 0:
                curr_zikatnr = resline.l_zuordnung[0]
            else:
                curr_zikatnr = resline.zikatnr

            zimkateg = db_session.query(Zimkateg).filter(
                    (Zimkateg.zikatnr == resline.zikatnr)).first()

            arrangement = db_session.query(Arrangement).filter(
                    (Arrangement == resline.arrangement)).first()
            ankunft = resline.ankunft
            abreise = resline.abreise
            fixed_rate = False

            if resline.was_status == 1:
                fixed_rate = True
            co_date = resline.abreise

            if co_date > resline.ankunft:
                co_date = co_date - 1
            create_bonus()
            for datum in range(resline.ankunft,co_date + 1) :
                bill_date = datum
                argt_rate = 0
                rm_rate = resline.zipreis
                pax = resline.erwachs

                if fixed_rate:

                    reslin_queasy = db_session.query(Reslin_queasy).filter(
                            (func.lower(Reslin_queasy.key) == "arrangement") &  (Reslin_queasy.resnr == resline.resnr) &  (Reslin_queasy.reslinnr == resline.reslinnr) &  (Reslin_queasy.datum >= Reslin_queasy.date1) &  (Reslin_queasy.datum <= Reslin_queasy.date2)).first()

                    if reslin_queasy:
                        rm_rate = reslin_queasy.deci1

                        if reslin_queasy.number3 != 0:
                            pax = reslin_queasy.number3
                    rm_rate, it_exist = usr_prog1(datum, rm_rate)
                else:

                    guest = db_session.query(Guest).filter(
                            (Guest.gastnr == resline.gastnr)).first()

                    guest_pr = db_session.query(Guest_pr).filter(
                            (Guest_pr.gastnr == guest.gastnr)).first()

                    if guest_pr:

                        queasy = db_session.query(Queasy).filter(
                                (Queasy.key == 18) &  (Queasy.number1 == resline.reserve_int)).first()

                        if queasy and queasy.logi3:
                            bill_date = resline.ankunft

                        if new_contrate:
                            rate_found, rm_rate, early_flag, kback_flag = get_output(ratecode_rate(ebdisc_flag, kbdisc_flag, resline.resnr, resline.reslinnr, guest_pr.CODE, None, bill_date, resline.ankunft, resline.abreise, resline.reserve_int, arrangement.argtnr, curr_zikatnr, resline.erwachs, resline.kind1, resline.kind2, resline.reserve_dec, resline.betriebsnr))
                        else:
                            rm_rate, rate_found = get_output(pricecod_rate(resline.resnr, resline.reslinnr, guest_pr.CODE, bill_date, resline.ankunft, resline.abreise, resline.reserve_int, arrangement.argtnr, curr_zikatnr, resline.erwachs, resline.kind1, resline.kind2, resline.reserve_dec, resline.betriebsnr))
                            rm_rate, it_exist = usr_prog2(datum, rm_rate)

                            if it_exist:
                                rate_found = True

                            if not it_exist and bonus_array[datum - resline.ankunft + 1 - 1] :
                                rm_rate = 0
                lrate = rm_rate

                if datum < billdate:

                    genstat = db_session.query(Genstat).filter(
                            (Genstat.resnr == resnr) &  (Genstat.res_int[0] == reslinnr) &  (Genstat.datum == datum)).first()

                    if genstat:
                        rm_rate = genstat.rateLocal
                    else:

                        exrate = db_session.query(exrate).filter(
                                (exrate.artnr == resline.betriebsnr) &  (exrate.datum == datum)).first()

                        if exrate:
                            lrate = rm_rate * exrate.betrag
                else:

                    waehrung = db_session.query(Waehrung).filter(
                            (Waehrungsnr == resline.betriebsnr)).first()

                    if waehrung:
                        lrate = rm_rate * waehrung.ankauf / waehrung.einheit

                s_list = query(s_list_list, filters=(lambda s_list :s_list.bezeich == arrangement.argt_rgbez and s_list.rmcat == zimkateg.kurzbez and s_list.preis == rm_rate and s_list.lrate == lrate and s_list.datum == datum and s_list.ankunft == resline.ankunft and s_list.abreise == resline.abreise and s_list.erwachs == pax and s_list.kind1 == resline.kind1 and s_list.kind2 == resline.kind2), first=True)

                if not s_list:
                    s_list = S_list()
                    s_list_list.append(s_list)

                    s_list.bezeich = arrangement.argt_rgbez
                    s_list.rmcat = zimkateg.kurzbez
                    s_list.preis = rm_rate
                    s_list.lrate = lrate
                    s_list.datum = datum
                    s_list.ankunft = resline.ankunft
                    s_list.abreise = resline.abreise
                    s_list.erwachs = pax
                    s_list.kind1 = resline.kind1
                    s_list.kind2 = resline.kind2


                s_list.qty = s_list.qty + resline.zimmeranz

                for fixleist in db_session.query(Fixleist).filter(
                        (Fixleist.resnr == resline.resnr) &  (Fixleist.reslinnr == resline.reslinnr)).all():
                    add_it = False
                    argt_rate = 0

                    if fixleist.sequenz == 1:
                        add_it = True

                    elif fixleist.sequenz == 2 or fixleist.sequenz == 3:

                        if resline.ankunft == datum:
                            add_it = True

                    elif fixleist.sequenz == 4 and get_day(datum) == 1:
                        add_it = True

                    elif fixleist.sequenz == 5 and get_day(datum + 1) == 1:
                        add_it = True

                    elif fixleist.sequenz == 6:

                        if fixleist.lfakt == None:
                            delta = 0
                        else:
                            delta = fixleist.lfakt - resline.ankunft

                            if delta < 0:
                                delta = 0
                        start_date = resline.ankunft + delta

                        if (resline.abreise - start_date) < fixleist.dekade:
                            start_date = resline.ankunft

                        if datum <= (start_date + (fixleist.dekade - 1)):
                            add_it = True

                        if datum < start_date:
                            add_it = False

                    if add_it:

                        artikel = db_session.query(Artikel).filter(
                                (Artikel.artnr == fixleist.artnr) &  (Artikel.departement == fixleist.departement)).first()
                        argt_rate = fixleist.betrag * fixleist.number

                        if not fixed_rate and guest_pr:
                            contcode = guest_pr.CODE
                            ct = resline.zimmer_wunsch

                            if re.match(".*\$CODE\$.*",ct):
                                ct = substring(ct,0 + get_index(ct, "$CODE$") + 6)
                                contcode = substring(ct, 0,1 + get_index(ct, ";") - 1)

                            reslin_queasy = db_session.query(Reslin_queasy).filter(
                                    (func.lower(Reslin_queasy.key) == "argt_line") &  (func.lower(Reslin_queasy.char1) == (contcode).lower()) &  (Reslin_queasy.number1 == resline.reserve_int) &  (Reslin_queasy.number2 == arrangement.argtnr) &  (Reslin_queasy.reslinnr == resline.zikatnr) &  (Reslin_queasy.number3 == fixleist.artnr) &  (Reslin_queasy.resnr == fixleist.departement) &  (Reslin_queasy.bill_date >= Reslin_queasy.date1) &  (Reslin_queasy.bill_date <= Reslin_queasy.date2)).first()

                            if reslin_queasy:
                                argt_rate = reslin_queasy.deci1 * fixleist.number

                    if argt_rate != 0:

                        s_list = query(s_list_list, filters=(lambda s_list :s_list.bezeich == artikel.bezeich and s_list.preis == (argt_rate / fixleist.number) and s_list.datum == datum and s_list.ankunft == resline.ankunft and s_list.abreise == resline.abreise and s_list.erwachs == pax and s_list.kind1 == resline.kind1 and s_list.kind2 == resline.kind2), first=True)

                        if not s_list:
                            s_list = S_list()
                            s_list_list.append(s_list)

                            s_list.nr = artikel.artnr
                            s_list.bezeich = artikel.bezeich
                            s_list.preis = argt_rate / fixleist.number
                            s_list.datum = datum
                            s_list.ankunft = resline.ankunft
                            s_list.abreise = resline.abreise
                            s_list.erwachs = pax
                            s_list.kind1 = resline.kind1
                            s_list.kind2 = resline.kind2
                        s_list.qty = s_list.qty + (fixleist.number * resline.zimmeranz)

        for s_list in query(s_list_list):

            if s_list.nr == 0:

                t_list = query(t_list_list, filters=(lambda t_list :t_list.bezeich == s_list.bezeich and t_list.rmcat == s_list.rmcat and t_list.preis == s_list.preis and t_list.lrate == s_list.lrate and t_list.ankunft == s_list.ankunft and t_list.abreise == s_list.abreise and t_list.erwachs == s_list.erwachs and t_list.kind1 == s_list.kind1 and t_list.kind2 == s_list.kind2), first=True)

                if not t_list:
                    t_list = T_list()
                    t_list_list.append(t_list)

                    t_list.nr = s_list.nr
                    t_list.bezeich = s_list.bezeich
                    t_list.rmcat = s_list.rmcat
                    t_list.preis = s_list.preis
                    t_list.lrate = s_list.lrate
                    t_list.date1 = s_list.datum
                    t_list.ankunft = s_list.ankunft
                    t_list.abreise = s_list.abreise
                    t_list.erwachs = s_list.erwachs
                    t_list.kind1 = s_list.kind1
                    t_list.kind2 = s_list.kind2


                t_list.tage = t_list.tage + 1
                t_list.date2 = s_list.datum

                if s_list.datum == t_list.date1:
                    t_list.qty = t_list.qty + s_list.qty
            else:

                t_list = query(t_list_list, filters=(lambda t_list :t_list.bezeich == s_list.bezeich and t_list.preis == s_list.preis and t_list.lrate == s_list.lrate and t_list.ankunft == s_list.ankunft and t_list.abreise == s_list.abreise and t_list.erwachs == s_list.erwachs and t_list.kind1 == s_list.kind1 and t_list.kind2 == s_list.kind2), first=True)

                if not t_list:
                    t_list = T_list()
                    t_list_list.append(t_list)

                    t_list.nr = s_list.nr
                    t_list.bezeich = s_list.bezeich
                    t_list.preis = s_list.preis
                    t_list.lrate = s_list.lrate
                    t_list.date1 = s_list.datum
                    t_list.ankunft = s_list.ankunft
                    t_list.abreise = s_list.abreise
                    t_list.erwachs = s_list.erwachs
                    t_list.kind1 = s_list.kind1
                    t_list.kind2 = s_list.kind2


                t_list.tage = t_list.tage + 1
                t_list.date2 = s_list.datum

                if s_list.datum == t_list.date1:
                    t_list.qty = t_list.qty + s_list.qty
            s_list_list.remove(s_list)

        for t_list in query(t_list_list):
            t_list.betrag = t_list.qty * t_list.tage * t_list.lrate

        if rechnr > 0:

            bill_line_obj_list = []
            for bill_line, artikel in db_session.query(Bill_line, Artikel).join(Artikel,(Artikel.artnr == Bill_line.artnr) &  (Artikel.departement == Bill_line.departement)).filter(
                    (Bill_line.rechnr == bill.rechnr)).all():
                if bill_line._recid in bill_line_obj_list:
                    continue
                else:
                    bill_line_obj_list.append(bill_line._recid)


                do_it = True

                if artikel.artart == 9:

                    arrangement = db_session.query(Arrangement).filter(
                            (Arrangement.argt_artikelnr == artikel.artnr)).first()

                    if not arrangement or arrangement.segmentcode == 0:
                        do_it = False

                if do_it:
                    t_list = T_list()
                    t_list_list.append(t_list)

                    curr_no = curr_no + 1
                    t_list.nr = curr_no
                    t_list.bezeich = bill_line.bezeich
                    t_list.preis = 0
                    t_list.date1 = bill_line.bill_datum
                    t_list.betrag = bill_line.betrag

    def usr_prog1(bill_date:date, roomrate:decimal):

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        it_exist = False
        prog_str:str = ""
        i:int = 0

        def generate_inner_output():
            return it_exist

        reslin_queasy = db_session.query(Reslin_queasy).filter(
                (func.lower(Reslin_queasy.key) == "rate_prog") &  (Reslin_queasy.number1 == resnr) &  (Reslin_queasy.number2 == 0) &  (Reslin_queasy.char1 == "") &  (Reslin_queasy.reslinnr == 1)).first()

        if reslin_queasy:
            prog_str = reslin_queasy.char3

        if prog_str != "":
            for i in range(1,len(prog_str)  + 1) :
            compile value (".\\__rate.p")
            dos silent "del .\\__rate.p"

            if not compiler:ERROR:
                roomrate = value(".\\__rate.p") (0, resnr, reslinnr, bill_date, roomrate, False)
                it_exist = True


        return generate_inner_output()

    def usr_prog2(bill_date:date, roomrate:decimal):

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        it_exist = False
        prog_str:str = ""
        i:int = 0

        def generate_inner_output():
            return it_exist

        queasy = db_session.query(Queasy).filter(
                (Queasy.key == 2) &  (Queasy.char1 == guest_pr.code)).first()

        if queasy:
            prog_str = queasy.char3

        if prog_str != "":
            for i in range(1,len(prog_str)  + 1) :

            if not compiler:ERROR:
                roomrate = value(".\\__rate.p") (0, resnr, reslinnr, bill_date, roomrate, False)
                it_exist = True


        return generate_inner_output()

    def get_vat(inp_str:str):

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        mwst = 0
        tokcounter:int = 0
        messtr:str = ""
        mestoken:str = ""
        mesvalue:str = ""

        def generate_inner_output():
            return mwst
        IF1 + get_index(inp_str, "vat%") = 0 THEN

        return generate_inner_output()
        for tokcounter in range(1,num_entries(inp_str, ";") - 1 + 1) :
            messtr = entry(tokcounter - 1, inp_str, ";")
            mestoken = entry(0, messtr, ",")
            mesvalue = entry(1, messtr, ",")

            if mestoken == "vat%":
                mwst = decimal.Decimal(mesvalue) / 100

                return generate_inner_output()


        return generate_inner_output()

    def update_bill():

        nonlocal succes_flag, outfile, run_ask, bill_list_list, output_list_list, lvcarea, new_contrate, billdate, price_decimal, vat_artnr, n, serv_vat, briefnr2, briefnr21, print_rc, f_gastnr, f_resnr, f_resline, f_bill, longer_billamt, long_billamt, master_ankunft, master_abreise, fixrate_flag, long_digit, exchg_rate, curr_line, curr_page, curr_pos, blloop, headloop, f_lmargin, lmargin, proforma_inv, bline_flag, keychar, bl_balance, bl_balance1, bl0_balance, bl0_balance1, bl1_balance, bl1_balance1, bline_nr, print_all_member, g_length, d_length, c_length, w_length, v_length, print_member, short_arrival, short_depart, ntab, nskip, wd_array, bonus_array, curr_bl_vat, bl_netto, res_line, reservation, bediener, htparam, guest, bill, bill_line, waehrung, printer, briefzei, artikel, queasy, printcod, akt_kont, zimkateg, zimmer, master, guest_pr, reslin_queasy, arrangement, katpreis, exrate, fixleist, genstat
        nonlocal rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1


        nonlocal brief_list, htp_list, loop_list, loop1_list, header_list, bill_list, output_list, s_list, t_list, bline_list, t_spbill_list, rmember, mainres, foart, resline, rline, gmember, guest1, gast, mbill, rsvguest, gbuff, mresline, exchg_buff, htp, w1
        nonlocal brief_list_list, htp_list_list, loop_list_list, loop1_list_list, header_list_list, bill_list_list, output_list_list, s_list_list, t_list_list, bline_list_list, t_spbill_list_list

        bill = db_session.query(Bill).filter(
                (Bill.rechnr == rechnr)).first()

        if bill:
            bill.rechnr2 = briefnr


            succes_flag = True

        bill = db_session.query(Bill).first()

    bediener = db_session.query(Bediener).filter(
            (func.lower(Bediener.userinit) == (user_init).lower())).first()

    if case_type == 2:
        update_bill()

        return generate_output()
    output_list = Output_list()
    output_list_list.append(output_list)


    htparam = db_session.query(Htparam).filter(
            (Htparam.paramnr == 550)).first()

    if htparam.feldtyp == 4:
        new_contrate = htparam.flogical

    htparam = db_session.query(Htparam).filter(
            (Htparam.paramnr == 110)).first()
    billdate = htparam.fdate

    htparam = db_session.query(Htparam).filter(
            (Htparam.paramnr == 491)).first()
    price_decimal = htparam.finteger

    htparam = db_session.query(Htparam).filter(
            (Htparam.paramnr == 132)).first()

    if htparam.feldtyp == 1:
        vat_artnr[0] = htparam.finteger

    elif htparam.feldtyp == 5:
        for n in range(1,num_entries(htparam.fchar, ";")  + 1) :

            if trim(entry(n - 1, htparam.fchar, ";")) != "" and n <= 5:
                vat_artnr[n - 1] = to_int(trim(entry(n - 1, htparam.fchar, ";")))

    htparam = db_session.query(Htparam).filter(
            (Htparam.paramnr == 479)).first()
    serv_vat = htparam.flogical

    htparam = db_session.query(Htparam).filter(
            (Htparam.paramnr == 415)).first()
    briefnr2 = htparam.finteger

    htparam = db_session.query(Htparam).filter(
            (Htparam.paramnr == 495)).first()
    briefnr21 = htparam.finteger

    htparam = db_session.query(Htparam).filter(
            (Htparam.paramnr == 435)).first()
    print_rc = (htparam.finteger == briefnr)

    guest = db_session.query(Guest).filter(
            (Guest.gastnr == gastnr)).first()

    if guest:
        f_gastnr = True

    reservation = db_session.query(Reservation).filter(
            (Reservation.resnr == resnr)).first()

    if reservation:
        f_resnr = True
    f_resline = False

    if resnr > 0 and reslinnr > 0:

        res_line = db_session.query(Res_line).filter(
                (Res_line.resnr == resnr) &  (Res_line.reslinnr == reslinnr)).first()

        if res_line:
            f_resline = True

    bill = db_session.query(Bill).filter(
            (Bill.rechnr == rechnr)).first()

    if bill:
        f_bill = True

        for bill_line in db_session.query(Bill_line).filter(
                (Bill_line.rechnr == bill.rechnr)).all():

            if (bill_line.betrag <= -1000000000) or (bill_line.betrag >= 1000000000):
                longer_billamt = True
                break

            elif bill_line.betrag <= -100000000 or (bill_line.betrag >= 1000000000):
                long_billamt = True

    if f_bill and bill.resnr > 0 and bill.reslinnr == 0:

        res_line = db_session.query(Res_line).filter(
                (Res_line.resnr == bill.resnr) &  (Res_line.resstatus == 6)).first()

        if not res_line:

            res_line = db_session.query(Res_line).filter(
                    (Res_line.resnr == bill.resnr) &  (Res_line.resstatus == 8)).first()

        if res_line:
            f_resline = True
            master_ankunft = res_line.ankunft
            master_abreise = res_line.abreise

            for rmember in db_session.query(Rmember).filter(
                    (Rmember.resnr == bill.resnr) &  (Rmember.resstatus >= 6) &  (Rmember.resstatus <= 8)).all():

                if rmember.ankunft < master_ankunft:
                    master_ankunft = rmember.ankunft

                if rmember.abreise > master_abreise:
                    master_abreise = rmember.abreise

    htparam = db_session.query(Htparam).filter(
            (Htparam.paramnr == 264)).first()
    fixrate_flag = htparam.flogical

    htparam = db_session.query(Htparam).filter(
            (Htparam.paramnr == 246)).first()
    long_digit = htparam.flogical

    if f_resline:

        if res_line.reserve_dec != 0:
            exchg_rate = res_line.reserve_dec
        else:

            waehrung = db_session.query(Waehrung).filter(
                    (Waehrungsnr == res_line.betriebsnr)).first()

            if waehrung:
                exchg_rate = waehrung.ankauf / waehrung.einheit
            else:

                htparam = db_session.query(Htparam).filter(
                        (Htparam.paramnr == 144)).first()

                waehrung = db_session.query(Waehrung).filter(
                        (Waehrung.wabkurz == htparam.fchar)).first()

                if waehrung:
                    exchg_rate = waehrung.ankauf / waehrung.einheit
    else:

        htparam = db_session.query(Htparam).filter(
                (Htparam.paramnr == 144)).first()

        waehrung = db_session.query(Waehrung).filter(
                (Waehrung.wabkurz == htparam.fchar)).first()

        if waehrung:
            exchg_rate = waehrung.ankauf / waehrung.einheit

    if printnr == 0:
        outfile = ".\\vhp_letter.rtf"
    else:

        printer = db_session.query(Printer).filter(
                (Printer.nr == printnr)).first()

        if not printer:

            return generate_output()
        else:
            outfile = printer.path
    fill_list()
    curr_line = 1
    curr_page = 1

    for brief_list in query(brief_list_list):

        if curr_line >= printer.pglen:
            output_list.str = output_list.str + ""


            output_list = Output_list()
            output_list_list.append(output_list)

            curr_page = curr_page + 1
            curr_line = 1
            do_billhead()
        curr_pos = 1
        analyse_text()

        if blloop == 0 and headloop == 0:

            if f_lmargin:
                for n in range(1,lmargin + 1) :
                    put_string(" ")
            build_text_line(brief_list.b_text)
            output_list.str = output_list.str + ""


            output_list = Output_list()
            output_list_list.append(output_list)

            curr_line = curr_line + 1
            curr_pos = 1

        elif blloop == 2:
            loop_list = Loop_list()
            loop_list_list.append(loop_list)

            loop_list.texte = brief_list.b_text
            curr_pos = 1

        elif headloop == 2:
            loop1_list = Loop1_list()
            loop1_list_list.append(loop1_list)

            loop1_list.texte = brief_list.b_text
            curr_pos = 1

        elif blloop == 3:

            if proforma_inv:
                do_pbill_line()
            else:

                if bline_flag == -1:

                    if not spbill_flag:

                        if inv_type == 1:
                            do_billlinea()

                        elif inv_type == 2:
                            do_billlineb()

                        elif inv_type >= 3:
                            do_billlinec()
                    else:
                        do_spbillline()

                elif bline_flag == 0:

                    if not spbill_flag:

                        if inv_type == 1:
                            do_billline0()

                        elif inv_type == 2:
                            do_billlineb()

                        elif inv_type >= 3:
                            do_billline0c()
                    else:

                        if inv_type == 1:
                            do_spbillline0()

                        elif inv_type == 2:
                            do_spbillline0b()

                        elif inv_type >= 3:
                            do_spbillline0c()

                elif bline_flag == 1:

                    if not spbill_flag:
                        do_billline1()
                    else:
                        do_spbillline1()

                elif bline_flag == 2:

                    if not spbill_flag:
                        do_billline2()
                    else:
                        do_spbillline2()

        elif headloop == 3:
            do_billhead()

        if blloop == 1:
            blloop = 2

        if headloop == 1:
            headloop = 2

    htparam = db_session.query(Htparam).filter(
            (Htparam.paramnr == 465)).first()

    if (not proforma_inv) and bill and bill.rechnr != 0 and htparam.flogical:
        run_ask = True

    for bill in db_session.query(Bill).filter(
            (Bill.rechnr == rechnr)).all():
        buffer_copy(bill, bill_list)

    return generate_output()