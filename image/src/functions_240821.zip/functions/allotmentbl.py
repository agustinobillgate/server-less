from functions.additional_functions import *
import decimal
from datetime import date
from sqlalchemy import func
from models import Kontline, Bediener, Zimkateg, Res_line

def allotmentbl(case_type:int, gastnr:int, kon_gastnr:int, kontcode:str, ankunft:date, abreise:date, zimmeranz:int):
    allotment_list_list = []
    check_resline_list_list = []
    allot_list_list = []
    s_list_list = []
    d1:date = None
    d2:date = None
    datum:date = None
    d:date = None
    kontline = bediener = zimkateg = res_line = None

    allotment_list = check_resline_list = allot_list = s_list = None

    allotment_list_list, Allotment_list = create_model_like(Kontline, {"kurzbez":str, "userinit":str})
    check_resline_list_list, Check_resline_list = create_model("Check_resline_list", {"resnr":int, "name":str, "abreise":date, "ankunft":date})
    allot_list_list, Allot_list = create_model("Allot_list", {"datum":date, "anz":int})
    s_list_list, S_list = create_model("S_list", {"datum":date, "tag":str, "qty":int, "occ":int, "vac":int, "ovb":int})


    db_session = local_storage.db_session

    def generate_output():
        nonlocal allotment_list_list, check_resline_list_list, allot_list_list, s_list_list, d1, d2, datum, d, kontline, bediener, zimkateg, res_line


        nonlocal allotment_list, check_resline_list, allot_list, s_list
        nonlocal allotment_list_list, check_resline_list_list, allot_list_list, s_list_list
        return {"allotment-list": allotment_list_list, "check-resline-list": check_resline_list_list, "allot-list": allot_list_list, "s-list": s_list_list}

    def assign_it():

        nonlocal allotment_list_list, check_resline_list_list, allot_list_list, s_list_list, d1, d2, datum, d, kontline, bediener, zimkateg, res_line


        nonlocal allotment_list, check_resline_list, allot_list, s_list
        nonlocal allotment_list_list, check_resline_list_list, allot_list_list, s_list_list

        kontline_obj_list = []
        for kontline, bediener in db_session.query(Kontline, Bediener).join(Bediener,(Bediener.nr == Kontline.bediener_nr)).filter(
                (Kontline.gastnr == gastnr) &  (Kontline.kontignr > 0) &  (Kontline.betriebsnr == 0) &  (Kontline.kontstat == 1)).all():
            if kontline._recid in kontline_obj_list:
                continue
            else:
                kontline_obj_list.append(kontline._recid)

            zimkateg = db_session.query(Zimkateg).filter(
                    (Zimkateg.zikatnr == kontline.zikatnr)).first()
            allotment_list = Allotment_list()
            allotment_list_list.append(allotment_list)

            buffer_copy(kontline, allotment_list)
            allotment_list.userinit = bediener.userinit

            if zimkateg:
                allotment_list.kurzbez = zimkateg.kurzbez

    def check_resline():

        nonlocal allotment_list_list, check_resline_list_list, allot_list_list, s_list_list, d1, d2, datum, d, kontline, bediener, zimkateg, res_line


        nonlocal allotment_list, check_resline_list, allot_list, s_list
        nonlocal allotment_list_list, check_resline_list_list, allot_list_list, s_list_list

        res_line_obj_list = []
        for res_line, kontline in db_session.query(Res_line, Kontline).join(Kontline,(Kontline.kontignr == Res_line.kontignr) &  (func.lower(Kontline.(kontcode).lower()) == (kontcode).lower()) &  (Kontline.kontstat == 1)).filter(
                (Res_line.kontignr != 0) &  (Res_line.gastnr == kon_gastnr) &  (Res_line.active_flag < 2) &  (Res_line.resstatus < 11)).all():
            if res_line._recid in res_line_obj_list:
                continue
            else:
                res_line_obj_list.append(res_line._recid)

            if res_line.abreise <= kontline.ankunft or res_line.ankunft > kontline.abreise:
                1
            else:
                check_resline_list = Check_resline_list()
                check_resline_list_list.append(check_resline_list)

                check_resline_list.resnr = res_line.resnr
                check_resline_list.name = res_line.name
                check_resline_list.abreise = res_line.abreise
                check_resline_list.ankunft = res_line.ankunft

    def check_allotment():

        nonlocal allotment_list_list, check_resline_list_list, allot_list_list, s_list_list, d1, d2, datum, d, kontline, bediener, zimkateg, res_line


        nonlocal allotment_list, check_resline_list, allot_list, s_list
        nonlocal allotment_list_list, check_resline_list_list, allot_list_list, s_list_list

        res_line_obj_list = []
        for res_line, kontline in db_session.query(Res_line, Kontline).join(Kontline,(Kontline.kontignr == Res_line.kontignr) &  (func.lower(Kontline.(kontcode).lower()) == (kontcode).lower()) &  (Kontline.kontstat == 1)).filter(
                (Res_line.kontignr != 0) &  (Res_line.gastnr == gastnr) &  (Res_line.active_flag < 2) &  (Res_line.resstatus < 11) &  (not (Res_line.ankunft > abreise)) &  (not (Res_line.abreise < ankunft))).all():
            if res_line._recid in res_line_obj_list:
                continue
            else:
                res_line_obj_list.append(res_line._recid)

            if res_line.ankunft >= ankunft:
                d1 = res_line.ankunft
            else:
                d1 = ankunft

            if res_line.abreise <= abreise:
                d2 = res_line.abreise - 1
            else:
                d2 = abreise
            for datum in range(d1,d2 + 1) :

                allot_list = query(allot_list_list, filters=(lambda allot_list :allot_list.datum == datum), first=True)

                if not allot_list:
                    allot_list = Allot_list()
                    allot_list_list.append(allot_list)

                    allot_list.datum = datum
                    allot_list.anz = zimmeranz
                allot_list.anz = allot_list.anz - res_line.zimmeranz

    def create_slist():

        nonlocal allotment_list_list, check_resline_list_list, allot_list_list, s_list_list, d1, d2, datum, d, kontline, bediener, zimkateg, res_line


        nonlocal allotment_list, check_resline_list, allot_list, s_list
        nonlocal allotment_list_list, check_resline_list_list, allot_list_list, s_list_list

        weekdays:[str] = ["", "", "", "", "", "", "", "", ""]
        for d in range(ankunft,abreise + 1) :
            s_list = S_list()
            s_list_list.append(s_list)

            s_list.datum = d
            s_list.qty = zimmeranz
            s_list.vac = zimmeranz


            s_list.tag = weekdays[get_weekday(s_list.datum) - 1]

        res_line_obj_list = []
        for res_line, kontline in db_session.query(Res_line, Kontline).join(Kontline,(Kontline.kontignr == Res_line.kontignr) &  (func.lower(Kontline.(kontcode).lower()) == (kontcode).lower()) &  (Kontline.kontstat == 1)).filter(
                (Res_line.kontignr != 0) &  (Res_line.gastnr == gastnr) &  (Res_line.active_flag < 2) &  (Res_line.resstatus < 11)).all():
            if res_line._recid in res_line_obj_list:
                continue
            else:
                res_line_obj_list.append(res_line._recid)

            if res_line.abreise <= ankunft or res_line.ankunft > abreise:
                1
            else:
                for d in range(res_line.ankunft,(res_line.abreise - 1)  + 1) :

                    s_list = query(s_list_list, filters=(lambda s_list :s_list.datum == d), first=True)

                    if s_list:
                        s_list.vac = s_list.vac - res_line.zimmeranz
                        s_list.occ = s_list.occ + res_line.zimmeranz


    if case_type == 1:
        assign_it()

    elif case_type == 2:
        check_resline()

    elif case_type == 3:
        check_allotment()

    elif case_type == 4:
        create_slist()

    return generate_output()