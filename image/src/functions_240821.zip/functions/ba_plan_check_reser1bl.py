from functions.additional_functions import *
import decimal
from datetime import date
from sqlalchemy import func
from models import Bk_reser

def ba_plan_check_reser1bl(rml_raum:str, rsv_date:date, rsv_i:int):
    t_bk_reser_list = []
    bk_reser = None

    t_bk_reser = None

    t_bk_reser_list, T_bk_reser = create_model("T_bk_reser", {"resstatus":int, "veran_nr":int})


    db_session = local_storage.db_session

    def generate_output():
        nonlocal t_bk_reser_list, bk_reser


        nonlocal t_bk_reser
        nonlocal t_bk_reser_list
        return {"t-bk-reser": t_bk_reser_list}

    for bk_reser in db_session.query(Bk_reser).filter(
            (func.lower(Bk_reser.raum) == (rml_raum).lower()) &  (Bk_reser.datum == rsv_date) &  (Bk_reser.rsv_i >= Bk_reser.von_i) &  (Bk_reser.rsv_i <= Bk_reser.bis_i) &  (Bk_reser.resstatus <= 2)).all():
        t_bk_reser = T_bk_reser()
        t_bk_reser_list.append(t_bk_reser)

        t_bk_reser.resstatus = bk_reser.resstatus
        t_bk_reser.veran_nr = bk_reser.veran_nr

    return generate_output()