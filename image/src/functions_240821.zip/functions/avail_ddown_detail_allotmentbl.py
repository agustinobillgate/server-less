from functions.additional_functions import *
import decimal
from datetime import date
from models import Kontline, Zimmer

def avail_ddown_detail_allotmentbl(curr_zikat:int, datum:date):
    rlist_list = []
    kontline = zimmer = None

    rlist = None

    rlist_list, Rlist = create_model("Rlist", {"resnr":str, "zinr":str, "ankunft":date, "abreise":date, "zimmeranz":int, "resstatus":int, "zipreis":decimal, "erwachs":int, "kind1":int, "gratis":int, "name":str, "rsvname":str, "confirmed":bool, "sleeping":bool, "bezeich":str, "res_status":str}, {"sleeping": True})


    db_session = local_storage.db_session

    def generate_output():
        nonlocal rlist_list, kontline, zimmer


        nonlocal rlist
        nonlocal rlist_list
        return {"rlist": rlist_list}

    def detail_allotments():

        nonlocal rlist_list, kontline, zimmer


        nonlocal rlist
        nonlocal rlist_list

        if curr_zikat == 0:

            for kontline in db_session.query(Kontline).filter(
                    (Kontline.betriebsnr == 1) &  (Kontline.ankunft <= datum) &  (Kontline.abreise >= datum) &  (Kontline.kontstat == 1)).all():

                zimmer = db_session.query(Zimmer).filter(
                        (Zimmer.zikatnr == kontline.zikatnr) &  (Zimmer.sleeping)).first()
                rlist = Rlist()
                rlist_list.append(rlist)

                rlist.zimmeranz = kontline.zimmeranz + 1
                rlist.zinr = zimmer.zinr
                rlist.name = outorder.gespgrund
                rlist.abreise = kontline.abreise
                rlist.ankunft = kontline.ankunft
                rlist.bezeich = zimmer.bezeich


        else:

            for kontline in db_session.query(Kontline).filter(
                    (Kontline.betriebsnr == 1) &  (Kontline.ankunft <= datum) &  (Kontline.abreise >= datum) &  (Kontline.zikatnr == curr_zikat) &  (Kontline.kontstat == 1)).all():

                zimmer = db_session.query(Zimmer).filter(
                        (Zimmer.zikatnr == kontline.zikatnr) &  (Zimmer.sleeping)).first()
                rlist = Rlist()
                rlist_list.append(rlist)

                rlist.zimmeranz = kontline.zimmeranz + 1
                rlist.zinr = zimmer.zinr
                rlist.name = outorder.gespgrund
                rlist.abreise = kontline.abreise
                rlist.ankunft = kontline.ankunft
                rlist.bezeich = zimmer.bezeich


    detail_allotments()

    return generate_output()