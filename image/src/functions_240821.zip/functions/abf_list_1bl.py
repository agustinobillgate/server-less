from functions.additional_functions import *
import decimal
from datetime import date
from sqlalchemy import func
from models import Htparam, Res_line, Arrangement, Artikel, Argt_line, Reslin_queasy, Fixleist, Guest, Reservation, Segment, Ratecode, Genstat, Bill, Master

def abf_list_1bl(fdate:date, tdate:date, bfast_artnr:int, bfast_dept:int):
    abf_list_list = []
    datum:date = None
    to_date:date = None
    htparam = res_line = arrangement = artikel = argt_line = reslin_queasy = fixleist = guest = reservation = segment = ratecode = genstat = bill = master = None

    abf_list = invoice = None

    abf_list_list, Abf_list = create_model("Abf_list", {"zinr":str, "name":str, "segmentcode":int, "ankunft":date, "anztage":int, "abreise":date, "kurzbez":str, "arrangement":str, "zimmeranz":int, "erwachs":int, "kind1":int, "gratis":int, "resnr":int, "bemerk":str, "gastnr":int, "resstatus":int, "resname":str, "address":str, "city":str, "comments":str, "nation1":str, "bezeich":str, "zipreis":decimal, "code":str, "id":str, "bezeichnung":str})

    Invoice = Bill

    db_session = local_storage.db_session

    def generate_output():
        nonlocal abf_list_list, datum, to_date, htparam, res_line, arrangement, artikel, argt_line, reslin_queasy, fixleist, guest, reservation, segment, ratecode, genstat, bill, master
        nonlocal invoice


        nonlocal abf_list, invoice
        nonlocal abf_list_list
        return {"abf-list": abf_list_list}

    def disp_arlist():

        nonlocal abf_list_list, datum, to_date, htparam, res_line, arrangement, artikel, argt_line, reslin_queasy, fixleist, guest, reservation, segment, ratecode, genstat, bill, master
        nonlocal invoice


        nonlocal abf_list, invoice
        nonlocal abf_list_list

        do_it:bool = False
        roflag:bool = False
        epreis:decimal = 0
        qty:int = 0
        i:int = 0
        str:str = ""
        contcode:str = ""
        dont_post:bool = False
        abf_list_list.clear()

        for res_line in db_session.query(Res_line).filter(
                (Res_line.ankunft < fdate) &  (Res_line.abreise >= fdate) &  ((Res_line.resstatus != 3) &  (Res_line.resstatus != 4) &  (Res_line.resstatus != 8) &  (Res_line.resstatus != 9) &  (Res_line.resstatus != 10) &  (Res_line.resstatus != 12)) &  (Res_line.active_flag <= 1) &  (Res_line.l_zuordnung[2] == 0)).all():
            do_it = False
            roflag = True
            qty = 0

            if (res_line.erwachs + res_line.kind1 + res_line.gratis + res_line.l_zuordnung[3]) == 0:
                1
            else:

                arrangement = db_session.query(Arrangement).filter(
                        (Arrangement == res_line.arrangement)).first()

                if arrangement:

                    argt_line_obj_list = []
                    for argt_line, artikel in db_session.query(Argt_line, Artikel).join(Artikel,(Artikel.artnr == Argt_line.argt_artnr) &  (Artikel.departement == bfast_dept) &  (Artikel.zwkum == bfast_artnr)).filter(
                            (Argt_line.argtnr == arrangement.argtnr)).all():
                        if argt_line._recid in argt_line_obj_list:
                            continue
                        else:
                            argt_line_obj_list.append(argt_line._recid)


                        do_it = True
                        roflag = False
                        epreis = argt_line.betrag


                        break


            if do_it and epreis == 0:
                contcode = ""

                for i in range(1,num_entries(res_line.zimmer_wunsch, ";") - 1 + 1) :
                    str = entry(i - 1, res_line.zimmer_wunsch, ";")

                    if substring(str, 0, 6) == "$CODE$":
                        contcode = substring(str, 6)
                        break

                if contcode != "":

                    reslin_queasy = db_session.query(Reslin_queasy).filter(
                            (func.lower(Reslin_queasy.key) == "argt_line") &  (Reslin_queasy.char1 == guest_pr.CODE) &  (Reslin_queasy.number1 == res_line.reserve_int) &  (Reslin_queasy.number2 == arrangement.argtnr) &  (Reslin_queasy.number3 == bfast_artnr) &  (Reslin_queasy.resnr == bfast_dept) &  (Reslin_queasy.reslinnr == res_line.zikatnr) &  (Reslin_queasy.date1 <= fdate) &  (Reslin_queasy.date2 >= fdate) &  (Reslin_queasy.deci1 > 0)).first()

                if not reslin_queasy:

                    reslin_queasy = db_session.query(Reslin_queasy).filter(
                            (func.lower(Reslin_queasy.key) == "fargt_line") &  (Reslin_queasy.char1 == guest_pr.CODE) &  (Reslin_queasy.number1 == res_line.reserve_int) &  (Reslin_queasy.number2 == arrangement.argtnr) &  (Reslin_queasy.number3 == bfast_artnr) &  (Reslin_queasy.resnr == bfast_dept) &  (Reslin_queasy.date1 <= fdate) &  (Reslin_queasy.date2 >= fdate) &  (Reslin_queasy.deci1 > 0)).first()
                do_it = None != reslin_queasy
                roflag = not do_it

            if not do_it:

                for fixleist in db_session.query(Fixleist).filter(
                        (Fixleist.resnr == res_line.resnr) &  (Fixleist.reslinnr == res_line.reslinnr) &  (Fixleist.artnr == bfast_artnr) &  (Fixleist.departement == bfast_dept)).all():
                    dont_post = check_fixleist_posted(fixleist.artnr, fixleist.departement, fixleist.sequenz, fixleist.dekade, fixleist.lfakt)

                    if not dont_post:
                        do_it = True
                        qty = qty + fixleist.number

            if do_it:

                guest = db_session.query(Guest).filter(
                        (Guest.gastnr == res_line.resnr)).first()

                reservation = db_session.query(Reservation).filter(
                        (Reservation.resnr == res_line.resnr)).first()

                segment = db_session.query(Segment).filter(
                        (Segmentcode == res_line.argt_typ)).first()

                ratecode = db_session.query(Ratecode).filter(
                        (Ratecode.CODE == res_line.arrangement)).first()
                abf_list = Abf_list()
                abf_list_list.append(abf_list)


                if not roflag:
                    buffer_copy(res_line, abf_list)
                else:
                    buffer_copy(res_line, abf_list,except_fields=["erwachs","kind1","gratis"])
                    abf_list.erwachs = 0


                abf_list.segmentcode = reservation.segmentcode
                abf_list.erwachs = abf_list.erwachs + qty
                abf_list.gastnr = res_line.gastnr
                abf_list.resname = reservation.name
                abf_list.comments = reservation.bemerk
                abf_list.bezeich = segment.bezeich
                abf_list.zipreis = res_line.zipreis
                abf_list.id = reservation.useridanlage

                if abf_list.comments != "":
                    abf_list.comments = abf_list.comments + chr(10)
                abf_list.comments = abf_list.comments + res_line.bemerk

                if not roflag:
                    abf_list.kind1 = abf_list.kind1 + res_line.l_zuordnung[3]

                if zimkateg:
                    abf_list.kurzbez = zimkateg.kurzbez

                if ratecode:
                    abf_list.CODE = ratecode.CODE

                if guest:
                    abf_list.nation1 = guest.nation1
                    abf_list.address = guest.adresse1
                    abf_list.city = guest.wohnort + " " + guest.plz

    def disp_arlist1():

        nonlocal abf_list_list, datum, to_date, htparam, res_line, arrangement, artikel, argt_line, reslin_queasy, fixleist, guest, reservation, segment, ratecode, genstat, bill, master
        nonlocal invoice


        nonlocal abf_list, invoice
        nonlocal abf_list_list

        do_it:bool = False
        roflag:bool = False
        epreis:decimal = 0
        qty:int = 0
        i:int = 0
        str:str = ""
        contcode:str = ""
        dont_post:bool = False
        abf_list_list.clear()

        for genstat in db_session.query(Genstat).filter(
                ((Genstat.resstatus != 3) &  (Genstat.resstatus != 4) &  (Genstat.resstatus != 8) &  (Genstat.resstatus != 9) &  (Genstat.resstatus != 10) &  (Genstat.resstatus != 12)) &  (Genstat.datum >= fdate) &  (Genstat.datum <= tdate)).all():
            do_it = False
            roflag = True
            qty = 0

            if (genstat.erwachs + genstat.kind1 + genstat.gratis + genstat.kind3) == 0:
                1
            else:

                arrangement = db_session.query(Arrangement).filter(
                        (Arrangement == genstat.argt)).first()

                if arrangement:

                    argt_line_obj_list = []
                    for argt_line, artikel in db_session.query(Argt_line, Artikel).join(Artikel,(Artikel.artnr == Argt_line.argt_artnr) &  (Artikel.departement == bfast_dept) &  (Artikel.zwkum == bfast_artnr)).filter(
                            (Argt_line.argtnr == arrangement.argtnr)).all():
                        if argt_line._recid in argt_line_obj_list:
                            continue
                        else:
                            argt_line_obj_list.append(argt_line._recid)


                        do_it = True
                        roflag = False
                        epreis = argt_line.betrag


                        break


            if do_it and epreis == 0:
                contcode = ""

                for i in range(1,num_entries(genstat.res_char[1], ";") - 1 + 1) :
                    str = entry(i - 1, genstat.res_char[1], ";")

                    if substring(str, 0, 6) == "$CODE$":
                        contcode = substring(str, 6)
                        break

                if contcode != "":

                    reslin_queasy = db_session.query(Reslin_queasy).filter(
                            (func.lower(Reslin_queasy.key) == "argt_line") &  (Reslin_queasy.char1 == guest_pr.CODE) &  (Reslin_queasy.number1 == genstat.res_int[1]) &  (Reslin_queasy.number2 == arrangement.argtnr) &  (Reslin_queasy.number3 == bfast_artnr) &  (Reslin_queasy.resnr == bfast_dept) &  (Reslin_queasy.reslinnr == genstat.zikatnr) &  (Reslin_queasy.date1 <= fdate) &  (Reslin_queasy.date2 >= fdate) &  (Reslin_queasy.deci1 > 0)).first()

                if not reslin_queasy:

                    reslin_queasy = db_session.query(Reslin_queasy).filter(
                            (func.lower(Reslin_queasy.key) == "fargt_line") &  (Reslin_queasy.char1 == guest_pr.CODE) &  (Reslin_queasy.number1 == genstat.res_int[1]) &  (Reslin_queasy.number2 == arrangement.argtnr) &  (Reslin_queasy.number3 == bfast_artnr) &  (Reslin_queasy.resnr == bfast_dept) &  (Reslin_queasy.date1 <= fdate) &  (Reslin_queasy.date2 >= fdate) &  (Reslin_queasy.deci1 > 0)).first()
                do_it = None != reslin_queasy
                roflag = not do_it

            if not do_it:

                for fixleist in db_session.query(Fixleist).filter(
                        (Fixleist.resnr == genstat.resnr) &  (Fixleist.artnr == bfast_artnr) &  (Fixleist.departement == bfast_dept)).all():
                    dont_post = check_fixleist_posted1(fixleist.artnr, fixleist.departement, fixleist.sequenz, fixleist.dekade, fixleist.lfakt)

                    if not dont_post:
                        do_it = True
                        qty = qty + fixleist.number

            if do_it:

                guest = db_session.query(Guest).filter(
                        (Guest.gastnr == genstat.gastnrmember)).first()

                reservation = db_session.query(Reservation).filter(
                        (Reservation.resnr == genstat.resnr)).first()

                segment = db_session.query(Segment).filter(
                        (Segmentcode == genstat.segmentcode)).first()

                ratecode = db_session.query(Ratecode).filter(
                        (Ratecode.CODE == genstat.argt)).first()
                abf_list = Abf_list()
                abf_list_list.append(abf_list)


                if not roflag:
                    buffer_copy(genstat, abf_list)
                else:
                    buffer_copy(genstat, abf_list,except_fields=["erwachs","kind1","gratis","datum"])
                    abf_list.erwachs = 0


                abf_list.segmentcode = reservation.segmentcode
                abf_list.erwachs = abf_list.erwachs + qty
                abf_list.gastnr = genstat.gastnr
                abf_list.resname = reservation.name
                abf_list.comments = reservation.bemerk
                abf_list.bezeich = segment.bezeich
                abf_list.zipreis = genstat.zipreis
                abf_list.ankunft = genstat.res_date[0]
                abf_list.abreise = genstat.res_date[1]
                abf_list.id = reservation.useridanlage

                if abf_list.comments != "":
                    abf_list.comments = abf_list.comments + chr(10)

                if not roflag:
                    abf_list.kind1 = abf_list.kind1 + genstat.kind1

                if zimkateg:
                    abf_list.kurzbez = zimkateg.kurzbez

                if ratecode:
                    abf_list.CODE = ratecode.CODE

                if guest:
                    abf_list.address = guest.adresse1
                abf_list.city = guest.wohnort + " " + guest.plz
                abf_list.nation1 = guest.nation1
                abf_list.name = guest.name
                abf_list.comments = abf_list.comments + guest.bemerk

    def check_fixleist_posted(artnr:int, dept:int, fakt_modus:int, intervall:int, lfakt:date):

        nonlocal abf_list_list, datum, to_date, htparam, res_line, arrangement, artikel, argt_line, reslin_queasy, fixleist, guest, reservation, segment, ratecode, genstat, bill, master
        nonlocal invoice


        nonlocal abf_list, invoice
        nonlocal abf_list_list

        dont_post = False
        master_flag:bool = False
        delta:int = 0
        start_date:date = None

        def generate_inner_output():
            return dont_post
        Invoice = Bill

        master = db_session.query(Master).filter(
                (Master.resnr == res_line.resnr) &  (Master.active) &  (Master.flag == 0)).first()

        if master and master.umsatzart[1] :
            master_flag = True

        if master_flag:

            invoice = db_session.query(Invoice).filter(
                    (Invoice.resnr == res_line.resnr) &  (Invoice.reslinnr == 0)).first()
        else:

            invoice = db_session.query(Invoice).filter(
                    (Invoice.zinr == res_line.zinr) &  (Invoice.resnr == res_line.resnr) &  (Invoice.reslinnr == res_line.reslinnr) &  (Invoice.billtyp == 0) &  (Invoice.billnr == 1) &  (Invoice.flag == 0)).first()

        if not dont_post:

            if fakt_modus == 2:

                if res_line.ankunft != fdate:
                    dont_post = True

            elif fakt_modus == 3:

                if (res_line.ankunft + 1) != fdate:
                    dont_post = True

            elif fakt_modus == 4:

                if get_day(fdate) != 1:
                    dont_post = True

            elif fakt_modus == 5:

                if get_day(fdate + timedelta(days=1)) != 1:
                    dont_post = True

            elif fakt_modus == 6:

                if lfakt == None:
                    delta = 0
                else:
                    delta = lfakt - res_line.ankunft

                    if delta < 0:
                        delta = 0
                start_date = res_line.ankunft + delta

                if (res_line.abreise - start_date) < intervall:
                    start_date = res_line.ankunft

                if fdate > (start_date + (intervall - 1)):
                    dont_post = True

                if fdate < start_date:
                    dont_post = True


        return generate_inner_output()

    def check_fixleist_posted1(artnr:int, dept:int, fakt_modus:int, intervall:int, lfakt:date):

        nonlocal abf_list_list, datum, to_date, htparam, res_line, arrangement, artikel, argt_line, reslin_queasy, fixleist, guest, reservation, segment, ratecode, genstat, bill, master
        nonlocal invoice


        nonlocal abf_list, invoice
        nonlocal abf_list_list

        dont_post = False
        master_flag:bool = False
        delta:int = 0
        start_date:date = None

        def generate_inner_output():
            return dont_post
        Invoice = Bill

        master = db_session.query(Master).filter(
                (Master.resnr == res_line.resnr) &  (Master.active) &  (Master.flag == 0)).first()

        if master and master.umsatzart[1] :
            master_flag = True

        if master_flag:

            invoice = db_session.query(Invoice).filter(
                    (Invoice.resnr == genstat.resnr) &  (Invoice.reslinnr == 0)).first()
        else:

            invoice = db_session.query(Invoice).filter(
                    (Invoice.zinr == genstat.zinr) &  (Invoice.resnr == genstat.resnr) &  (Invoice.reslinnr == genstat.res_int[0]) &  (Invoice.billtyp == 0) &  (Invoice.billnr == 1) &  (Invoice.flag == 0)).first()

        if not dont_post:

            if fakt_modus == 2:

                if genstat.datum != fdate:
                    dont_post = True

            elif fakt_modus == 3:

                if (genstat.datum + 1) != fdate:
                    dont_post = True

            elif fakt_modus == 4:

                if get_day(fdate) != 1:
                    dont_post = True

            elif fakt_modus == 5:

                if get_day(fdate + timedelta(days=1)) != 1:
                    dont_post = True

            elif fakt_modus == 6:

                if lfakt == None:
                    delta = 0
                else:
                    delta = lfakt - genstat.datum

                    if delta < 0:
                        delta = 0
                start_date = genstat.datum + delta

                if (genstat.datum - start_date) < intervall:
                    start_date = genstat.datum

                if fdate > (start_date + (intervall - 1)):
                    dont_post = True

                if fdate < start_date:
                    dont_post = True


        return generate_inner_output()

    htparam = db_session.query(Htparam).filter(
            (Htparam.paramnr == 110)).first()
    datum = htparam.fdate

    if fdate > datum and tdate == datum:
        disp_arlist()

    elif fdate <= datum and tdate == datum:
        disp_arlist1()

    return generate_output()