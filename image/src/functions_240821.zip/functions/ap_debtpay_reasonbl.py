from functions.additional_functions import *
import decimal
from datetime import date
from sqlalchemy import func
from models import L_kredit, Queasy

def ap_debtpay_reasonbl(curr_mode:str, docu_nr:str, bill_date:date, comments:str):
    l_kredit = queasy = None


    db_session = local_storage.db_session

    def generate_output():
        nonlocal l_kredit, queasy


        return {}

    def create_queasy():

        nonlocal l_kredit, queasy

        l_kredit = db_session.query(L_kredit).filter(
                (L_kredit.rgdatum == bill_date) &  (L_kredit.opart < 2) &  (L_kredit.counter >= 0) &  (func.lower(L_kredit.name) == (docu_nr).lower())).first()

        queasy = db_session.query(Queasy).filter(
                (Queasy.key == 263) &  (Queasy.char1 == l_kredit.name)).first()

        if queasy:
            queasy.char2 = comments


        else:
            queasy = Queasy()
            db_session.add(queasy)

            queasy.key = 263
            queasy.char1 = l_kredit.name
            queasy.char2 = comments

    def load_queasy():

        nonlocal l_kredit, queasy

        l_kredit = db_session.query(L_kredit).filter(
                (L_kredit.rgdatum == bill_date) &  (L_kredit.opart < 2) &  (L_kredit.counter >= 0) &  (func.lower(L_kredit.name) == (docu_nr).lower())).first()

        queasy = db_session.query(Queasy).filter(
                (Queasy.key == 263) &  (Queasy.char1 == l_kredit.name)).first()

        if queasy:
            comments = queasy.char2


        else:
            comments = " "


    if curr_mode.lower()  == "save":
        create_queasy()
    else:
        load_queasy()

    return generate_output()