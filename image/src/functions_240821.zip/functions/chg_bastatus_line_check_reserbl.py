from functions.additional_functions import *
import decimal
from models import Bk_reser

def chg_bastatus_line_check_reserbl(r_recid:int, sorttype:int):
    its_ok = False
    bk_reser = None

    resline = None

    Resline = Bk_reser

    db_session = local_storage.db_session

    def generate_output():
        nonlocal its_ok, bk_reser
        nonlocal resline


        nonlocal resline
        return {"its_ok": its_ok}


    bk_reser = db_session.query(Bk_reser).filter(
            (Bk_reser._recid == r_recid)).first()

    resline = db_session.query(Resline).filter(
            (Resline.datum == bk_reser.datum) &  (Resline.raum == bk_reser.raum) &  (((Resline.von_i >= bk_reser.von_i) &  (Resline.von_i <= bk_reser.bis_i)) |  ((Resline.bis_i >= bk_reser.von_i) &  (Resline.bis_i <= bk_reser.bis_i)) |  ((bk_reser.von_i >= Resline.von_i) &  (bk_reser.bis_i <= Resline.bis_i))) &  ((Resline._recid != bk_reser._recid)) &  (Resline.resstatus == sorttype)).first()

    if resline:

        if resline.resstatus == 1:
            its_ok = False

            return generate_output()

        if resline.resstatus == 2:
            its_ok = False

            return generate_output()