from functions.additional_functions import *
import decimal
from sqlalchemy import func
import random
from models import Bediener, Res_history

def chg_new_password_webbl(uname:str, new_pwd:str):
    pswd:str = ""
    bediener = res_history = None


    db_session = local_storage.db_session

    def generate_output():
        nonlocal pswd, bediener, res_history
        nonlocal uname, new_pwd


        return {}

    def encode_string(in_str:str):

        nonlocal pswd, bediener, res_history
        nonlocal uname, new_pwd

        out_str = ""
        s:str = ""
        j:int = 0
        len_:int = 0
        ch:str = ""

        def generate_inner_output():
            return (out_str)

        j = random.randint(1, 9)
        in_str = to_string(j) + in_str
        j = random.randint(1, 9)
        in_str = to_string(j) + in_str
        j = random.randint(1, 9)
        in_str = to_string(j) + in_str
        j = random.randint(1, 9)
        in_str = to_string(j) + in_str
        j = random.randint(1, 9)
        ch = chr(ord(to_string(j)) + 23)
        out_str = ch
        j = ord(ch) - 71
        for len_ in range(1,len(in_str)  + 1) :
            out_str = out_str + chr (ord(substring(in_str, len_ - 1, 1)) + j)

        return generate_inner_output()


    pswd = encode_string(new_pwd)

    bediener = db_session.query(Bediener).filter(
            (func.lower(Bediener.username) == (uname).lower())).first()

    if bediener:
        bediener.usercode = pswd
        bediener.kassenbest =  to_decimal("0")


        res_history = Res_history()
        db_session.add(res_history)

        res_history.nr = bediener.nr
        res_history.datum = get_current_date()
        res_history.zeit = get_current_time_in_seconds()
        res_history.aenderung = "Change Password"
        res_history.action = "User"


        pass

    return generate_output()