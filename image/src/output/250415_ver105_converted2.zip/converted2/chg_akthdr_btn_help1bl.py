#using conversion tools version: 1.0.0.105

from functions.additional_functions import *
from decimal import Decimal
from models import Guest

def chg_akthdr_btn_help1bl(gastnr:int):

    prepare_cache ([Guest])

    lname = ""
    guest_gastnr = 0
    guest = None

    db_session = local_storage.db_session

    def generate_output():
        nonlocal lname, guest_gastnr, guest
        nonlocal gastnr

        return {"lname": lname, "guest_gastnr": guest_gastnr}


    guest = get_cache (Guest, {"gastnr": [(eq, gastnr)]})
    lname = guest.name + ", " + guest.anredefirma
    guest_gastnr = guest.gastnr

    return generate_output()