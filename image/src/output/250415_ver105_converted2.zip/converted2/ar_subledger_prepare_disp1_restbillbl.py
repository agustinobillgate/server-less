#using conversion tools version: 1.0.0.105

from functions.additional_functions import *
from decimal import Decimal
from models import H_journal, Blinehis

def ar_subledger_prepare_disp1_restbillbl(s_recid:int):

    prepare_cache ([Blinehis])

    billno = 0
    t_h_journal_list = []
    i:int = 0
    h_journal = blinehis = None

    t_h_journal = bline = None

    t_h_journal_list, T_h_journal = create_model_like(H_journal)

    Bline = create_buffer("Bline",Blinehis)


    db_session = local_storage.db_session

    def generate_output():
        nonlocal billno, t_h_journal_list, i, h_journal, blinehis
        nonlocal s_recid
        nonlocal bline


        nonlocal t_h_journal, bline
        nonlocal t_h_journal_list

        return {"billno": billno, "t-h-journal": t_h_journal_list}

    bline = get_cache (Blinehis, {"_recid": [(eq, s_recid)]})
    for i in range(1,length(bline.bezeich)  + 1) :

        if substring(bline.bezeich, i - 1, 1) == ("*").lower() :
            billno = to_int(substring(bline.bezeich, i + 1 - 1, length(bline.bezeich)))
            i = 999

    for h_journal in db_session.query(H_journal).filter(
             (H_journal.rechnr == billno) & (H_journal.departement == bline.departement) & (H_journal.bill_datum == bline.bill_datum)).order_by(H_journal._recid).all():
        t_h_journal = T_h_journal()
        t_h_journal_list.append(t_h_journal)

        buffer_copy(h_journal, t_h_journal)

    return generate_output()